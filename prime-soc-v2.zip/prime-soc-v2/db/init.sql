CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Tenants (synced from Wazuh groups)
CREATE TABLE IF NOT EXISTS tenants (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          VARCHAR(200) NOT NULL,
  wazuh_group   VARCHAR(100) UNIQUE NOT NULL,
  industry      VARCHAR(100),
  status        VARCHAR(20) NOT NULL DEFAULT 'active',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Portal users (auth via Wazuh, roles stored here)
CREATE TABLE IF NOT EXISTS portal_users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wazuh_username VARCHAR(100) UNIQUE NOT NULL,
  portal_role   VARCHAR(20) NOT NULL DEFAULT 'client',
  tenant_id     UUID REFERENCES tenants(id) ON DELETE SET NULL,
  full_name     VARCHAR(200),
  email         VARCHAR(255),
  is_active     BOOLEAN NOT NULL DEFAULT true,
  last_login    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_portal_users_username ON portal_users(wazuh_username);
CREATE INDEX idx_portal_users_tenant ON portal_users(tenant_id);

-- Sessions for audit
CREATE TABLE IF NOT EXISTS sessions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES portal_users(id) ON DELETE CASCADE,
  jti         VARCHAR(100) UNIQUE NOT NULL,
  ip_address  VARCHAR(50),
  user_agent  TEXT,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_jti ON sessions(jti);

-- Audit log
CREATE TABLE IF NOT EXISTS audit_logs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username    VARCHAR(100),
  action      VARCHAR(200) NOT NULL,
  details     JSONB,
  ip_address  VARCHAR(50),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_created ON audit_logs(created_at);

-- Bootstrap admin mapping
-- Real admin login still uses Wazuh credentials
-- This just marks which Wazuh users get admin role in the portal
INSERT INTO portal_users (wazuh_username, portal_role, full_name)
VALUES ('wazuh', 'admin', 'SOC Administrator')
ON CONFLICT (wazuh_username) DO NOTHING;

INSERT INTO portal_users (wazuh_username, portal_role, full_name)
VALUES ('admin', 'admin', 'Portal Admin')
ON CONFLICT (wazuh_username) DO NOTHING;
