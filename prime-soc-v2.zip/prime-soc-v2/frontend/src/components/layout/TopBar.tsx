'use client';
import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface User { id:string;username:string;role:string;full_name:string;tenant_id?:string|null;wazuh_group?:string|null; }

export default function TopBar({ user, className='' }: { user:User; className?:string }) {
  const router = useRouter();
  const [profile, setProfile] = useState(false);
  const [notifs, setNotifs]   = useState(false);
  const pRef = useRef<HTMLDivElement>(null);
  const nRef = useRef<HTMLDivElement>(null);
  const initials = user.full_name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2)||'U';

  useEffect(() => {
    const h = (e:MouseEvent) => {
      if (pRef.current && !pRef.current.contains(e.target as Node)) setProfile(false);
      if (nRef.current && !nRef.current.contains(e.target as Node)) setNotifs(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const logout = async () => {
    await fetch('/api/auth/logout', { method:'POST' });
    router.push('/'); router.refresh();
  };

  return (
    <header className={`${className} flex items-center justify-between px-4`}
      style={{ background:'rgba(8,12,20,0.98)', borderBottom:'1px solid var(--border)', backdropFilter:'blur(12px)', zIndex:50 }}>
      {/* Logo */}
      <div className="flex items-center gap-2.5 min-w-[180px]">
        <div className="w-7 h-7 rounded-lg flex items-center justify-center"
          style={{ background:'rgba(0,216,232,0.15)', border:'1px solid rgba(0,216,232,0.3)' }}>
          <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none">
            <path d="M12 2L3 6v6c0 5.5 3.8 10.7 9 12 5.2-1.3 9-6.5 9-12V6l-9-4z"
              fill="rgba(0,216,232,0.2)" stroke="var(--cyan)" strokeWidth="1.5"/>
            <path d="M9 12l2 2 4-4" stroke="var(--cyan)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <span className="font-bold text-white" style={{ fontSize:15, letterSpacing:'-0.02em' }}>Prime SOC</span>
      </div>

      {/* Search */}
      <div className="flex-1 max-w-[340px] mx-4">
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
          </svg>
          <input className="field pl-9 py-1.5" style={{ fontSize:12 }} placeholder="Search telemetry, agents, events…" />
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1.5">
        <button onClick={() => router.push('/cases')}
          className="label-caps px-3 py-1.5 rounded-lg transition-colors"
          style={{ border:'1px solid var(--cyan)', color:'var(--cyan)', background:'rgba(0,216,232,0.07)', fontSize:9 }}>
          + Case
        </button>
        <button onClick={() => router.push('/soar')}
          className="label-caps px-3 py-1.5 rounded-lg transition-colors text-white"
          style={{ border:'1px solid rgba(255,255,255,0.12)', background:'rgba(255,255,255,0.04)', fontSize:9 }}>
          Playbook
        </button>

        {/* Notifications */}
        <div ref={nRef} className="relative">
          <button onClick={() => setNotifs(!notifs)}
            className="relative w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/5">
            <svg className="w-4 h-4 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
            </svg>
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-400" />
          </button>
          {notifs && (
            <div className="absolute right-0 top-10 w-72 rounded-xl z-50 overflow-hidden animate-up"
              style={{ background:'#0d1117', border:'1px solid var(--border)', boxShadow:'0 16px 48px rgba(0,0,0,0.6)' }}>
              <div className="px-4 py-3 border-b flex justify-between" style={{ borderColor:'var(--border)' }}>
                <span className="label-caps text-secondary">Alerts</span>
                <span className="mono text-dim" style={{ fontSize:10 }}>Real-time</span>
              </div>
              <div className="p-2 text-center py-6">
                <p className="mono text-dim" style={{ fontSize:11 }}>Live alerts load from Wazuh feed</p>
                <button onClick={() => { setNotifs(false); router.push('/dashboard'); }}
                  className="mt-3 label-caps text-cyan" style={{ fontSize:9 }}>
                  View Dashboard →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Profile */}
        <div ref={pRef} className="relative">
          <button onClick={() => setProfile(!profile)}
            className="flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-white/5 transition-colors">
            <div className="w-6 h-6 rounded-full flex items-center justify-center font-bold mono text-xs"
              style={{ background: user.role==='admin' ? 'var(--cyan)' : 'var(--purple)', color:'#fff', fontSize:10 }}>
              {initials}
            </div>
            <svg className="w-3 h-3 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/>
            </svg>
          </button>
          {profile && (
            <div className="absolute right-0 top-9 w-52 rounded-xl z-50 overflow-hidden animate-up"
              style={{ background:'#0d1117', border:'1px solid var(--border)', boxShadow:'0 16px 48px rgba(0,0,0,0.6)' }}>
              <div className="px-4 py-3 border-b" style={{ borderColor:'var(--border)' }}>
                <p className="font-semibold text-white" style={{ fontSize:13 }}>{user.full_name}</p>
                <p className="mono text-dim mt-0.5" style={{ fontSize:10 }}>
                  {user.role === 'admin' ? 'SUPER ADMIN' : 'CLIENT'}
                  {user.wazuh_group ? ` · ${user.wazuh_group}` : ''}
                </p>
              </div>
              <div className="p-1.5">
                <button onClick={() => { setProfile(false); router.push('/settings'); }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/5 text-secondary transition-colors">
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                  </svg>
                  <span style={{ fontSize:12 }}>Settings</span>
                </button>
                <div className="my-1 border-t" style={{ borderColor:'var(--border)' }} />
                <button onClick={logout}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-red-500/10 transition-colors">
                  <svg className="w-3.5 h-3.5 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                  </svg>
                  <span className="text-red-400" style={{ fontSize:12 }}>Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
