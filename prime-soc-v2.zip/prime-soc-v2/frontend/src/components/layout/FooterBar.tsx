'use client';
import { useEffect, useState } from 'react';
export default function FooterBar({ className='' }: { className?:string }) {
  const [t, setT] = useState('');
  useEffect(() => {
    const tick = () => setT(new Date().toUTCString().split(' ')[4]+' UTC');
    tick(); const id = setInterval(tick, 1000); return () => clearInterval(id);
  }, []);
  return (
    <footer className={`${className} flex justify-between items-center px-5`}
      style={{ background:'rgba(8,12,20,0.98)', borderTop:'1px solid var(--border)', backdropFilter:'blur(8px)' }}>
      <div className="flex items-center gap-4">
        <span className="mono text-green-400 flex items-center gap-1.5" style={{ fontSize:10 }}>
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live" />SYSTEM NOMINAL
        </span>
        <span className="mono text-dim" style={{ fontSize:10 }}>|</span>
        <span className="mono text-dim" style={{ fontSize:10 }}>ENCRYPTED · STABLE</span>
      </div>
      <div className="flex items-center gap-4">
        <a href="#" className="mono text-dim hover:text-secondary transition-colors" style={{ fontSize:10 }}>Status</a>
        <a href="#" className="mono text-dim hover:text-secondary transition-colors" style={{ fontSize:10 }}>Support</a>
        <a href="#" className="mono text-dim hover:text-secondary transition-colors" style={{ fontSize:10 }}>Docs</a>
        <span className="mono text-dim" style={{ fontSize:10 }}>{t}</span>
      </div>
    </footer>
  );
}
