import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
import TopBar from '@/components/layout/TopBar';
import Sidebar from '@/components/layout/Sidebar';
import FooterBar from '@/components/layout/FooterBar';

async function getUser() {
  const store = cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const payload = await verifyToken(token);
  if (!payload) return null;
  return queryOne<{
    id:string;wazuh_username:string;portal_role:string;
    tenant_id:string|null;full_name:string|null;
    wazuh_group:string|null;last_login:string|null;
  }>(
    `SELECT pu.id, pu.wazuh_username, pu.portal_role, pu.tenant_id,
            pu.full_name, pu.last_login, t.wazuh_group
     FROM portal_users pu
     LEFT JOIN tenants t ON t.id = pu.tenant_id
     WHERE pu.id = $1 AND pu.is_active = true`,
    [payload.sub],
  );
}

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const user = await getUser();
  if (!user) redirect('/');

  const userCtx = {
    id:           user.id,
    username:     user.wazuh_username,
    role:         user.portal_role,
    tenant_id:    user.tenant_id,
    full_name:    user.full_name ?? user.wazuh_username,
    wazuh_group:  user.wazuh_group,
    last_login:   user.last_login,
  };

  return (
    <div className="portal-grid">
      <TopBar user={userCtx} className="area-top" />
      <Sidebar user={userCtx} className="area-side" />
      <main className="area-main" style={{ background: 'var(--bg-primary)' }}>
        {children}
      </main>
      <FooterBar className="area-foot" />
    </div>
  );
}
