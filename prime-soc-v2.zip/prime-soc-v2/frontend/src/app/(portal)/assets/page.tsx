'use client';
import { useState, useEffect } from 'react';

interface Agent {
  id: string; name: string; ip?: string; status: string;
  os?: { name: string; version: string; platform: string };
  group?: string[]; version?: string;
  lastKeepAlive?: string; dateAdd?: string;
}

const STATUS: Record<string, { color: string; bg: string }> = {
  active:          { color: '#10b981', bg: 'rgba(16,185,129,0.12)' },
  disconnected:    { color: '#ef4444', bg: 'rgba(239,68,68,0.12)' },
  never_connected: { color: '#475569', bg: 'rgba(71,85,105,0.2)' },
  pending:         { color: '#f59e0b', bg: 'rgba(245,158,11,0.12)' },
};

export default function AssetsPage() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [total, setTotal]   = useState(0);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const fetchAgents = () => {
    setLoading(true);
    fetch('/api/wazuh/agents').then(r => r.json())
      .then(d => { setAgents(d.agents ?? []); setTotal(d.total ?? 0); })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchAgents(); }, []);

  const filtered = agents.filter(a => {
    const text = !filter || a.name.toLowerCase().includes(filter.toLowerCase()) || (a.ip ?? '').includes(filter);
    const status = statusFilter === 'all' || a.status === statusFilter;
    return text && status;
  });

  const counts = {
    active:       agents.filter(a => a.status === 'active').length,
    disconnected: agents.filter(a => a.status === 'disconnected').length,
    pending:      agents.filter(a => a.status === 'pending').length,
    never:        agents.filter(a => a.status === 'never_connected').length,
  };
  const healthPct = total > 0 ? ((counts.active / total) * 100).toFixed(1) : '0';

  return (
    <div className="p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-white" style={{ fontSize: 20, letterSpacing: '-0.02em' }}>Assets & Endpoints</h1>
          <p className="mono text-secondary mt-0.5" style={{ fontSize: 11 }}>
            {total.toLocaleString()} managed endpoints via Wazuh
          </p>
        </div>
        <button onClick={fetchAgents} className="label-caps px-3 py-1.5 rounded-lg text-secondary hover:text-white transition-colors flex items-center gap-1.5"
          style={{ border: '1px solid var(--border)', fontSize: 9 }}>
          <svg className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Refresh
        </button>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-5 gap-3">
        {[
          { label: 'Total Agents', value: total, color: 'var(--cyan)', filter: 'all' },
          { label: 'Active', value: counts.active, color: 'var(--green)', filter: 'active' },
          { label: 'Disconnected', value: counts.disconnected, color: 'var(--red)', filter: 'disconnected' },
          { label: 'Pending', value: counts.pending, color: 'var(--amber)', filter: 'pending' },
          { label: 'Health', value: `${healthPct}%`, color: 'var(--cyan)', filter: 'all' },
        ].map(s => (
          <button key={s.label} onClick={() => setStatusFilter(s.filter)}
            className="card p-3 text-center transition-all hover:border-cyan-500/30"
            style={{ borderColor: statusFilter === s.filter && s.filter !== 'all' ? s.color + '50' : undefined }}>
            <p className="label-caps text-dim" style={{ fontSize: 8 }}>{s.label}</p>
            <p className="stat-value mt-1" style={{ fontSize: 20, color: s.color }}>{s.value}</p>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input value={filter} onChange={e => setFilter(e.target.value)}
            className="field pl-9 py-1.5" style={{ fontSize: 12, width: 240 }}
            placeholder="Search by name, IP…" />
        </div>
        <div className="flex gap-1.5">
          {['all', 'active', 'disconnected', 'pending', 'never_connected'].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className="label-caps px-2.5 py-1.5 rounded-lg transition-colors"
              style={{
                fontSize: 8,
                background: statusFilter === s ? 'rgba(0,216,232,0.12)' : 'transparent',
                border: `1px solid ${statusFilter === s ? 'rgba(0,216,232,0.3)' : 'var(--border)'}`,
                color: statusFilter === s ? 'var(--cyan)' : 'var(--text-dim)',
              }}>
              {s.replace('_', ' ')}
            </button>
          ))}
        </div>
        <span className="mono text-dim ml-auto" style={{ fontSize: 10 }}>
          {filtered.length} / {agents.length} shown
        </span>
      </div>

      {/* Agent Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="py-16 flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
            <p className="mono text-secondary" style={{ fontSize: 12 }}>Fetching agents from Wazuh API…</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-12 text-center">
            <p className="mono text-dim" style={{ fontSize: 12 }}>No agents match current filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Agent ID</th><th>Name</th><th>IP</th>
                  <th>OS</th><th>Group</th><th>Version</th>
                  <th>Last Keepalive</th><th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 200).map(agent => {
                  const st = STATUS[agent.status] ?? STATUS.pending;
                  return (
                    <tr key={agent.id}>
                      <td className="mono text-dim" style={{ fontSize: 11 }}>{agent.id}</td>
                      <td className="font-semibold text-white" style={{ fontSize: 12 }}>{agent.name}</td>
                      <td className="mono text-secondary" style={{ fontSize: 11 }}>{agent.ip ?? '—'}</td>
                      <td className="mono text-secondary" style={{ fontSize: 11 }}>
                        {agent.os ? `${agent.os.name} ${agent.os.version ?? ''}`.trim() : '—'}
                      </td>
                      <td className="mono text-secondary" style={{ fontSize: 11 }}>{agent.group?.join(', ') ?? '—'}</td>
                      <td className="mono text-dim" style={{ fontSize: 11 }}>{agent.version ?? '—'}</td>
                      <td className="mono text-dim" style={{ fontSize: 11 }}>
                        {agent.lastKeepAlive ? new Date(agent.lastKeepAlive).toLocaleString() : '—'}
                      </td>
                      <td>
                        <span className="label-caps px-2 py-0.5 rounded"
                          style={{ fontSize: 8, background: st.bg, color: st.color }}>
                          {agent.status.replace('_', ' ')}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length > 200 && (
              <div className="py-3 text-center border-t" style={{ borderColor: 'var(--border)' }}>
                <p className="mono text-dim" style={{ fontSize: 11 }}>Showing 200 of {filtered.length}. Use filters to narrow.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
