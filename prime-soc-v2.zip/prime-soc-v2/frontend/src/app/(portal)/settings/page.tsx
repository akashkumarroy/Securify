'use client';
import { useState } from 'react';

export default function SettingsPage() {
  const [section, setSection] = useState<'general'|'integrations'|'security'>('general');
  const [saved, setSaved] = useState(false);

  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 2500); };

  const TOOLS = [
    { key:'WAZUH_DASHBOARD_URL',  label:'Wazuh Dashboard URL',  color:'var(--cyan)',   current: process.env.NEXT_PUBLIC_WAZUH_DASHBOARD_URL ?? 'https://msocprime.centralindia.cloudapp.azure.com' },
    { key:'OPENCTI_URL',          label:'OpenCTI URL',           color:'#a78bfa',       current: process.env.NEXT_PUBLIC_OPENCTI_URL ?? 'http://10.0.7.93:8080' },
    { key:'SHUFFLE_URL',          label:'Shuffle (SOAR) URL',    color:'#7c3aed',       current: process.env.NEXT_PUBLIC_SHUFFLE_URL ?? 'https://shuffler.io' },
    { key:'IRIS_URL',             label:'IRIS URL',              color:'var(--red)',    current: process.env.NEXT_PUBLIC_IRIS_URL ?? 'https://10.0.7.93:4433' },
  ];

  return (
    <div className="p-5 space-y-5">
      <div>
        <h1 className="font-bold text-white" style={{ fontSize:20, letterSpacing:'-0.02em' }}>Portal Settings</h1>
        <p className="mono text-secondary mt-0.5" style={{ fontSize:11 }}>Configure integrations and portal preferences</p>
      </div>

      <div className="flex gap-6">
        {/* Sidebar nav */}
        <div className="w-40 shrink-0 space-y-0.5">
          {(['general','integrations','security'] as const).map(s => (
            <button key={s} onClick={() => setSection(s)}
              className="w-full text-left px-3 py-2 rounded-lg capitalize transition-colors"
              style={{
                fontSize:13,
                background: section===s ? 'rgba(0,216,232,0.08)' : 'transparent',
                borderLeft: section===s ? '2px solid var(--cyan)' : '2px solid transparent',
                color: section===s ? 'var(--cyan)' : 'var(--text-secondary)',
              }}>
              {s}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 max-w-xl space-y-4">
          {section === 'general' && (
            <div className="card p-5 space-y-4">
              <p className="label-caps text-secondary" style={{ fontSize:9 }}>Portal Identity</p>
              {[
                { label:'Portal Name', default:'Prime SOC' },
                { label:'Organization', default:'Vanguard Ops Command' },
              ].map(f => (
                <div key={f.label}>
                  <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>{f.label}</label>
                  <input className="field" defaultValue={f.default} />
                </div>
              ))}
              <div>
                <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Session Timeout (hours)</label>
                <input className="field" type="number" defaultValue={8} min={1} max={24} style={{ width:100 }} />
              </div>
            </div>
          )}

          {section === 'integrations' && (
            <div className="card p-5 space-y-5">
              <div>
                <p className="label-caps text-secondary mb-1" style={{ fontSize:9 }}>Tool URLs</p>
                <p className="mono text-dim" style={{ fontSize:10 }}>
                  Update your <code className="text-cyan-400">.env</code> file to change these. Restart Docker after any changes.
                </p>
              </div>
              {TOOLS.map(t => (
                <div key={t.key}>
                  <label className="flex items-center gap-2 mb-1.5">
                    <div className="w-2 h-2 rounded-full" style={{ background:t.color }} />
                    <span className="label-caps text-secondary" style={{ fontSize:8 }}>{t.label}</span>
                  </label>
                  <input className="field" defaultValue={t.current} readOnly
                    style={{ borderColor:`${t.color}30`, color:'var(--text-dim)' }} />
                </div>
              ))}
              <div className="px-3 py-3 rounded-lg flex items-start gap-2"
                style={{ background:'rgba(245,158,11,0.08)', border:'1px solid rgba(245,158,11,0.2)' }}>
                <svg className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <p className="mono text-amber-300" style={{ fontSize:10 }}>
                  URLs are configured in <strong>.env</strong> at deploy time. Edit .env and run{' '}
                  <code>docker compose up -d --build</code> to apply changes.
                </p>
              </div>
            </div>
          )}

          {section === 'security' && (
            <div className="card p-5 space-y-4">
              <p className="label-caps text-secondary" style={{ fontSize:9 }}>Security Settings</p>
              {[
                { label:'Wazuh IAM Authentication',  desc:'All logins validated against Wazuh API', on:true, locked:true },
                { label:'Session Audit Logging',     desc:'All login/logout events stored in PostgreSQL', on:true, locked:true },
                { label:'IP Rate Limiting (Nginx)',   desc:'5 login attempts per minute per IP', on:true, locked:false },
                { label:'TLS Bypass for Self-Signed', desc:'rejectUnauthorized=false for Wazuh/IRIS', on:true, locked:false },
                { label:'SSO Integration (OIDC)',     desc:'Future roadmap — replace per-module auth', on:false, locked:false },
              ].map(s => (
                <div key={s.label} className="flex items-center justify-between py-2.5 border-b last:border-0"
                  style={{ borderColor:'var(--border)' }}>
                  <div>
                    <p className="font-medium text-white" style={{ fontSize:13 }}>{s.label}</p>
                    <p className="mono text-secondary mt-0.5" style={{ fontSize:10 }}>{s.desc}</p>
                  </div>
                  <div className="relative w-9 h-5 rounded-full cursor-pointer shrink-0"
                    style={{ background: s.on ? 'var(--cyan)' : 'rgba(71,85,105,0.5)', opacity: s.locked ? 0.7 : 1 }}>
                    <div className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all"
                      style={{ left: s.on ? '18px' : '2px' }} />
                  </div>
                </div>
              ))}
            </div>
          )}

          <button onClick={save}
            className="label-caps px-6 py-2.5 rounded-lg flex items-center gap-2 transition-all"
            style={{ background: saved ? 'var(--green)' : 'var(--cyan)', color:'#001a1e', fontSize:9 }}>
            {saved
              ? <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>Saved</>
              : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
}
