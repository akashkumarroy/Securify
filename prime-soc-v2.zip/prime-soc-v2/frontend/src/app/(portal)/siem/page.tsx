'use client';
import { useState, useEffect } from 'react';

type Tab = 'overview'|'events'|'fim'|'sca'|'vulnerability'|'compliance';

interface AgentStats { total:number; active:number; disconnected:number; never:number; }
interface Alert { id:string; timestamp:string; severity:string; source:string; rule_desc:string; rule_level:number; }
interface FIM { file:string; agent_id:string; date:string; type:string; size?:number; }
interface SCA { policy_id:string; name:string; score:number; passed:number; failed:number; total_checks:number; agent_id:string; }
interface VulnSummary { summary:{critical:number;high:number;medium:number;low:number;total:number}; perAgent:{agent_id:string;name:string;count:number}[]; }
interface Compliance { id:string; name:string; count:number; }

const SEV_COLOR: Record<string,string> = { CRITICAL:'#ef4444', HIGH:'#f59e0b', MEDIUM:'#eab308', LOW:'#3b82f6', INFO:'#64748b' };

export default function SIEMPage() {
  const [tab, setTab] = useState<Tab>('overview');
  const [agents, setAgents]   = useState<AgentStats|null>(null);
  const [alerts, setAlerts]   = useState<Alert[]>([]);
  const [fim, setFim]         = useState<FIM[]>([]);
  const [sca, setSca]         = useState<SCA[]>([]);
  const [vuln, setVuln]       = useState<VulnSummary|null>(null);
  const [compliance, setCompliance] = useState<Compliance[]>([]);
  const [loading, setLoading] = useState<Record<string,boolean>>({});

  const load = async (which: string) => {
    setLoading(p => ({ ...p, [which]: true }));
    try {
      if (which === 'overview' || which === 'all') {
        const [ag, al] = await Promise.all([
          fetch('/api/wazuh/agents').then(r=>r.json()),
          fetch('/api/wazuh/alerts?limit=50').then(r=>r.json()),
        ]);
        const items = ag.agents ?? [];
        setAgents({
          total: ag.total ?? 0,
          active: items.filter((a:any)=>a.status==='active').length,
          disconnected: items.filter((a:any)=>a.status==='disconnected').length,
          never: items.filter((a:any)=>a.status==='never_connected').length,
        });
        setAlerts(al.alerts ?? []);
      }
      if (which === 'fim') {
        const r = await fetch('/api/wazuh/fim').then(r=>r.json());
        setFim(Array.isArray(r) ? r.slice(0,100) : []);
      }
      if (which === 'sca') {
        const r = await fetch('/api/wazuh/sca').then(r=>r.json());
        setSca(Array.isArray(r) ? r : []);
      }
      if (which === 'vulnerability') {
        const r = await fetch('/api/wazuh/vulnerability').then(r=>r.json());
        setVuln(r?.summary ? r : null);
      }
      if (which === 'compliance') {
        const r = await fetch('/api/wazuh/compliance').then(r=>r.json());
        setCompliance(Array.isArray(r) ? r : []);
      }
    } finally { setLoading(p => ({ ...p, [which]: false })); }
  };

  useEffect(() => { load('overview'); }, []);
  useEffect(() => { if (tab !== 'overview' && tab !== 'events') load(tab); }, [tab]);

  const TABS: { id:Tab; label:string }[] = [
    { id:'overview', label:'Overview' },
    { id:'events', label:'Security Events' },
    { id:'fim', label:'File Integrity' },
    { id:'sca', label:'Configuration Assessment' },
    { id:'vulnerability', label:'Vulnerabilities' },
    { id:'compliance', label:'Compliance' },
  ];

  const isLoading = (t: string) => loading[t] || loading['all'];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-0 shrink-0">
        <div className="flex items-center gap-3 mb-4">
          <h1 className="font-bold text-white" style={{ fontSize:20, letterSpacing:'-0.02em' }}>Security Information &amp; Event Management</h1>
          <span className="badge badge-active">LIVE TELEMETRY</span>
        </div>

        {/* Stat row */}
        <div className="grid grid-cols-4 gap-3 mb-4">
          {[
            { label:'Total Agents', value:agents?.total??'…', color:'var(--cyan)' },
            { label:'Active',       value:agents?.active??'…', color:'var(--green)' },
            { label:'Disconnected', value:agents?.disconnected??'…', color:'var(--red)' },
            { label:'Never Connected', value:agents?.never??'…', color:'var(--text-dim)' },
          ].map(s => (
            <div key={s.label} className="card px-4 py-3">
              <p className="label-caps text-dim">{s.label}</p>
              <p className="stat-value mt-1" style={{ fontSize:24, color:s.color }}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-0 border-b" style={{ borderColor:'var(--border)' }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className="px-4 py-2 label-caps transition-colors border-b-2 -mb-px"
              style={{
                fontSize: 9,
                borderColor: tab===t.id ? 'var(--cyan)' : 'transparent',
                color: tab===t.id ? 'var(--cyan)' : 'var(--text-dim)',
              }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-auto p-5">
        {/* OVERVIEW */}
        {tab === 'overview' && (
          <div className="space-y-4">
            <div className="card" style={{ maxHeight:400, overflow:'auto' }}>
              <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor:'var(--border)' }}>
                <p className="label-caps text-secondary">Latest Security Events</p>
                <span className="mono text-dim" style={{ fontSize:10 }}>{alerts.length} records</span>
              </div>
              <table className="data-table">
                <thead><tr><th>Timestamp</th><th>Level</th><th>Agent</th><th>Rule Description</th></tr></thead>
                <tbody>
                  {alerts.slice(0,20).map(a => (
                    <tr key={a.id}>
                      <td className="mono text-dim" style={{ fontSize:11 }}>{a.timestamp?new Date(a.timestamp).toLocaleString():''}</td>
                      <td>
                        <span className={`badge ${a.severity==='CRITICAL'?'badge-critical':a.severity==='HIGH'?'badge-high':a.severity==='MEDIUM'?'badge-medium':'badge-low'}`}>{a.rule_level}</span>
                      </td>
                      <td className="text-white font-medium" style={{ fontSize:12 }}>{a.source}</td>
                      <td className="text-secondary" style={{ fontSize:12 }}>{a.rule_desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {alerts.length===0 && <div className="py-8 text-center"><p className="mono text-dim" style={{ fontSize:12 }}>No events fetched</p></div>}
            </div>
          </div>
        )}

        {/* EVENTS - all alerts with filters */}
        {tab === 'events' && (
          <div className="card" style={{ overflow:'auto', maxHeight:'calc(100vh - 280px)' }}>
            <div className="px-4 py-3 border-b" style={{ borderColor:'var(--border)' }}>
              <p className="label-caps text-secondary">Security Events ({alerts.length})</p>
            </div>
            <table className="data-table">
              <thead><tr><th>Timestamp</th><th>Severity</th><th>Agent</th><th>IP</th><th>Rule</th><th>Level</th></tr></thead>
              <tbody>
                {alerts.map(a => (
                  <tr key={a.id}>
                    <td className="mono text-dim" style={{ fontSize:11 }}>{a.timestamp?new Date(a.timestamp).toLocaleString():''}</td>
                    <td><span className={`badge badge-${a.severity.toLowerCase()}`}>{a.severity}</span></td>
                    <td className="text-white" style={{ fontSize:12 }}>{a.source}</td>
                    <td className="mono text-dim" style={{ fontSize:11 }}>{(a as any).agent_ip??'—'}</td>
                    <td className="text-secondary" style={{ fontSize:12, maxWidth:200 }}>
                      <span className="truncate block" title={a.rule_desc}>{a.rule_desc}</span>
                    </td>
                    <td className="mono" style={{ fontSize:11, color: a.rule_level>=13?'#ef4444':a.rule_level>=10?'#f59e0b':'var(--text-secondary)' }}>{a.rule_level}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {alerts.length===0&&<div className="py-8 text-center"><p className="mono text-dim" style={{ fontSize:12 }}>No events</p></div>}
          </div>
        )}

        {/* FIM */}
        {tab === 'fim' && (
          <div className="space-y-4">
            <div className="card">
              <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor:'var(--border)' }}>
                <p className="label-caps text-secondary">File Integrity Monitoring Events</p>
                {isLoading('fim') && <div className="w-4 h-4 border border-cyan-400 border-t-transparent rounded-full animate-spin" />}
              </div>
              {fim.length > 0 ? (
                <table className="data-table">
                  <thead><tr><th>Date</th><th>Agent</th><th>File</th><th>Event</th><th>Size</th></tr></thead>
                  <tbody>
                    {fim.map((f,i) => (
                      <tr key={i}>
                        <td className="mono text-dim" style={{ fontSize:11 }}>{f.date?new Date(f.date).toLocaleString():''}</td>
                        <td className="text-white" style={{ fontSize:12 }}>{f.agent_id}</td>
                        <td className="mono text-secondary" style={{ fontSize:11, maxWidth:280 }}>
                          <span className="truncate block" title={f.file}>{f.file}</span>
                        </td>
                        <td><span className={`badge ${f.type==='modified'?'badge-warning':f.type==='deleted'?'badge-critical':'badge-info'}`}>{f.type||'changed'}</span></td>
                        <td className="mono text-dim" style={{ fontSize:11 }}>{f.size?`${f.size}B`:'—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="py-12 text-center">
                  <p className="mono text-dim" style={{ fontSize:12 }}>
                    {isLoading('fim') ? 'Loading FIM data…' : 'No FIM events found. Ensure FIM is enabled on agents.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SCA */}
        {tab === 'sca' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 mb-4">
              {sca.slice(0,6).map((p,i) => {
                const pct = p.total_checks > 0 ? Math.round((p.passed/p.total_checks)*100) : 0;
                return (
                  <div key={i} className="card p-4">
                    <p className="font-semibold text-white mb-1" style={{ fontSize:13 }}>{p.name}</p>
                    <p className="mono text-dim mb-3" style={{ fontSize:10 }}>Agent: {p.agent_id}</p>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="relative w-12 h-12">
                        <svg className="w-full h-full -rotate-90" viewBox="0 0 40 40">
                          <circle cx="20" cy="20" r="16" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="4"/>
                          <circle cx="20" cy="20" r="16" fill="none"
                            stroke={pct>=80?'var(--green)':pct>=60?'var(--amber)':'var(--red)'}
                            strokeWidth="4"
                            strokeDasharray={`${2*Math.PI*16*pct/100} ${2*Math.PI*16}`}
                            strokeLinecap="round"/>
                        </svg>
                        <span className="absolute inset-0 flex items-center justify-center mono font-bold" style={{ fontSize:9 }}>{pct}%</span>
                      </div>
                      <div>
                        <p className="mono font-bold" style={{ color:pct>=80?'var(--green)':pct>=60?'var(--amber)':'var(--red)', fontSize:18 }}>{p.score??pct}</p>
                        <p className="mono text-dim" style={{ fontSize:9 }}>Score</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div className="rounded-lg py-1" style={{ background:'rgba(16,185,129,0.1)' }}>
                        <p className="mono font-bold text-green-400" style={{ fontSize:14 }}>{p.passed}</p>
                        <p className="mono text-dim" style={{ fontSize:9 }}>Passed</p>
                      </div>
                      <div className="rounded-lg py-1" style={{ background:'rgba(239,68,68,0.1)' }}>
                        <p className="mono font-bold text-red-400" style={{ fontSize:14 }}>{p.failed}</p>
                        <p className="mono text-dim" style={{ fontSize:9 }}>Failed</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            {sca.length===0&&!isLoading('sca')&&(
              <div className="card py-12 text-center">
                <p className="mono text-dim" style={{ fontSize:12 }}>No SCA data. Enable SCA module in Wazuh agents.</p>
              </div>
            )}
            {isLoading('sca')&&<div className="py-8 text-center"><div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto"/></div>}
          </div>
        )}

        {/* VULNERABILITY */}
        {tab === 'vulnerability' && (
          <div className="space-y-4">
            {vuln ? (
              <>
                <div className="grid grid-cols-4 gap-4">
                  {[
                    { label:'Critical', value:vuln.summary.critical, color:'var(--red)' },
                    { label:'High',     value:vuln.summary.high,     color:'var(--amber)' },
                    { label:'Medium',   value:vuln.summary.medium,   color:'#eab308' },
                    { label:'Low',      value:vuln.summary.low,      color:'#3b82f6' },
                  ].map(s => (
                    <div key={s.label} className="card p-4 text-center">
                      <p className="label-caps text-dim mb-2">{s.label}</p>
                      <p className="stat-value" style={{ fontSize:32, color:s.color }}>{s.value}</p>
                    </div>
                  ))}
                </div>
                <div className="card">
                  <div className="px-4 py-3 border-b" style={{ borderColor:'var(--border)' }}>
                    <p className="label-caps text-secondary">Vulnerabilities by Agent (Top 10)</p>
                  </div>
                  <table className="data-table">
                    <thead><tr><th>Agent</th><th>Total Vulnerabilities</th><th>Risk Bar</th></tr></thead>
                    <tbody>
                      {vuln.perAgent.map((a,i) => {
                        const max = vuln.perAgent[0]?.count ?? 1;
                        return (
                          <tr key={i}>
                            <td className="text-white font-medium" style={{ fontSize:12 }}>{a.name}</td>
                            <td className="mono font-bold" style={{ fontSize:14, color:'var(--amber)' }}>{a.count}</td>
                            <td style={{ width:200 }}>
                              <div className="rounded-full overflow-hidden" style={{ height:4, background:'rgba(255,255,255,0.05)' }}>
                                <div style={{ width:`${(a.count/max)*100}%`, height:'100%', background:'var(--amber)', borderRadius:4 }} />
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <div className="card py-12 text-center">
                <p className="mono text-dim" style={{ fontSize:12 }}>
                  {isLoading('vulnerability') ? 'Fetching vulnerability data…' : 'No vulnerability data. Enable Vulnerability Detection module in Wazuh.'}
                </p>
              </div>
            )}
          </div>
        )}

        {/* COMPLIANCE */}
        {tab === 'compliance' && (
          <div className="space-y-4">
            {compliance.length > 0 ? (
              <div className="grid grid-cols-3 gap-4">
                {compliance.map((f,i) => (
                  <div key={i} className="card p-5">
                    <div className="flex items-center justify-between mb-3">
                      <p className="font-bold text-white" style={{ fontSize:15 }}>{f.name}</p>
                      <span className="badge badge-active">MONITORED</span>
                    </div>
                    <p className="stat-value" style={{ fontSize:32, color:'var(--cyan)' }}>{f.count}</p>
                    <p className="mono text-dim mt-1" style={{ fontSize:10 }}>Alert events mapped to {f.id.toUpperCase()}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="card py-12 text-center">
                <p className="mono text-dim" style={{ fontSize:12 }}>
                  {isLoading('compliance') ? 'Fetching compliance data…' : 'No compliance-tagged alerts found. Alerts need PCI-DSS/HIPAA/GDPR/NIST rule groups.'}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
