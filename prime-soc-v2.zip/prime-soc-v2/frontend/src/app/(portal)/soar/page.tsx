'use client';
import { useState, useEffect } from 'react';

interface SoarStats {
  total_workflows: number;
  active_workflows: number;
  success: number;
  failed: number;
  pending: number;
  health_pct: number;
}

export default function SOARPage() {
  const [authenticated, setAuth] = useState(false);
  const [creds, setCreds] = useState({ u: '', p: '' });
  const [stats, setStats] = useState<SoarStats | null>(null);
  const [iframeLoaded, setLoaded] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);

  useEffect(() => {
    fetch('/api/soar/stats').then(r => r.json()).then(setStats).catch(() => {});
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    await new Promise(r => setTimeout(r, 500));
    setAuthLoading(false);
    setAuth(true);
  };

  const SHUFFLE_URL = process.env.NEXT_PUBLIC_SHUFFLE_URL ?? 'https://shuffler.io';

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-4 shrink-0 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="font-bold text-white" style={{ fontSize: 20, letterSpacing: '-0.02em' }}>SOAR Automation</h1>
            <p className="mono text-secondary mt-0.5" style={{ fontSize: 11 }}>Security Orchestration, Automation & Response — Shuffle</p>
          </div>
          <button className="label-caps px-4 py-2 rounded-lg transition-colors"
            style={{ background: 'var(--cyan)', color: '#001a1e', fontSize: 9 }}>
            ▶ Run Playbook
          </button>
        </div>
        {/* Stats */}
        <div className="grid grid-cols-5 gap-3">
          {[
            { label: 'Total Workflows', value: stats?.total_workflows ?? '—', color: 'var(--cyan)' },
            { label: 'Active Now', value: stats?.active_workflows ?? '—', color: 'var(--green)' },
            { label: 'Successful', value: stats?.success ?? '—', color: 'var(--green)' },
            { label: 'Failed', value: stats?.failed ?? '—', color: 'var(--red)' },
            { label: 'Pending', value: stats?.pending ?? '—', color: 'var(--amber)' },
          ].map(s => (
            <div key={s.label} className="card px-3 py-2 text-center">
              <p className="label-caps text-dim" style={{ fontSize: 8 }}>{s.label}</p>
              <p className="stat-value mt-1" style={{ fontSize: 20, color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 relative overflow-hidden">
        {!authenticated ? (
          <div className="absolute inset-0 flex items-center justify-center"
            style={{ background: 'rgba(8,12,20,0.92)', backdropFilter: 'blur(8px)', zIndex: 20 }}>
            <div className="card p-8 w-full max-w-md animate-up">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4"
                style={{ background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.3)' }}>
                <svg className="w-6 h-6" style={{ color: '#a78bfa' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h2 className="text-center font-bold text-white mb-1" style={{ fontSize: 16 }}>Shuffle SOAR</h2>
              <p className="text-center mono text-secondary mb-5" style={{ fontSize: 12 }}>
                Enter your Shuffle credentials to access workflow automation
              </p>
              <form onSubmit={handleAuth} className="space-y-3">
                <input className="field" type="text" placeholder="Username" value={creds.u}
                  onChange={e => setCreds(p => ({ ...p, u: e.target.value }))} required />
                <input className="field" type="password" placeholder="Password" value={creds.p}
                  onChange={e => setCreds(p => ({ ...p, p: e.target.value }))} required />
                <button type="submit" disabled={authLoading || !creds.u || !creds.p}
                  className="w-full py-3 rounded-lg font-bold label-caps flex items-center justify-center gap-2 disabled:opacity-40"
                  style={{ background: '#7c3aed', color: 'white', fontSize: 10 }}>
                  {authLoading
                    ? <><div className="w-3.5 h-3.5 border border-white border-t-transparent rounded-full animate-spin" />Authorizing…</>
                    : 'Access Shuffle SOAR'}
                </button>
              </form>
            </div>
          </div>
        ) : (
          <>
            {!iframeLoaded && (
              <div className="absolute inset-0 flex items-center justify-center z-10"
                style={{ background: 'var(--bg-primary)' }}>
                <div className="w-7 h-7 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
              </div>
            )}
            <iframe
              src={SHUFFLE_URL}
              title="Shuffle SOAR"
              className="tool-frame"
              onLoad={() => setLoaded(true)}
            />
          </>
        )}
      </div>
    </div>
  );
}
