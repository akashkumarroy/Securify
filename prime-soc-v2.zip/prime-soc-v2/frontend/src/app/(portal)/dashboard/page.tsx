'use client';
import { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, AreaChart, Area, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

// ── Types ──────────────────────────────────────────────────────
interface AgentSummary { total:number; active:number; disconnected:number; never:number; pending:number; }
interface Alert { id:string; timestamp:string; severity:string; source:string; rule_desc:string; rule_level:number; agent_ip?:string; mitre?:{ id:string[]; technique:string[] }; }
interface DashData { agents:AgentSummary|null; critAlerts:{items:Alert[];total:number}; recentAlerts:Alert[]; }

// ── Severity helpers ───────────────────────────────────────────
const SEV_COLOR: Record<string,string> = { CRITICAL:'#ef4444', HIGH:'#f59e0b', MEDIUM:'#eab308', LOW:'#3b82f6', INFO:'#64748b' };
const SEV_CLASS: Record<string,string> = { CRITICAL:'badge-critical', HIGH:'badge-high', MEDIUM:'badge-medium', LOW:'badge-low', INFO:'badge-info' };

function SevBadge({ s }: { s:string }) {
  return <span className={`badge ${SEV_CLASS[s]??'badge-info'}`}>{s}</span>;
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active||!payload?.length) return null;
  return (
    <div className="card px-3 py-2 rounded-lg" style={{ fontSize:11 }}>
      <p className="text-dim mono mb-1">{label}</p>
      {payload.map((p:any,i:number) => (
        <p key={i} className="mono font-bold" style={{ color:p.color }}>{p.name}: {p.value?.toLocaleString()}</p>
      ))}
    </div>
  );
}

// ── Stat Card ──────────────────────────────────────────────────
function StatCard({ label, value, sub, color, icon }: { label:string;value:string|number;sub?:string;color:string;icon:string }) {
  return (
    <div className="card p-4">
      <div className="flex items-start justify-between mb-3">
        <p className="label-caps text-dim">{label}</p>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background:`${color}15` }}>
          <svg className="w-4 h-4" style={{ color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d={icon}/>
          </svg>
        </div>
      </div>
      <p className="stat-value" style={{ fontSize:28, color }}>{value}</p>
      {sub && <p className="mono text-dim mt-1" style={{ fontSize:10 }}>{sub}</p>}
    </div>
  );
}

// ── Alert Row ──────────────────────────────────────────────────
function AlertRow({ alert }: { alert:Alert }) {
  const t = alert.timestamp ? new Date(alert.timestamp).toLocaleTimeString('en-GB', { hour12:false }) : '—';
  return (
    <tr>
      <td className="mono text-dim" style={{ fontSize:11 }}>{t}</td>
      <td><SevBadge s={alert.severity} /></td>
      <td className="text-white font-medium" style={{ fontSize:12 }}>{alert.source}</td>
      <td className="text-secondary" style={{ fontSize:12, maxWidth:240 }}>
        <span className="truncate block" title={alert.rule_desc}>{alert.rule_desc||'—'}</span>
      </td>
      <td className="mono text-dim" style={{ fontSize:11 }}>{alert.rule_level}</td>
      <td>
        {alert.mitre?.technique?.[0]
          ? <span className="badge badge-info" style={{ fontSize:9 }}>{alert.mitre.technique[0]}</span>
          : <span className="text-dim" style={{ fontSize:11 }}>—</span>}
      </td>
    </tr>
  );
}

// ── MITRE Heatmap ──────────────────────────────────────────────
interface MitreCell { id:string; name:string; count:number; maxLevel:number; }
function MitreHeatmap({ data }: { data:MitreCell[] }) {
  const maxCount = Math.max(...data.map(d=>d.count), 1);
  const getColor = (cell:MitreCell) => {
    if (!cell.count) return 'rgba(255,255,255,0.04)';
    const ratio = cell.count / maxCount;
    if (cell.maxLevel >= 13) return `rgba(239,68,68,${0.3+ratio*0.6})`;
    if (cell.maxLevel >= 10) return `rgba(245,158,11,${0.25+ratio*0.55})`;
    if (cell.maxLevel >= 7)  return `rgba(234,179,8,${0.2+ratio*0.5})`;
    return `rgba(59,130,246,${0.2+ratio*0.4})`;
  };
  return (
    <div className="grid gap-1" style={{ gridTemplateColumns:'repeat(6,1fr)' }}>
      {data.map(cell => (
        <div key={cell.id} title={`${cell.id}: ${cell.name} (${cell.count} hits)`}
          className="rounded cursor-pointer hover:opacity-80 transition-opacity flex flex-col p-1"
          style={{ background:getColor(cell), minHeight:32 }}>
          <span className="mono" style={{ fontSize:7, color:'rgba(255,255,255,0.5)', lineHeight:1 }}>{cell.id}</span>
          {cell.count > 0 && <span className="mono font-bold mt-auto" style={{ fontSize:9, color:'rgba(255,255,255,0.8)' }}>{cell.count}</span>}
        </div>
      ))}
    </div>
  );
}

// ── Main Dashboard ─────────────────────────────────────────────
export default function DashboardPage() {
  const [data, setData]       = useState<DashData|null>(null);
  const [mitre, setMitre]     = useState<MitreCell[]>([]);
  const [allAlerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [epsHistory, setEps]  = useState<{t:string;v:number}[]>([]);

  const fetchAll = useCallback(async () => {
    try {
      const [dash, mitreRes, alertRes] = await Promise.allSettled([
        fetch('/api/wazuh/dashboard').then(r=>r.json()),
        fetch('/api/wazuh/mitre').then(r=>r.json()),
        fetch('/api/wazuh/alerts?limit=100').then(r=>r.json()),
      ]);
      if (dash.status==='fulfilled') setData(dash.value);
      if (mitreRes.status==='fulfilled') setMitre(Array.isArray(mitreRes.value) ? mitreRes.value : []);
      if (alertRes.status==='fulfilled') {
        const alerts: Alert[] = alertRes.value.alerts ?? [];
        setAlerts(alerts);
        // Build EPS history from alert timestamps (last 24 alerts grouped by hour)
        const byHour: Record<string,number> = {};
        alerts.forEach(a => {
          if (!a.timestamp) return;
          const h = new Date(a.timestamp).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',hour12:false});
          byHour[h] = (byHour[h]||0) + 1;
        });
        const eps = Object.entries(byHour).slice(-20).map(([t,v])=>({ t, v }));
        setEps(eps);
      }
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);
  useEffect(() => { const id = setInterval(fetchAll, 30_000); return () => clearInterval(id); }, [fetchAll]);

  const agents  = data?.agents;
  const crit    = data?.critAlerts?.total ?? 0;
  const recent  = allAlerts.slice(0, 15);
  const healthPct = agents && agents.total > 0 ? ((agents.active / agents.total)*100).toFixed(1) : '—';

  // Severity distribution from real alerts
  const sevDist = ['CRITICAL','HIGH','MEDIUM','LOW','INFO'].map(s => ({
    name: s, value: allAlerts.filter(a=>a.severity===s).length, color: SEV_COLOR[s],
  })).filter(d=>d.value>0);

  // Top sources
  const sourceCounts: Record<string,number> = {};
  allAlerts.forEach(a => { if(a.source) sourceCounts[a.source]=(sourceCounts[a.source]||0)+1; });
  const topSources = Object.entries(sourceCounts).sort((a,b)=>b[1]-a[1]).slice(0,8)
    .map(([name,count])=>({ name, count }));

  if (loading) return (
    <div className="flex items-center justify-center h-full">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="mono text-secondary" style={{ fontSize:12 }}>Fetching live data from Wazuh…</p>
      </div>
    </div>
  );

  return (
    <div className="p-5 space-y-4 animate-fade">

      {/* ── Row 1: KPI Cards ──────────────────────────── */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard label="Total Agents"    value={agents?.total??0}          sub={`${agents?.active??0} active`}         color="var(--cyan)"   icon="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"/>
        <StatCard label="Critical Alerts" value={crit}                       sub="Level 12–15 severity"                  color="#ef4444"        icon="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
        <StatCard label="Endpoint Health" value={`${healthPct}%`}            sub={`${agents?.disconnected??0} disconnected`} color="var(--green)" icon="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        <StatCard label="Total Events"    value={allAlerts.length>0?allAlerts.length+'+':`${data?.critAlerts?.total??0}`}  sub="Last 100 fetched"  color="#a78bfa"        icon="M13 10V3L4 14h7v7l9-11h-7z"/>
      </div>

      {/* ── Row 2: Alert Volume + Severity Pie ───────── */}
      <div className="grid grid-cols-3 gap-4">
        {/* Alert Volume Bar Chart */}
        <div className="col-span-2 card p-4">
          <div className="flex items-center justify-between mb-4">
            <p className="label-caps text-secondary">Alert Volume by Time</p>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live" />
              <span className="mono text-dim" style={{ fontSize:10 }}>Live — updates every 30s</span>
            </div>
          </div>
          <div style={{ height:160 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={epsHistory} barSize={8} margin={{ top:0, right:0, bottom:0, left:0 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="t" hide />
                <YAxis hide />
                <Tooltip content={<CustomTooltip />} cursor={{ fill:'rgba(0,216,232,0.04)' }} />
                <Bar dataKey="v" name="Events" fill="var(--cyan)" radius={[3,3,0,0]} opacity={0.8}/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Severity Distribution */}
        <div className="card p-4">
          <p className="label-caps text-secondary mb-4">Severity Distribution</p>
          {sevDist.length > 0 ? (
            <>
              <div style={{ height:140 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={sevDist} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                      dataKey="value" stroke="none">
                      {sevDist.map((d,i) => <Cell key={i} fill={d.color} />)}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1 mt-2">
                {sevDist.map(d => (
                  <div key={d.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-sm" style={{ background:d.color }} />
                      <span className="mono text-secondary" style={{ fontSize:10 }}>{d.name}</span>
                    </div>
                    <span className="mono font-bold" style={{ fontSize:11, color:d.color }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-40">
              <p className="mono text-dim" style={{ fontSize:11 }}>No alert data available</p>
            </div>
          )}
        </div>
      </div>

      {/* ── Row 3: MITRE Heatmap + Top Sources ───────── */}
      <div className="grid grid-cols-3 gap-4">
        {/* MITRE ATT&CK */}
        <div className="col-span-2 card p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="label-caps text-secondary">MITRE ATT&amp;CK Heatmap</p>
            <span className="badge badge-info">{mitre.length} Techniques Detected</span>
          </div>
          {mitre.length > 0 ? (
            <>
              <MitreHeatmap data={mitre} />
              <div className="flex items-center gap-4 mt-3">
                {[
                  { label:'Critical (L13+)', color:'rgba(239,68,68,0.7)' },
                  { label:'High (L10+)',     color:'rgba(245,158,11,0.7)' },
                  { label:'Medium (L7+)',    color:'rgba(234,179,8,0.6)' },
                  { label:'Low',            color:'rgba(59,130,246,0.5)' },
                ].map(l => (
                  <div key={l.label} className="flex items-center gap-1">
                    <div className="w-2.5 h-2.5 rounded-sm" style={{ background:l.color }} />
                    <span className="mono text-dim" style={{ fontSize:9 }}>{l.label}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center" style={{ height:120 }}>
              <p className="mono text-dim" style={{ fontSize:11 }}>No MITRE technique data. Alerts may not have MITRE tags.</p>
            </div>
          )}
        </div>

        {/* Top Alert Sources */}
        <div className="card p-4">
          <p className="label-caps text-secondary mb-4">Top Alert Sources</p>
          <div className="space-y-2">
            {topSources.length > 0 ? topSources.map((s,i) => {
              const max = topSources[0].count;
              return (
                <div key={s.name}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-secondary truncate" style={{ fontSize:11, maxWidth:140 }} title={s.name}>{s.name}</span>
                    <span className="mono font-bold text-white" style={{ fontSize:11 }}>{s.count}</span>
                  </div>
                  <div className="rounded-full overflow-hidden" style={{ height:3, background:'rgba(255,255,255,0.06)' }}>
                    <div className="h-full rounded-full" style={{ width:`${(s.count/max)*100}%`, background:'var(--cyan)' }} />
                  </div>
                </div>
              );
            }) : (
              <p className="mono text-dim" style={{ fontSize:11 }}>No data</p>
            )}
          </div>
        </div>
      </div>

      {/* ── Row 4: Agent Status + Recent Alerts ──────── */}
      <div className="grid grid-cols-3 gap-4">
        {/* Agent Status Breakdown */}
        <div className="card p-4">
          <p className="label-caps text-secondary mb-4">Agent Status</p>
          {agents ? (
            <div className="space-y-3">
              {[
                { label:'Active',       value:agents.active,       color:'var(--green)', pct:agents.total?((agents.active/agents.total)*100):0 },
                { label:'Disconnected', value:agents.disconnected, color:'var(--red)',   pct:agents.total?((agents.disconnected/agents.total)*100):0 },
                { label:'Pending',      value:agents.pending,      color:'var(--amber)', pct:agents.total?((agents.pending/agents.total)*100):0 },
                { label:'Never Connected', value:agents.never,     color:'var(--text-dim)', pct:agents.total?((agents.never/agents.total)*100):0 },
              ].map(r => (
                <div key={r.label}>
                  <div className="flex justify-between mb-1">
                    <span className="text-secondary" style={{ fontSize:12 }}>{r.label}</span>
                    <span className="mono font-bold" style={{ color:r.color, fontSize:12 }}>{r.value}</span>
                  </div>
                  <div className="rounded-full overflow-hidden" style={{ height:4, background:'rgba(255,255,255,0.05)' }}>
                    <div style={{ width:`${r.pct}%`, height:'100%', background:r.color, borderRadius:4, transition:'width 0.6s' }} />
                  </div>
                </div>
              ))}
              <div className="pt-2 border-t" style={{ borderColor:'var(--border)' }}>
                <div className="flex justify-between">
                  <span className="label-caps text-dim">Total</span>
                  <span className="mono font-bold text-white">{agents.total}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="skeleton h-32 rounded-lg" />
          )}
        </div>

        {/* Real-time Alert Feed */}
        <div className="col-span-2 card flex flex-col" style={{ maxHeight:320 }}>
          <div className="flex items-center justify-between px-4 py-3 border-b shrink-0" style={{ borderColor:'var(--border)' }}>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 dot-live" />
              <p className="label-caps text-secondary">Real-time Alert Feed</p>
            </div>
            <div className="flex gap-2">
              <span className="badge badge-critical">{crit} CRITICAL</span>
              <span className="badge badge-info">{allAlerts.length} TOTAL</span>
            </div>
          </div>
          <div className="overflow-auto flex-1">
            {recent.length > 0 ? (
              <table className="data-table">
                <thead><tr><th>Time</th><th>Severity</th><th>Agent</th><th>Rule Description</th><th>Level</th><th>MITRE</th></tr></thead>
                <tbody>{recent.map(a => <AlertRow key={a.id} alert={a} />)}</tbody>
              </table>
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="mono text-dim" style={{ fontSize:12 }}>No alerts fetched. Check Wazuh API connection.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
