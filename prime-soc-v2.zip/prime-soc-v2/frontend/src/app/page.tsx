'use client';

import { Suspense, useState, useEffect, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

// ── Inner form — wrapped in Suspense to fix useSearchParams error ──
function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [time, setTime]         = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const tick = () => setTime(new Date().toUTCString().split(' ')[4] + ' UTC');
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  // Subtle particle canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let raf: number;
    const particles: { x:number;y:number;vx:number;vy:number;life:number }[] = [];
    let mouse = { x: -999, y: -999 };

    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; });

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const g = ctx.createRadialGradient(mouse.x, mouse.y, 0, mouse.x, mouse.y, 280);
      g.addColorStop(0, 'rgba(0,216,232,0.035)');
      g.addColorStop(1, 'transparent');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (Math.random() < 0.2) {
        particles.push({
          x: mouse.x + (Math.random()-0.5)*120,
          y: mouse.y + (Math.random()-0.5)*120,
          vx: (Math.random()-0.5)*0.4,
          vy: -Math.random()*0.6,
          life: 1,
        });
      }
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx; p.y += p.vy; p.life -= 0.018;
        if (p.life <= 0) { particles.splice(i, 1); continue; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0,216,232,${p.life * 0.35})`;
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim().toLowerCase(), password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? 'Authentication failed'); return; }
      const redirect = searchParams.get('redirect') ?? '/dashboard';
      router.push(redirect);
      router.refresh();
    } catch { setError('Connection error. Check network.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col items-center justify-center p-6 bg-grid"
      style={{ background: 'var(--bg-primary)' }}>

      {/* Grid bg */}
      <div className="fixed inset-0 bg-grid opacity-60 pointer-events-none" />
      <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />

      {/* Ambient orbs */}
      <div className="fixed top-[-15%] left-[-10%] w-[50%] h-[50%] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(0,216,232,0.06) 0%, transparent 70%)', filter: 'blur(40px)' }} />
      <div className="fixed bottom-[-15%] right-[-10%] w-[50%] h-[50%] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(124,58,237,0.06) 0%, transparent 70%)', filter: 'blur(40px)' }} />

      <main className="relative z-10 w-full max-w-[420px] animate-up">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center glow-cyan"
              style={{ background: 'rgba(0,216,232,0.12)', border: '1px solid rgba(0,216,232,0.3)' }}>
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
                <path d="M12 2L3 6v6c0 5.5 3.8 10.7 9 12 5.2-1.3 9-6.5 9-12V6l-9-4z"
                  fill="rgba(0,216,232,0.2)" stroke="var(--cyan)" strokeWidth="1.5" />
                <path d="M9 12l2 2 4-4" stroke="var(--cyan)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <span className="text-xl font-bold tracking-tight text-white">Prime SOC</span>
          </div>
          <p className="label-caps text-dim">Advanced Cyber Defense Terminal</p>
        </div>

        {/* Card */}
        <div className="card relative overflow-hidden" style={{ padding: '28px 32px' }}>
          <div className="scan-line" />

          <div className="flex justify-between items-center mb-6">
            <span className="label-caps text-secondary">Authentication Required</span>
            <span className="mono text-dim" style={{ fontSize: 10 }}>v2.0.0</span>
          </div>

          {error && (
            <div className="mb-5 px-3 py-2.5 rounded-lg flex items-center gap-2 animate-fade"
              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)' }}>
              <div className="w-1.5 h-1.5 rounded-full bg-red-400 shrink-0" />
              <p className="mono text-red-400" style={{ fontSize: 12 }}>{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label-caps text-dim block mb-2">Operator ID</label>
              <input className="field" type="text" placeholder="Enter username"
                value={username} onChange={e => setUsername(e.target.value)}
                autoComplete="username" required />
            </div>
            <div>
              <label className="label-caps text-dim block mb-2">Access Key</label>
              <input className="field" type="password" placeholder="••••••••••••"
                value={password} onChange={e => setPassword(e.target.value)}
                autoComplete="current-password" required />
            </div>

            {/* Status indicator */}
            <div className="flex items-center gap-2.5 py-2.5 px-3 rounded-lg"
              style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)' }}>
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live" />
              <span className="mono text-secondary" style={{ fontSize: 11 }}>Wazuh IAM Active — Credentials validated against SIEM</span>
            </div>

            <button type="submit" disabled={loading || !username || !password}
              className="w-full py-3 rounded-lg font-bold tracking-wide transition-all flex items-center justify-center gap-2 disabled:opacity-40"
              style={{ background: 'var(--cyan)', color: '#001a1e', fontSize: 13 }}>
              {loading
                ? <><svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>Authenticating…</>
                : <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"/></svg>SECURE LOGIN</>
              }
            </button>
          </form>

          <div className="flex justify-between items-center mt-5">
            <span className="mono text-dim" style={{ fontSize: 10 }}>Restricted System</span>
            <span className="mono text-dim" style={{ fontSize: 10 }}>{time}</span>
          </div>
        </div>

        <p className="text-center mono text-dim mt-5 leading-relaxed" style={{ fontSize: 10 }}>
          Unauthorized access is prohibited. All activity is monitored and logged.
        </p>
      </main>

      {/* Footer bar */}
      <div className="fixed bottom-0 left-0 right-0 flex justify-between items-center px-5"
        style={{ height: 'var(--footer-h)', background: 'rgba(8,12,20,0.9)', borderTop: '1px solid var(--border)', backdropFilter: 'blur(8px)' }}>
        <span className="mono text-green-400 flex items-center gap-1.5" style={{ fontSize: 10 }}>
          <span className="w-1.5 h-1.5 rounded-full bg-green-400 dot-live" />SYSTEM NOMINAL
        </span>
        <span className="mono text-dim" style={{ fontSize: 10 }}>ENCRYPTED · STABLE</span>
      </div>
    </div>
  );
}

// ── Page export — wraps LoginForm in Suspense ──────────────────
export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg-primary)' }}>
        <div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
      </div>
    }>
      <LoginForm />
    </Suspense>
  );
}
