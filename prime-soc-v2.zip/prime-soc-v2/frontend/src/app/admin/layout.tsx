import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
import TopBar from '@/components/layout/TopBar';
import Sidebar from '@/components/layout/Sidebar';
import FooterBar from '@/components/layout/FooterBar';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const store = cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) redirect('/');
  const payload = await verifyToken(token);
  if (!payload || payload.role !== 'admin') redirect('/dashboard');

  const user = await queryOne<{ id:string; wazuh_username:string; portal_role:string; full_name:string|null; tenant_id:string|null; }>(
    `SELECT id, wazuh_username, portal_role, full_name, tenant_id FROM portal_users WHERE id = $1 AND is_active = true`,
    [payload.sub],
  );
  if (!user) redirect('/');

  const ctx = { id: user.id, username: user.wazuh_username, role: user.portal_role, full_name: user.full_name ?? user.wazuh_username, tenant_id: user.tenant_id, wazuh_group: null };

  return (
    <div className="portal-grid">
      <TopBar user={ctx} className="area-top" />
      <Sidebar user={ctx} className="area-side" />
      <main className="area-main" style={{ background: 'var(--bg-primary)' }}>{children}</main>
      <FooterBar className="area-foot" />
    </div>
  );
}
