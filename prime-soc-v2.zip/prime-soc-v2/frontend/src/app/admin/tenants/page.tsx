'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Tenant { id:string; name:string; wazuh_group:string; industry?:string; status:string; created_at:string; }

const STATUS_STYLE: Record<string, { color:string; bg:string }> = {
  active:   { color:'var(--green)', bg:'rgba(16,185,129,0.12)' },
  warning:  { color:'var(--amber)', bg:'rgba(245,158,11,0.12)' },
  critical: { color:'var(--red)',   bg:'rgba(239,68,68,0.12)' },
  inactive: { color:'var(--text-dim)', bg:'rgba(71,85,105,0.1)' },
};

export default function AdminTenantsPage() {
  const router = useRouter();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [wazuhGroups, setWazuhGroups] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name:'', wazuh_group:'', industry:'' });
  const [error, setError] = useState('');

  const fetchAll = async () => {
    const [tr, gr] = await Promise.allSettled([
      fetch('/api/tenants').then(r=>r.json()),
      fetch('/api/tenants/groups').then(r=>r.json()),
    ]);
    if (tr.status==='fulfilled') setTenants(tr.value.tenants??[]);
    if (gr.status==='fulfilled') setWazuhGroups(gr.value.groups??[]);
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true); setError('');
    try {
      const res = await fetch('/api/tenants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? 'Failed'); return; }
      setShowCreate(false);
      setForm({ name:'', wazuh_group:'', industry:'' });
      fetchAll();
    } finally { setCreating(false); }
  };

  const filtered = tenants.filter(t =>
    !filter || t.name.toLowerCase().includes(filter.toLowerCase()) || t.wazuh_group.toLowerCase().includes(filter.toLowerCase())
  );

  // Groups not yet mapped to tenants
  const unmappedGroups = wazuhGroups.filter(g => !tenants.some(t => t.wazuh_group === g) && g !== 'default');

  return (
    <div className="p-5 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-white" style={{ fontSize:24, letterSpacing:'-0.02em' }}>Tenant Management</h1>
          <p className="mono text-secondary mt-0.5" style={{ fontSize:11 }}>
            {tenants.length} configured tenants · {wazuhGroups.length} Wazuh groups found
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <input value={filter} onChange={e=>setFilter(e.target.value)}
              className="field pl-8 py-1.5" style={{ fontSize:12, width:200 }}
              placeholder="Filter tenants…" />
            <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
          </div>
          <button onClick={()=>{setShowCreate(true);setError('');}}
            className="label-caps px-4 py-2 rounded-lg" style={{ background:'var(--cyan)', color:'#001a1e', fontSize:9 }}>
            + Onboard Tenant
          </button>
        </div>
      </div>

      {/* Unmapped Wazuh groups notice */}
      {unmappedGroups.length > 0 && (
        <div className="rounded-xl p-4 flex items-start gap-3"
          style={{ background:'rgba(245,158,11,0.08)', border:'1px solid rgba(245,158,11,0.2)' }}>
          <svg className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
          <div>
            <p className="font-semibold text-amber-400" style={{ fontSize:13 }}>
              {unmappedGroups.length} Wazuh group{unmappedGroups.length>1?'s':''} not yet mapped to tenants
            </p>
            <p className="mono text-secondary mt-1" style={{ fontSize:11 }}>
              Groups: {unmappedGroups.slice(0,5).join(', ')}{unmappedGroups.length>5?`…+${unmappedGroups.length-5} more`:''}
            </p>
          </div>
        </div>
      )}

      {/* Tenant Grid */}
      {loading ? (
        <div className="grid grid-cols-4 gap-4">
          {[1,2,3,4].map(i=><div key={i} className="skeleton h-48 rounded-xl"/>)}
        </div>
      ) : (
        <div className="grid grid-cols-4 gap-4">
          {filtered.map(tenant => {
            const st = STATUS_STYLE[tenant.status] ?? STATUS_STYLE.active;
            return (
              <div key={tenant.id} className="card-hover p-5 flex flex-col rounded-xl">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm"
                    style={{ background:'rgba(255,255,255,0.05)', color:'var(--text-secondary)' }}>
                    {tenant.name.slice(0,2).toUpperCase()}
                  </div>
                  <span className="label-caps px-2 py-0.5 rounded-full"
                    style={{ fontSize:8, background:st.bg, color:st.color }}>
                    {tenant.status}
                  </span>
                </div>
                <h3 className="font-bold text-white mb-0.5" style={{ fontSize:14 }}>{tenant.name}</h3>
                <p className="mono text-secondary mb-1" style={{ fontSize:10 }}>Group: {tenant.wazuh_group}</p>
                {tenant.industry && <p className="mono text-dim mb-3" style={{ fontSize:10 }}>{tenant.industry}</p>}
                <p className="mono text-dim mt-auto" style={{ fontSize:9 }}>
                  Created {new Date(tenant.created_at).toLocaleDateString()}
                </p>
                <button onClick={()=>router.push('/dashboard')}
                  className="mt-3 w-full py-1.5 rounded-lg label-caps transition-colors"
                  style={{ border:'1px solid var(--border)', color:'var(--text-secondary)', fontSize:8 }}>
                  Access Portal →
                </button>
              </div>
            );
          })}

          {/* Add new */}
          <div onClick={()=>{setShowCreate(true);setError('');}}
            className="card-hover p-5 flex flex-col items-center justify-center rounded-xl cursor-pointer min-h-[192px]"
            style={{ border:'1px dashed rgba(255,255,255,0.1)' }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
              style={{ background:'rgba(255,255,255,0.04)' }}>
              <svg className="w-5 h-5 text-dim" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4v16m8-8H4"/>
              </svg>
            </div>
            <p className="font-semibold text-secondary" style={{ fontSize:13 }}>Onboard New Tenant</p>
            <p className="mono text-dim mt-1" style={{ fontSize:10 }}>Deploy fresh SOC environment</p>
          </div>
        </div>
      )}

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background:'rgba(0,0,0,0.75)', backdropFilter:'blur(8px)' }}>
          <div className="card p-7 w-full max-w-md rounded-2xl animate-up">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-white" style={{ fontSize:16 }}>Onboard New Tenant</h3>
              <button onClick={()=>setShowCreate(false)} className="text-dim hover:text-white">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
                </svg>
              </button>
            </div>
            {error && (
              <div className="mb-4 px-3 py-2 rounded-lg mono" style={{ background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.25)', color:'#fca5a5', fontSize:12 }}>
                {error}
              </div>
            )}
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Tenant Name *</label>
                <input className="field" placeholder="e.g. Acme Corp" value={form.name}
                  onChange={e=>setForm(p=>({...p,name:e.target.value}))} required/>
              </div>
              <div>
                <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Wazuh Agent Group *</label>
                {wazuhGroups.length > 0 ? (
                  <select className="field" value={form.wazuh_group}
                    onChange={e=>setForm(p=>({...p,wazuh_group:e.target.value}))} required>
                    <option value="">Select existing group…</option>
                    {wazuhGroups.filter(g=>g!=='default').map(g=>(
                      <option key={g} value={g}>{g}</option>
                    ))}
                    <option value="__new__">— Create new group —</option>
                  </select>
                ) : (
                  <input className="field" placeholder="e.g. Acme_Corp" value={form.wazuh_group}
                    onChange={e=>setForm(p=>({...p,wazuh_group:e.target.value}))} required/>
                )}
                <p className="mono text-dim mt-1" style={{ fontSize:9 }}>Must match the Wazuh agent group name exactly</p>
              </div>
              <div>
                <label className="label-caps text-dim block mb-1.5" style={{ fontSize:8 }}>Industry</label>
                <input className="field" placeholder="e.g. Financial Technology" value={form.industry}
                  onChange={e=>setForm(p=>({...p,industry:e.target.value}))}/>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={()=>setShowCreate(false)}
                  className="flex-1 py-2.5 rounded-lg label-caps text-secondary" style={{ border:'1px solid var(--border)', fontSize:9 }}>
                  Cancel
                </button>
                <button type="submit" disabled={creating}
                  className="flex-1 py-2.5 rounded-lg label-caps disabled:opacity-40" style={{ background:'var(--cyan)', color:'#001a1e', fontSize:9 }}>
                  {creating ? 'Creating…' : 'Deploy Environment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
