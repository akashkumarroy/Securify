import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import https from 'https';
export const runtime = 'nodejs';
export async function GET(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(request.url);
  const statsOnly = searchParams.get('stats') === 'true';
  try {
    const agent = new https.Agent({ rejectUnauthorized: false });
    const IRIS = process.env.IRIS_URL!;
    const KEY  = process.env.IRIS_API_KEY!;
    const res = await fetch(`${IRIS}/manage/cases/list`, { headers: { Authorization: `Bearer ${KEY}` }, ...(IRIS.startsWith('https') ? { agent } as any : {}) });
    if (!res.ok) throw new Error(`IRIS ${res.status}`);
    const data = await res.json();
    const cases: any[] = data?.data?.cases ?? [];
    if (statsOnly) {
      return NextResponse.json({
        total: cases.length,
        open: cases.filter((c:any) => c.state_name !== 'Closed').length,
        in_progress: cases.filter((c:any) => c.state_name === 'In Progress').length,
        closed: cases.filter((c:any) => c.state_name === 'Closed').length,
      });
    }
    return NextResponse.json({ cases });
  } catch (err) {
    return NextResponse.json({ total:0, open:0, in_progress:0, closed:0, error: String(err) });
  }
}
