import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { query } from '@/lib/db';
import bcrypt from 'bcryptjs';

export const runtime = 'nodejs';

function auth(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export async function GET(request: NextRequest) {
  const payload = await auth(request);
  if (!payload || payload.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const users = await query(
    `SELECT pu.id, pu.wazuh_username, pu.portal_role, pu.full_name, pu.email,
            pu.is_active, pu.last_login, pu.created_at,
            t.name AS tenant_name, t.wazuh_group
     FROM portal_users pu LEFT JOIN tenants t ON t.id = pu.tenant_id
     ORDER BY pu.created_at DESC`,
  );
  return NextResponse.json({ users });
}

export async function POST(request: NextRequest) {
  const payload = await auth(request);
  if (!payload || payload.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const { wazuh_username, portal_role, tenant_id, full_name, email } = await request.json();
  if (!wazuh_username) return NextResponse.json({ error: 'wazuh_username required' }, { status: 400 });
  try {
    const [user] = await query(
      `INSERT INTO portal_users (wazuh_username, portal_role, tenant_id, full_name, email)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [wazuh_username.toLowerCase(), portal_role ?? 'client', tenant_id || null, full_name || null, email || null],
    );
    return NextResponse.json({ user }, { status: 201 });
  } catch (err: any) {
    if (err.code === '23505') return NextResponse.json({ error: 'Username already registered' }, { status: 409 });
    throw err;
  }
}
