import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { query } from '@/lib/db';
export const runtime = 'nodejs';
export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload || payload.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  const body = await request.json();
  const sets: string[] = []; const vals: unknown[] = []; let i = 1;
  if (body.is_active !== undefined) { sets.push(`is_active = $${i++}`); vals.push(body.is_active); }
  if (body.portal_role) { sets.push(`portal_role = $${i++}`); vals.push(body.portal_role); }
  if (body.tenant_id !== undefined) { sets.push(`tenant_id = $${i++}`); vals.push(body.tenant_id || null); }
  if (body.full_name) { sets.push(`full_name = $${i++}`); vals.push(body.full_name); }
  if (!sets.length) return NextResponse.json({ error: 'Nothing to update' }, { status: 400 });
  vals.push(params.id);
  const [user] = await query(`UPDATE portal_users SET ${sets.join(',')} WHERE id = $${i} RETURNING *`, vals);
  return NextResponse.json({ user });
}
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload || payload.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  if (params.id === payload.sub) return NextResponse.json({ error: 'Cannot delete yourself' }, { status: 400 });
  await query(`DELETE FROM portal_users WHERE id = $1`, [params.id]);
  return NextResponse.json({ success: true });
}
