import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
export const runtime = 'nodejs';
export async function GET(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const user = await queryOne(
    `SELECT pu.*, t.name AS tenant_name, t.wazuh_group FROM portal_users pu LEFT JOIN tenants t ON t.id = pu.tenant_id WHERE pu.id = $1`,
    [payload.sub]
  );
  if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ user });
}
