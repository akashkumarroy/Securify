import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import https from 'https';

// Map of proxy prefixes to target URLs
function getTarget(toolPrefix: string): string | null {
  switch (toolPrefix) {
    case 'wazuh':   return process.env.WAZUH_DASHBOARD_URL ?? null;
    case 'opencti': return process.env.OPENCTI_URL ?? null;
    case 'iris':    return process.env.IRIS_URL ?? null;
    case 'shuffle': return process.env.SHUFFLE_URL ?? null;
    default: return null;
  }
}

// Node.js runtime required for https agent
export const runtime = 'nodejs';

export async function GET(
  request: NextRequest,
  { params }: { params: { path: string[] } },
) {
  // Auth check
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const payload = await verifyToken(token);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const [tool, ...rest] = params.path;
  const targetBase = getTarget(tool);
  if (!targetBase) return NextResponse.json({ error: 'Unknown tool' }, { status: 404 });

  const targetPath = '/' + rest.join('/');
  const targetUrl  = targetBase.replace(/\/$/, '') + targetPath +
    (request.nextUrl.search ? request.nextUrl.search : '');

  try {
    const agent = new https.Agent({ rejectUnauthorized: false });

    // Forward relevant headers
    const headers: Record<string, string> = {};
    ['accept', 'accept-encoding', 'accept-language', 'cookie'].forEach(h => {
      const v = request.headers.get(h);
      if (v) headers[h] = v;
    });

    const res = await fetch(targetUrl, {
      headers,
      redirect: 'follow',
      // @ts-ignore
      agent: targetUrl.startsWith('https') ? agent : undefined,
    });

    // Build response, stripping frame-blocking headers
    const responseHeaders = new Headers();
    res.headers.forEach((value, key) => {
      const lower = key.toLowerCase();
      if (lower === 'x-frame-options') return;
      if (lower === 'content-security-policy') return;
      if (lower === 'x-content-security-policy') return;
      responseHeaders.set(key, value);
    });
    // Allow embedding in our portal
    responseHeaders.set('x-frame-options', 'ALLOWALL');

    return new NextResponse(res.body, {
      status: res.status,
      headers: responseHeaders,
    });
  } catch (err) {
    console.error(`[PROXY ${tool}]`, err);
    return NextResponse.json({ error: `Failed to reach ${tool}` }, { status: 502 });
  }
}

// Also handle POST (for form submissions inside iframes)
export async function POST(
  request: NextRequest,
  { params }: { params: { path: string[] } },
) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const payload = await verifyToken(token);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const [tool, ...rest] = params.path;
  const targetBase = getTarget(tool);
  if (!targetBase) return NextResponse.json({ error: 'Unknown tool' }, { status: 404 });

  const targetUrl = targetBase.replace(/\/$/, '') + '/' + rest.join('/');
  const agent = new https.Agent({ rejectUnauthorized: false });
  const body = await request.text();

  try {
    const res = await fetch(targetUrl, {
      method: 'POST',
      headers: { 'content-type': request.headers.get('content-type') ?? 'application/json' },
      body,
      // @ts-ignore
      agent: targetUrl.startsWith('https') ? agent : undefined,
    });

    const responseHeaders = new Headers();
    res.headers.forEach((v, k) => {
      if (!['x-frame-options','content-security-policy'].includes(k.toLowerCase()))
        responseHeaders.set(k, v);
    });

    return new NextResponse(res.body, { status: res.status, headers: responseHeaders });
  } catch {
    return NextResponse.json({ error: 'Proxy error' }, { status: 502 });
  }
}
