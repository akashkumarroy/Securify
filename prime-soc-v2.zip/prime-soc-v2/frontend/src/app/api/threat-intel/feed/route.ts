import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
export const runtime = 'nodejs';
async function gql(query: string) {
  const res = await fetch(`${process.env.OPENCTI_URL}/graphql`, {
    method: 'POST',
    headers: { 'Content-Type':'application/json', Authorization:`Bearer ${process.env.OPENCTI_API_KEY}` },
    body: JSON.stringify({ query }),
  });
  if (!res.ok) throw new Error(`OpenCTI ${res.status}`);
  const json = await res.json() as any;
  return json.data;
}
export async function GET(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const type = new URL(request.url).searchParams.get('type') ?? 'actors';
  try {
    if (type === 'actors') {
      const data = await gql(`query { threatActors(first: 20, orderBy: modified, orderMode: desc) { edges { node { id name description threat_actor_types } } } }`);
      return NextResponse.json({ actors: data?.threatActors?.edges?.map((e:any)=>e.node) ?? [] });
    }
    if (type === 'indicators') {
      const data = await gql(`query { indicators(first: 30, orderBy: modified, orderMode: desc) { edges { node { id name pattern_type x_opencti_score } } } }`);
      return NextResponse.json({ indicators: data?.indicators?.edges?.map((e:any)=>e.node) ?? [] });
    }
    return NextResponse.json({ error: 'Invalid type' }, { status: 400 });
  } catch (err) {
    return NextResponse.json({ actors:[], indicators:[], error: String(err) });
  }
}
