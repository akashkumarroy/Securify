import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getAgents } from '@/lib/wazuh';
export const runtime = 'nodejs';
export async function GET(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const payload = token ? await verifyToken(token) : null;
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const group = payload.role === 'admin' ? undefined : (payload.wazuh_group as string | undefined);
  try {
    const data = await getAgents(group);
    return NextResponse.json({ agents: data.items, total: data.total });
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 502 });
  }
}
