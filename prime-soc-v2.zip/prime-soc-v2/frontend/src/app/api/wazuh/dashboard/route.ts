import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getDashboardData, getMitreStats, getVulnerabilityStats, getComplianceStats } from '@/lib/wazuh';

export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const payload = await verifyToken(token);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const wazuhGroup = payload.role === 'admin' ? undefined : (payload.wazuh_group as string | undefined);

  try {
    const data = await getDashboardData(wazuhGroup);
    return NextResponse.json(data);
  } catch (err) {
    console.error('[WAZUH DASHBOARD]', err);
    return NextResponse.json({ error: String(err) }, { status: 502 });
  }
}
