-- Prime SOC Portal Database Schema
-- PostgreSQL 16+

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- TENANTS
-- ============================================================
CREATE TABLE IF NOT EXISTS tenants (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          VARCHAR(200) NOT NULL,
  uid           VARCHAR(50) UNIQUE NOT NULL,        -- e.g. FT-1102-G
  wazuh_group   VARCHAR(100) NOT NULL,              -- Wazuh agent group name
  wazuh_tenant  VARCHAR(100),                       -- OpenSearch security tenant
  industry      VARCHAR(100),
  status        VARCHAR(50) NOT NULL DEFAULT 'active', -- active | warning | critical | inactive
  threat_score  INT NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tenants_uid ON tenants(uid);
CREATE INDEX idx_tenants_status ON tenants(status);

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username      VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  email         VARCHAR(255),
  full_name     VARCHAR(200),
  role          VARCHAR(50) NOT NULL DEFAULT 'client', -- admin | client
  tenant_id     UUID REFERENCES tenants(id) ON DELETE SET NULL,
  is_active     BOOLEAN NOT NULL DEFAULT true,
  last_login    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_tenant ON users(tenant_id);
CREATE INDEX idx_users_role ON users(role);

-- ============================================================
-- SESSIONS (for JWT revocation / audit)
-- ============================================================
CREATE TABLE IF NOT EXISTS sessions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_jti   VARCHAR(100) UNIQUE NOT NULL, -- JWT ID for revocation
  ip_address  VARCHAR(50),
  user_agent  TEXT,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_jti ON sessions(token_jti);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

-- ============================================================
-- AUDIT LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  username    VARCHAR(100),
  action      VARCHAR(200) NOT NULL,
  resource    VARCHAR(200),
  details     JSONB,
  ip_address  VARCHAR(50),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_action ON audit_logs(action);
CREATE INDEX idx_audit_created ON audit_logs(created_at);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  tenant_id   UUID REFERENCES tenants(id) ON DELETE CASCADE,
  type        VARCHAR(50) NOT NULL, -- alert | incident | system | info
  severity    VARCHAR(20) NOT NULL DEFAULT 'info', -- critical | high | medium | low | info
  title       VARCHAR(300) NOT NULL,
  message     TEXT,
  is_read     BOOLEAN NOT NULL DEFAULT false,
  metadata    JSONB,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notif_user ON notifications(user_id);
CREATE INDEX idx_notif_tenant ON notifications(tenant_id);
CREATE INDEX idx_notif_read ON notifications(is_read);

-- ============================================================
-- AUTO-UPDATE updated_at TRIGGER
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_tenants_updated_at
  BEFORE UPDATE ON tenants
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- SEED DATA — Default admin user + example tenants
-- ============================================================

-- Insert demo tenants
INSERT INTO tenants (name, uid, wazuh_group, industry, status, threat_score) VALUES
  ('AeroSpace Corp',  'AS-9920-X', 'AeroSpace_Corp',  'Aerospace & Defense',    'active',   14),
  ('FinTech Global',  'FT-1102-G', 'FinTech_Global',  'Financial Technology',   'critical', 89),
  ('HealthSecure',    'HS-5541-M', 'HealthSecure',    'Healthcare & Life Sci.', 'warning',  42),
  ('Quantum Logic',   'QL-0081-Z', 'Quantum_Logic',   'Technology & Software',  'active',    2),
  ('DataStream Inc',  'DS-8872-P', 'DataStream_Inc',  'Data & Analytics',       'active',   21)
ON CONFLICT (uid) DO NOTHING;

-- Default admin user: admin / PrimeSoc@Admin123!
-- Password hash for: PrimeSoc@Admin123!
INSERT INTO users (username, password_hash, email, full_name, role, tenant_id)
VALUES (
  'admin',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeAkBb6sVjyKJx1/u',
  'admin@primesoc.local',
  'SOC Commander',
  'admin',
  NULL
)
ON CONFLICT (username) DO NOTHING;

-- Example client user for FinTech Global tenant
INSERT INTO users (username, password_hash, email, full_name, role, tenant_id)
SELECT
  'fintech_ops',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeAkBb6sVjyKJx1/u',
  'ops@fintechglobal.local',
  'FinTech Operator',
  'client',
  id
FROM tenants WHERE uid = 'FT-1102-G'
ON CONFLICT (username) DO NOTHING;
