# Prime SOC Portal

**Production-ready unified SOC customer portal** for enterprise MSSP operations.

## Stack
| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14 (App Router, Server Components) |
| Backend APIs | Next.js Route Handlers (Node.js) |
| Database | PostgreSQL 16 |
| Reverse Proxy | Nginx (iframe proxy, header stripping) |
| Deployment | Docker Compose |
| Design System | Tailwind CSS + JetBrains Mono + Inter |

## Integrated Tools
- **Wazuh** — SIEM, agent management, alerts (embedded + API)
- **OpenCTI** — Threat intelligence (embedded iframe + GraphQL API)
- **Shuffle** — SOAR automation (embedded iframe + REST API)
- **IRIS** — Case management (embedded iframe + REST API)
- **MISP** — Threat feeds (REST API)

---

## Quick Start

### 1. Clone and configure
```bash
git clone <repo> prime-soc-portal
cd prime-soc-portal
cp .env.example .env
```

Edit `.env` with your values:
```bash
nano .env
```

**Required values to change:**
```
POSTGRES_PASSWORD=your_secure_db_password
JWT_SECRET=your_64_char_random_secret
WAZUH_API_URL=https://your-wazuh-ip:55000
WAZUH_API_PASSWORD=your_wazuh_api_password
WAZUH_DASHBOARD_URL=https://your-wazuh-dashboard
OPENCTI_URL=http://your-opencti-ip:8080
OPENCTI_API_KEY=your-opencti-key
IRIS_URL=https://your-iris-ip:4433
IRIS_API_KEY=your-iris-key
SHUFFLE_API_KEY=your-shuffle-key
```

### 2. Deploy
```bash
docker compose up -d --build
```

Portal runs at: **http://localhost:80**

### 3. Default credentials
| Username | Password | Role |
|----------|----------|------|
| `admin` | `PrimeSoc@Admin123!` | Super Admin |
| `fintech_ops` | `PrimeSoc@Admin123!` | Client (FinTech Global) |

**⚠️ Change these immediately after first login.**

---

## User Management

### Creating a new client user
1. Login as admin
2. Go to **Admin → Users → Add User**
3. Set role to `Client` and assign a tenant

### Creating a new tenant
1. Go to **Admin → Tenants → Onboard Tenant**
2. Set `Wazuh Group` to match the exact Wazuh agent group name
3. Client users assigned to this tenant will only see agents in that group

---

## Wazuh Tenant Isolation

Tenants are isolated by **Wazuh agent groups**:
- When an admin creates a tenant, they specify `wazuh_group` (e.g., `FinTech_Global`)
- Client users assigned to this tenant can only see alerts/agents from that group
- The portal API enforces this by filtering all Wazuh API calls by `agents_list` (agents belonging to the group)

### Wazuh agent group setup (from your existing process):
```
Indexer Management > Securities > Tenants
Roles > [Your Role] > Action > Duplicate
```
Then assign the group to agents in Wazuh Manager.

---

## Adding a Domain

1. Update `.env`:
   ```
   DOMAIN=portal.yourdomain.com
   ```

2. Add SSL certificates to `./nginx/ssl/`:
   ```
   nginx/ssl/cert.pem
   nginx/ssl/key.pem
   ```

3. Update `nginx/nginx.conf` server_name directive.

4. Restart: `docker compose restart nginx`

---

## Environment Variables Reference

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `JWT_SECRET` | ✅ | Min 64 chars random string |
| `WAZUH_API_URL` | ✅ | Wazuh API base URL with port |
| `WAZUH_API_PASSWORD` | ✅ | Wazuh API user password |
| `WAZUH_DASHBOARD_URL` | ✅ | Wazuh Kibana/Dashboard URL |
| `OPENCTI_URL` | ✅ | OpenCTI base URL |
| `OPENCTI_API_KEY` | ✅ | OpenCTI API token |
| `IRIS_URL` | ✅ | IRIS base URL |
| `IRIS_API_KEY` | ✅ | IRIS API token |
| `SHUFFLE_URL` | ⚡ | Shuffle instance URL |
| `SHUFFLE_API_KEY` | ⚡ | Shuffle API key |
| `WAZUH_INSECURE_TLS` | 🔧 | Set `true` for self-signed certs |
| `IRIS_INSECURE_TLS` | 🔧 | Set `true` for self-signed certs |

---

## Architecture

```
Browser
  │
  ▼
Nginx :80/:443
  ├── /                 → Next.js portal (frontend:3000)
  ├── /api/*            → Next.js API routes (auth, Wazuh, SOAR, etc.)
  ├── /proxy/wazuh/*    → Wazuh Dashboard (strips X-Frame-Options)
  ├── /proxy/opencti/*  → OpenCTI (strips X-Frame-Options)
  └── /proxy/iris/*     → IRIS (strips X-Frame-Options)
  
Next.js
  ├── Server Components → PostgreSQL (users, tenants, sessions)
  ├── API Routes        → Wazuh API, OpenCTI GraphQL, IRIS REST, Shuffle REST
  └── Client Components → React, Recharts, Framer Motion

PostgreSQL
  └── users, tenants, sessions, audit_logs, notifications
```

---

## Security Notes

- All sessions stored in PostgreSQL with JTI for revocation
- All actions written to `audit_logs`
- JWT cookies are `httpOnly`, `secure`, `sameSite=lax`
- Rate limiting: 5 login attempts/min per IP
- Tenant isolation enforced server-side on every API call
- TLS verification configurable per tool (for self-signed cert environments)

---

## Roadmap / SSO

When ready to add SSO:
1. Add an OIDC provider (Keycloak, Azure AD, etc.)
2. Replace the login form with OAuth2 redirect
3. Map OIDC groups to portal tenants/roles
4. Remove per-module auth prompts (they become automatic)

The portal is designed to support SSO with minimal refactoring — all auth logic is in `src/lib/auth.ts` and `src/app/api/auth/`.
