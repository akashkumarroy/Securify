import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { JWTPayload } from '@/types';

const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN ?? '8h';

if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET environment variable is not set');
}

// ── Token generation ─────────────────────────────────────────

export function signToken(payload: Omit<JWTPayload, 'jti' | 'iat' | 'exp'>): string {
  const jti = uuidv4();
  return jwt.sign({ ...payload, jti }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
    algorithm: 'HS256',
  });
}

// ── Token verification ───────────────────────────────────────

export function verifyToken(token: string): JWTPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as JWTPayload;
    return decoded;
  } catch {
    return null;
  }
}

// ── Cookie name ──────────────────────────────────────────────

export const COOKIE_NAME = 'primesoc_session';

export const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  path: '/',
  maxAge: 8 * 60 * 60, // 8 hours in seconds
};

// ── Token from cookie string ─────────────────────────────────

export function getTokenFromCookieHeader(cookieHeader: string | null): string | null {
  if (!cookieHeader) return null;
  const cookies = Object.fromEntries(
    cookieHeader.split(';').map((c) => {
      const [k, ...v] = c.trim().split('=');
      return [k, v.join('=')];
    }),
  );
  return cookies[COOKIE_NAME] ?? null;
}
