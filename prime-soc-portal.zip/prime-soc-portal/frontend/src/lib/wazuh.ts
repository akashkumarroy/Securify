// ============================================================
// Wazuh API Client
// Handles authentication + tenant-scoped queries
// ============================================================

import https from 'https';

const WAZUH_API_URL   = process.env.WAZUH_API_URL!;
const WAZUH_USERNAME  = process.env.WAZUH_API_USERNAME ?? 'wazuh';
const WAZUH_PASSWORD  = process.env.WAZUH_API_PASSWORD!;
const INSECURE_TLS    = process.env.WAZUH_INSECURE_TLS === 'true';

// In-memory token cache (short-lived, ~900 seconds)
let _token: string | null = null;
let _tokenExpiry = 0;

// Custom agent to bypass self-signed cert errors
const httpsAgent = INSECURE_TLS
  ? new https.Agent({ rejectUnauthorized: false })
  : undefined;

// ── Auth ─────────────────────────────────────────────────────

async function getToken(): Promise<string> {
  const now = Date.now();
  if (_token && now < _tokenExpiry) return _token;

  const credentials = Buffer.from(`${WAZUH_USERNAME}:${WAZUH_PASSWORD}`).toString('base64');

  const res = await fetch(`${WAZUH_API_URL}/security/user/authenticate?raw=true`, {
    method: 'POST',
    headers: { Authorization: `Basic ${credentials}` },
    // @ts-expect-error — node-fetch accepts agent
    agent: httpsAgent,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Wazuh auth failed: ${res.status} — ${text}`);
  }

  const token = await res.text();
  _token = token.trim();
  _tokenExpiry = now + 890_000; // expire 10s before actual expiry
  return _token;
}

// ── Base request ─────────────────────────────────────────────

async function wazuhRequest<T>(
  path: string,
  options: { method?: string; body?: unknown } = {},
): Promise<T> {
  const token = await getToken();

  const res = await fetch(`${WAZUH_API_URL}${path}`, {
    method: options.method ?? 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
    // @ts-expect-error
    agent: httpsAgent,
  });

  if (res.status === 401) {
    // Token expired — clear cache and retry once
    _token = null;
    return wazuhRequest<T>(path, options);
  }

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Wazuh API error ${res.status}: ${text}`);
  }

  return res.json() as Promise<T>;
}

// ── Agents ───────────────────────────────────────────────────

export async function getAgents(wazuh_group?: string, limit = 500) {
  const params = new URLSearchParams({ limit: String(limit), offset: '0' });
  if (wazuh_group) params.append('groups_list', wazuh_group);

  const data = await wazuhRequest<{ data: { affected_items: unknown[]; total_affected_items: number } }>(
    `/agents?${params.toString()}`,
  );
  return data.data;
}

export async function getAgentOverview(wazuh_group?: string) {
  const agents = await getAgents(wazuh_group);
  const items = agents.affected_items as Array<{ status: string }>;

  const active       = items.filter((a) => a.status === 'active').length;
  const disconnected = items.filter((a) => a.status === 'disconnected').length;
  const total        = agents.total_affected_items;

  return {
    total_agents:        total,
    active_agents:       active,
    disconnected_agents: disconnected,
    endpoint_health_pct: total > 0 ? Math.round((active / total) * 100 * 10) / 10 : 0,
  };
}

// ── Alerts ───────────────────────────────────────────────────

export async function getAlerts(wazuh_group?: string, limit = 100) {
  // Build query: filter by group agents
  let agentIds: string[] = [];
  if (wazuh_group) {
    const agentsData = await getAgents(wazuh_group, 1000);
    agentIds = (agentsData.affected_items as Array<{ id: string }>).map((a) => a.id);
    if (agentIds.length === 0) return { affected_items: [], total_affected_items: 0 };
  }

  const params = new URLSearchParams({
    limit: String(limit),
    sort: '-timestamp',
    select: 'timestamp,rule.description,rule.level,rule.groups,rule.mitre,agent.name,agent.id,agent.ip',
  });

  if (agentIds.length > 0) {
    params.append('agents_list', agentIds.slice(0, 100).join(','));
  }

  const data = await wazuhRequest<{ data: { affected_items: unknown[]; total_affected_items: number } }>(
    `/alerts?${params.toString()}`,
  );
  return data.data;
}

export async function getCriticalAlerts(wazuh_group?: string) {
  let agentIds: string[] = [];
  if (wazuh_group) {
    const agentsData = await getAgents(wazuh_group, 1000);
    agentIds = (agentsData.affected_items as Array<{ id: string }>).map((a) => a.id);
    if (agentIds.length === 0) return { affected_items: [], total_affected_items: 0 };
  }

  const params = new URLSearchParams({
    limit: '50',
    sort: '-timestamp',
    level: '12-15',
    select: 'timestamp,rule.description,rule.level,rule.groups,rule.mitre,agent.name,agent.id,agent.ip',
  });
  if (agentIds.length > 0) {
    params.append('agents_list', agentIds.slice(0, 100).join(','));
  }

  const data = await wazuhRequest<{ data: { affected_items: unknown[]; total_affected_items: number } }>(
    `/alerts?${params.toString()}`,
  );
  return data.data;
}

// ── Statistics ───────────────────────────────────────────────

export async function getDashboardStats(wazuh_group?: string) {
  const [overview, criticalAlerts] = await Promise.allSettled([
    getAgentOverview(wazuh_group),
    getCriticalAlerts(wazuh_group),
  ]);

  return {
    agents: overview.status === 'fulfilled' ? overview.value : null,
    critical_alerts:
      criticalAlerts.status === 'fulfilled'
        ? criticalAlerts.value.total_affected_items
        : 0,
  };
}

// ── Security Events ──────────────────────────────────────────

export async function getSecurityEvents(wazuh_group?: string, limit = 50) {
  // Get events from all agents in group
  let agentIds: string[] = [];
  if (wazuh_group) {
    const agentsData = await getAgents(wazuh_group, 500);
    agentIds = (agentsData.affected_items as Array<{ id: string }>).map((a) => a.id);
    if (agentIds.length === 0) return [];
  }

  const params = new URLSearchParams({
    limit: String(limit),
    sort: '-timestamp',
    select: 'timestamp,rule.description,rule.level,agent.name,agent.id,location,data.srcip',
  });
  if (agentIds.length > 0) {
    params.append('agents_list', agentIds.slice(0, 100).join(','));
  }

  const data = await wazuhRequest<{ data: { affected_items: unknown[] } }>(
    `/alerts?${params.toString()}`,
  );
  return data.data.affected_items;
}
