// ============================================================
// IRIS Case Management API Client
// ============================================================

import https from 'https';

const IRIS_URL     = process.env.IRIS_URL!;
const IRIS_API_KEY = process.env.IRIS_API_KEY!;

const httpsAgent =
  process.env.IRIS_INSECURE_TLS === 'true'
    ? new https.Agent({ rejectUnauthorized: false })
    : undefined;

async function irisRequest<T>(
  path: string,
  options: { method?: string; body?: unknown } = {},
): Promise<T> {
  const res = await fetch(`${IRIS_URL}${path}`, {
    method: options.method ?? 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${IRIS_API_KEY}`,
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
    // @ts-expect-error
    agent: httpsAgent,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`IRIS API error ${res.status}: ${text}`);
  }

  return res.json() as Promise<T>;
}

// ── Cases ─────────────────────────────────────────────────────

export interface IRISResponse<T> {
  status: string;
  data: T;
}

export async function getCases(page = 1, perPage = 50) {
  const res = await irisRequest<IRISResponse<{ cases: unknown[] }>>(
    `/manage/cases/list`,
  );
  return res.data?.cases ?? [];
}

export async function getCaseById(caseId: number) {
  const res = await irisRequest<IRISResponse<unknown>>(
    `/manage/cases/${caseId}`,
  );
  return res.data;
}

// ── Alerts ───────────────────────────────────────────────────

export async function getIRISAlerts(page = 1, perPage = 50) {
  const res = await irisRequest<IRISResponse<{ alerts: unknown[] }>>(
    `/manage/alerts/filter?page=${page}&per_page=${perPage}&sort=-alert_source_event_time`,
  );
  return res.data?.alerts ?? [];
}

// ── Stats ────────────────────────────────────────────────────

export async function getCaseStats() {
  try {
    const cases = (await getCases()) as Array<{
      case_id: number;
      state_name?: string;
      open_date?: string;
    }>;

    const open        = cases.filter((c) => c.state_name !== 'Closed').length;
    const closed      = cases.filter((c) => c.state_name === 'Closed').length;
    const in_progress = cases.filter((c) => c.state_name === 'In Progress').length;

    return {
      total:       cases.length,
      open,
      closed,
      in_progress,
    };
  } catch {
    return { total: 0, open: 0, closed: 0, in_progress: 0 };
  }
}

// ── Create case ───────────────────────────────────────────────

export async function createCase(data: {
  case_name: string;
  case_description?: string;
  case_customer?: string;
  case_soc_id?: string;
  severity_id?: number;
}) {
  return irisRequest('/manage/cases/add', { method: 'POST', body: data });
}
