// ============================================================
// OpenCTI GraphQL API Client
// ============================================================

import https from 'https';

const OPENCTI_URL = process.env.OPENCTI_URL!;
const OPENCTI_API_KEY = process.env.OPENCTI_API_KEY!;

const httpsAgent =
  process.env.OPENCTI_URL?.startsWith('https')
    ? new https.Agent({ rejectUnauthorized: false })
    : undefined;

async function gqlQuery<T>(query: string, variables?: Record<string, unknown>): Promise<T> {
  const res = await fetch(`${OPENCTI_URL}/graphql`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENCTI_API_KEY}`,
    },
    body: JSON.stringify({ query, variables }),
    // @ts-expect-error
    agent: httpsAgent,
  });

  if (!res.ok) throw new Error(`OpenCTI request failed: ${res.status}`);

  const json = (await res.json()) as { data?: T; errors?: unknown[] };
  if (json.errors) throw new Error(`OpenCTI GraphQL error: ${JSON.stringify(json.errors)}`);
  return json.data as T;
}

// ── Threat Actors ────────────────────────────────────────────

export async function getThreatActors(limit = 20) {
  const q = `
    query GetThreatActors($first: Int) {
      threatActors(first: $first, orderBy: modified, orderMode: desc) {
        edges {
          node {
            id
            name
            description
            threat_actor_types
            sophistication
            first_seen
            last_seen
            confidence
          }
        }
      }
    }
  `;
  const data = await gqlQuery<{ threatActors: { edges: Array<{ node: unknown }> } }>(q, { first: limit });
  return data.threatActors.edges.map((e) => e.node);
}

// ── Indicators (IOCs) ────────────────────────────────────────

export async function getIndicators(limit = 50) {
  const q = `
    query GetIndicators($first: Int) {
      indicators(first: $first, orderBy: modified, orderMode: desc) {
        edges {
          node {
            id
            name
            pattern
            pattern_type
            valid_from
            confidence
            x_opencti_score
          }
        }
      }
    }
  `;
  const data = await gqlQuery<{ indicators: { edges: Array<{ node: unknown }> } }>(q, { first: limit });
  return data.indicators.edges.map((e) => e.node);
}

// ── Reports ──────────────────────────────────────────────────

export async function getReports(limit = 20) {
  const q = `
    query GetReports($first: Int) {
      reports(first: $first, orderBy: published, orderMode: desc) {
        edges {
          node {
            id
            name
            description
            published
            confidence
            report_types
          }
        }
      }
    }
  `;
  const data = await gqlQuery<{ reports: { edges: Array<{ node: unknown }> } }>(q, { first: limit });
  return data.reports.edges.map((e) => e.node);
}

// ── Stats ────────────────────────────────────────────────────

export async function getCTIStats() {
  const q = `
    query GetStats {
      threatsMetrics {
        malwares { total }
        threatActors { total }
        intrusionSets { total }
        campaigns { total }
      }
      indicatorsMetrics { total }
    }
  `;
  try {
    return await gqlQuery<unknown>(q);
  } catch {
    // Fallback if metrics query not available
    return null;
  }
}
