// ============================================================
// Shuffle SOAR API Client
// ============================================================

const SHUFFLE_URL = process.env.SHUFFLE_URL ?? 'https://shuffler.io';
const SHUFFLE_API_KEY = process.env.SHUFFLE_API_KEY!;

async function shuffleRequest<T>(
  path: string,
  options: { method?: string; body?: unknown } = {},
): Promise<T> {
  const res = await fetch(`${SHUFFLE_URL}${path}`, {
    method: options.method ?? 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${SHUFFLE_API_KEY}`,
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Shuffle API error ${res.status}: ${text}`);
  }

  return res.json() as Promise<T>;
}

// ── Workflows ────────────────────────────────────────────────

export async function getWorkflows() {
  return shuffleRequest<unknown[]>('/api/v1/workflows');
}

// ── Workflow executions ──────────────────────────────────────

export async function getWorkflowExecutions(workflowId: string, limit = 20) {
  return shuffleRequest<unknown[]>(
    `/api/v1/workflows/${workflowId}/executions?limit=${limit}`,
  );
}

// ── Apps ─────────────────────────────────────────────────────

export async function getApps() {
  return shuffleRequest<unknown[]>('/api/v1/apps');
}

// ── Stats ────────────────────────────────────────────────────

export async function getSOARStats() {
  try {
    const workflows = (await getWorkflows()) as Array<{ status?: string; execution_count?: number }>;
    const active   = workflows.filter((w) => w.status === 'running').length;
    const total    = workflows.length;

    // Aggregate execution counts
    let success = 0, failed = 0, pending = 0;
    for (const w of workflows) {
      // Execution counts from workflow metadata if available
      success += 0; // Will be populated from execution data
      failed  += 0;
      pending += 0;
    }

    return {
      total_workflows: total,
      active_workflows: active,
      success,
      failed,
      pending,
      health_pct: total > 0 ? Math.round(((total - failed) / total) * 100) : 0,
    };
  } catch {
    return {
      total_workflows: 0,
      active_workflows: 0,
      success: 0,
      failed: 0,
      pending: 0,
      health_pct: 0,
    };
  }
}

// ── Trigger workflow ─────────────────────────────────────────

export async function triggerWorkflow(workflowId: string, data?: Record<string, unknown>) {
  return shuffleRequest(`/api/v1/workflows/${workflowId}/execute`, {
    method: 'POST',
    body: data ?? {},
  });
}
