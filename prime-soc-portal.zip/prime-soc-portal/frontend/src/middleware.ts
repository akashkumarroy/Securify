import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';

// Routes that do NOT require authentication
const PUBLIC_PATHS = [
  '/',           // Login page
  '/api/auth/login',
  '/api/health',
  '/_next',
  '/favicon.ico',
  '/icons',
];

// Admin-only routes
const ADMIN_PATHS = ['/admin'];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Allow public paths
  const isPublic = PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p));
  if (isPublic) return NextResponse.next();

  // Read session cookie
  const token = request.cookies.get(COOKIE_NAME)?.value;

  if (!token) {
    // Redirect to login, preserve intended destination
    const loginUrl = new URL('/', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  const payload = verifyToken(token);

  if (!payload) {
    // Invalid/expired token — clear cookie and redirect
    const response = NextResponse.redirect(new URL('/', request.url));
    response.cookies.delete(COOKIE_NAME);
    return response;
  }

  // Admin-only route check
  const isAdminRoute = ADMIN_PATHS.some((p) => pathname.startsWith(p));
  if (isAdminRoute && payload.role !== 'admin') {
    return NextResponse.redirect(new URL('/dashboard', request.url));
  }

  // Inject user context into request headers for Server Components
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-user-id',      payload.sub);
  requestHeaders.set('x-user-role',    payload.role);
  requestHeaders.set('x-user-tenant',  payload.tenant_id ?? '');
  requestHeaders.set('x-wazuh-group',  payload.wazuh_group ?? '');

  return NextResponse.next({ request: { headers: requestHeaders } });
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|icons|api/health).*)',
  ],
};
