// ============================================================
// Prime SOC Portal — Global Types
// ============================================================

export type UserRole = 'admin' | 'client';

export interface User {
  id: string;
  username: string;
  email?: string;
  full_name?: string;
  role: UserRole;
  tenant_id?: string;
  tenant?: Tenant;
  is_active: boolean;
  last_login?: string;
  created_at: string;
}

export interface Tenant {
  id: string;
  name: string;
  uid: string;
  wazuh_group: string;
  wazuh_tenant?: string;
  industry?: string;
  status: 'active' | 'warning' | 'critical' | 'inactive';
  threat_score: number;
  created_at: string;
  updated_at: string;
  // Aggregated from APIs
  incident_count?: number;
  agent_count?: number;
  alert_count?: number;
}

export interface JWTPayload {
  sub: string;         // user id
  username: string;
  role: UserRole;
  tenant_id?: string;
  wazuh_group?: string;
  jti: string;         // token id for revocation
  iat: number;
  exp: number;
}

// ── Wazuh Types ─────────────────────────────────────────────

export interface WazuhAgent {
  id: string;
  name: string;
  ip?: string;
  os?: {
    name: string;
    version: string;
    platform: string;
  };
  status: 'active' | 'disconnected' | 'never_connected' | 'pending';
  group?: string[];
  lastKeepAlive?: string;
  version?: string;
  node_name?: string;
  manager?: string;
  dateAdd?: string;
}

export interface WazuhAlert {
  id: string;
  timestamp: string;
  rule: {
    id: string;
    description: string;
    level: number;
    groups: string[];
    mitre?: { id: string[]; technique: string[] };
  };
  agent: {
    id: string;
    name: string;
    ip?: string;
  };
  manager?: { name: string };
  location?: string;
  full_log?: string;
  data?: Record<string, unknown>;
}

export interface WazuhOverview {
  total_agents: number;
  active_agents: number;
  disconnected_agents: number;
  active_alerts_12plus: number;
  critical_severity: number;
  events_scanned: number;
  endpoint_health_pct: number;
}

// ── Shuffle SOAR Types ──────────────────────────────────────

export interface ShuffleWorkflow {
  id: string;
  name: string;
  description?: string;
  status: string;
  execution_count: number;
  last_executed?: string;
  actions?: { id: string; name: string; app_name: string }[];
}

export interface ShuffleExecution {
  execution_id: string;
  workflow_id: string;
  workflow_name?: string;
  status: 'FINISHED' | 'FAILED' | 'EXECUTING' | 'ABORTED';
  started_at: string;
  completed_at?: string;
  execution_argument?: string;
}

// ── OpenCTI Types ───────────────────────────────────────────

export interface CTIReport {
  id: string;
  name: string;
  description?: string;
  published: string;
  confidence: number;
  report_types: string[];
  objectLabel?: { value: string; color: string }[];
}

export interface CTIThreatActor {
  id: string;
  name: string;
  description?: string;
  threat_actor_types: string[];
  sophistication?: string;
  first_seen?: string;
  last_seen?: string;
}

export interface CTIIndicator {
  id: string;
  name: string;
  pattern: string;
  pattern_type: string;
  valid_from: string;
  confidence: number;
  x_opencti_score: number;
}

// ── IRIS Types ───────────────────────────────────────────────

export interface IRISCase {
  case_id: number;
  case_name: string;
  case_description?: string;
  case_customer?: string;
  case_soc_id?: string;
  state_name: string;
  owner_username?: string;
  open_date: string;
  close_date?: string;
  severity: { severity_name: string };
  classification?: { name: string };
  tags?: string[];
}

// ── Dashboard / API Response Types ──────────────────────────

export interface AlertFeedItem {
  id: string;
  timestamp: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  source: string;       // agent name
  event_name: string;   // rule description
  status: 'Triaging' | 'Pending' | 'Auto-Blocked' | 'Closed' | 'Open';
  rule_level: number;
}

export interface EPSDataPoint {
  time: string;
  eps: number;
}

export interface MitreAttackEntry {
  technique_id: string;
  technique_name: string;
  tactic: string;
  count: number;
  severity: 'none' | 'low' | 'medium' | 'high' | 'critical';
}

export interface ApiResponse<T> {
  data: T;
  error?: string;
  total?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
}

// ── Notification Types ──────────────────────────────────────

export interface Notification {
  id: string;
  type: 'alert' | 'incident' | 'system' | 'info';
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  title: string;
  message?: string;
  is_read: boolean;
  created_at: string;
}
