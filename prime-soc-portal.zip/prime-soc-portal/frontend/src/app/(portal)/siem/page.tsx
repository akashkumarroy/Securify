'use client';

import { useState, useEffect } from 'react';

interface WazuhStats {
  agents: { total_agents: number; active_agents: number; endpoint_health_pct: number } | null;
  critical_alerts: number;
}

export default function SIEMPage() {
  const [stats, setStats] = useState<WazuhStats | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'events' | 'integrity'>('overview');
  const [iframeLoaded, setIframeLoaded] = useState(false);

  const WAZUH_URL = process.env.NEXT_PUBLIC_WAZUH_DASHBOARD_URL ?? '/proxy/wazuh';

  useEffect(() => {
    fetch('/api/wazuh/stats')
      .then((r) => r.json())
      .then(setStats)
      .catch(() => {});
  }, []);

  const tabs = [
    { id: 'overview',   label: 'Overview' },
    { id: 'events',     label: 'Security events' },
    { id: 'integrity',  label: 'Integrity monitoring' },
  ] as const;

  return (
    <div className="flex flex-col h-full">
      {/* Breadcrumb + Header */}
      <div className="px-6 pt-5 pb-0 shrink-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-mono text-[10px] text-[#849495]">Dashboard</span>
          <span className="font-mono text-[10px] text-[#3b494b]">/</span>
          <span className="font-mono text-[10px] text-[#00f0ff]">SIEM (Wazuh)</span>
        </div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <h1 className="font-bold text-xl text-[#dee2f1] tracking-tight">
              Security Information &amp; Event Management
            </h1>
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full font-mono text-[10px] font-bold"
              style={{ background: 'rgba(114,255,112,0.1)', border: '1px solid rgba(114,255,112,0.3)', color: '#72ff70' }}>
              <span className="w-1.5 h-1.5 rounded-full bg-[#72ff70] status-dot-live" />
              LIVE TELEMETRY
            </span>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg font-mono text-[11px]"
            style={{ background: 'rgba(0,240,255,0.08)', border: '1px solid rgba(0,240,255,0.2)', color: '#00f0ff' }}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945" />
            </svg>
            SECURE TUNNEL: ACTIVE
          </div>
        </div>

        {/* Wazuh Dashboard Header */}
        <div className="glass-card rounded-t-xl px-4 py-3 flex items-center justify-between"
          style={{ borderBottom: '1px solid rgba(59,73,75,0.3)' }}>
          <div className="flex items-center gap-3">
            <svg className="w-4 h-4 text-[#00f0ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
                d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <span className="font-mono text-[12px] font-bold tracking-widest uppercase text-[#dee2f1]">
              Wazuh Dashboard
            </span>
            <div className="w-px h-4 bg-[#3b494b]" />
            {tabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className="font-mono text-[12px] px-1 py-0.5 transition-colors border-b-2"
                style={{
                  color: activeTab === tab.id ? '#dee2f1' : '#849495',
                  borderColor: activeTab === tab.id ? '#00f0ff' : 'transparent',
                }}>
                {tab.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[10px] text-[#849495]">Cluster: ops-prod-01</span>
            <span className="w-px h-3 bg-[#3b494b]" />
            <span className="font-mono text-[10px] text-[#849495]">v4.7.2</span>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="px-6 shrink-0">
        <div className="glass-card rounded-none grid grid-cols-4 divide-x"
          style={{ borderTop: 'none', divideColor: 'rgba(59,73,75,0.3)' }}>
          {[
            {
              label: 'TOTAL AGENTS',
              value: stats?.agents?.total_agents?.toLocaleString() ?? '—',
              sub: '↑ 4 added in last 24h',
              color: '#dee2f1',
              subColor: '#72ff70',
            },
            {
              label: 'ACTIVE ALERTS (LVL 12+)',
              value: stats?.critical_alerts?.toString() ?? '—',
              sub: 'Critical severity: 2',
              color: '#ffb4ab',
              subColor: '#849495',
            },
            {
              label: 'EVENTS SCANNED',
              value: '8.4M',
              sub: 'Avg 4.2k eps',
              color: '#dee2f1',
              subColor: '#849495',
            },
            {
              label: 'ENDPOINT STATUS',
              value: `${stats?.agents?.endpoint_health_pct ?? 98.2}%`,
              sub: 'Healthy',
              color: '#72ff70',
              subColor: '#72ff70',
            },
          ].map((s) => (
            <div key={s.label} className="p-4">
              <p className="font-mono text-[10px] tracking-widest uppercase text-[#849495] mb-1">{s.label}</p>
              <p className="font-mono text-[26px] font-bold" style={{ color: s.color }}>{s.value}</p>
              <p className="font-mono text-[10px] mt-1" style={{ color: s.subColor }}>{s.sub}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Wazuh iframe */}
      <div className="flex-1 px-6 pb-5 min-h-0">
        <div className="glass-card rounded-b-xl h-full relative overflow-hidden"
          style={{ borderTop: 'none' }}>
          {!iframeLoaded && (
            <div className="absolute inset-0 flex flex-col items-center justify-center z-10"
              style={{ background: 'rgba(14,19,29,0.9)' }}>
              <svg className="w-10 h-10 text-[#00f0ff] animate-spin mb-3" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              <p className="font-mono text-[12px] text-[#849495]">Loading Wazuh Dashboard…</p>
            </div>
          )}
          <iframe
            src={WAZUH_URL}
            title="Wazuh SIEM Dashboard"
            onLoad={() => setIframeLoaded(true)}
            className="w-full h-full border-none"
            style={{ minHeight: '500px' }}
            sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"
          />
        </div>
      </div>
    </div>
  );
}
