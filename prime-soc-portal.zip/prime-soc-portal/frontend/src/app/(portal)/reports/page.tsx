'use client';

import { useState } from 'react';

const REPORT_TEMPLATES = [
  { id: 'executive', title: 'Executive Security Summary', desc: 'High-level risk posture, threat score trends, compliance status overview.', icon: '📊', color: '#00f0ff' },
  { id: 'incidents',  title: 'Incident Report (30d)',     desc: 'All incidents, MTTR, severity distribution, resolution outcomes.',        icon: '🚨', color: '#ffb4ab' },
  { id: 'compliance', title: 'Compliance & Audit Log',    desc: 'SOC2, PCI-DSS, GDPR audit trail, policy violations, access logs.',         icon: '🛡️', color: '#72ff70' },
  { id: 'threats',    title: 'Threat Intelligence Brief', desc: 'Relevant threat actors, IOCs, industry-specific intelligence summary.',    icon: '🌐', color: '#d1bcff' },
  { id: 'agents',     title: 'Endpoint Health Report',   desc: 'Agent status, patch compliance, vulnerability exposure by group.',         icon: '💻', color: '#ffd770' },
  { id: 'soar',       title: 'SOAR Automation Report',   desc: 'Playbook execution stats, automated response outcomes, ROI metrics.',      icon: '⚡', color: '#b9cacb' },
];

export default function ReportsPage() {
  const [generating, setGenerating] = useState<string | null>(null);

  const handleGenerate = async (id: string) => {
    setGenerating(id);
    await new Promise(r => setTimeout(r, 1500));
    setGenerating(null);
    // In production: call /api/reports/generate?type=id and return PDF
    alert(`Report "${id}" would be generated and downloaded here. Connect your reporting backend.`);
  };

  return (
    <div className="p-6 min-h-full space-y-6">
      <div>
        <h1 className="font-bold text-2xl text-[#dee2f1] tracking-tight">Security Reports</h1>
        <p className="font-mono text-[11px] text-[#849495] mt-0.5">
          Generate and download security intelligence reports
        </p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {REPORT_TEMPLATES.map((r) => (
          <div key={r.id} className="glass-card-hover rounded-xl p-5 flex flex-col">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shrink-0"
                style={{ background: `${r.color}15` }}>
                {r.icon}
              </div>
              <div>
                <h3 className="font-bold text-[14px] text-[#dee2f1]">{r.title}</h3>
                <p className="font-mono text-[11px] text-[#849495] mt-0.5 leading-relaxed">{r.desc}</p>
              </div>
            </div>
            <button onClick={() => handleGenerate(r.id)}
              disabled={generating === r.id}
              className="mt-auto w-full py-2 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase transition-all flex items-center justify-center gap-2"
              style={{ border: `1px solid ${r.color}40`, color: r.color, background: `${r.color}0d` }}>
              {generating === r.id ? (
                <>
                  <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  GENERATING...
                </>
              ) : (
                <>
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Generate Report
                </>
              )}
            </button>
          </div>
        ))}
      </div>

      {/* Recent Reports placeholder */}
      <div>
        <h2 className="font-mono text-[12px] font-bold tracking-widest uppercase text-[#849495] mb-3">
          Recent Reports
        </h2>
        <div className="glass-card rounded-xl overflow-hidden">
          <div className="p-8 text-center">
            <svg className="w-10 h-10 text-[#3b494b] mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <p className="font-mono text-[12px] text-[#849495]">No reports generated yet.</p>
            <p className="font-mono text-[11px] text-[#3b494b] mt-1">Generated reports will appear here.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
