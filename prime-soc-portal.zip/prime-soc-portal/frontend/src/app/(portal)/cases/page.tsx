'use client';

import { useState, useEffect } from 'react';

interface CaseStats { total: number; open: number; closed: number; in_progress: number; }

export default function CasesPage() {
  const [stats, setStats] = useState<CaseStats | null>(null);
  const [authenticated, setAuthenticated] = useState(false);
  const [creds, setCreds] = useState({ id: '', token: '' });
  const [authLoading, setAuthLoading] = useState(false);
  const [iframeLoaded, setIframeLoaded] = useState(false);

  const IRIS_URL = process.env.NEXT_PUBLIC_IRIS_URL ?? '/proxy/iris';

  useEffect(() => {
    fetch('/api/cases?stats=true').then(r => r.json()).then(setStats).catch(() => {});
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    await new Promise(r => setTimeout(r, 600));
    setAuthenticated(true);
    setAuthLoading(false);
  };

  const DEMO_CASES = [
    { id: '#INC-9421', title: 'Anomalous SSH connection from RU IP Range',  tag: 'THREAT-HUNT', status: 'In Progress', color: '#ffd770' },
    { id: '#INC-9390', title: 'Unusual Data Egress: AWS-PROD-01',           tag: 'DATA-LOSS',   status: 'Triaged',     color: '#00f0ff' },
    { id: '#INC-9388', title: 'Brute Force Attempt: VPN-SFO-02',            tag: 'ACCESS',      status: 'Blocked',     color: '#72ff70' },
    { id: '#INC-9375', title: 'Privilege Escalation Detected: svc_backup',  tag: 'CRITICAL',    status: 'Open',        color: '#ffb4ab' },
    { id: '#INC-9360', title: 'PowerShell Execution Policy Bypass',         tag: 'MALWARE',     status: 'Closed',      color: '#849495' },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-6 pt-5 pb-4 shrink-0 border-b" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="font-bold text-xl text-[#dee2f1] tracking-tight">Case Management</h1>
            <p className="font-mono text-[11px] text-[#849495] mt-0.5">Incident Response & Case Tracking via IRIS</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase"
            style={{ border: '1px solid #00f0ff', color: '#00f0ff', background: 'rgba(0,240,255,0.08)' }}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            New Case
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: 'Total Cases',  value: stats?.total ?? 66,       color: '#dee2f1' },
            { label: 'Open',         value: stats?.open ?? 18,         color: '#ffb4ab' },
            { label: 'In Progress',  value: stats?.in_progress ?? 12,  color: '#ffd770' },
            { label: 'Closed',       value: stats?.closed ?? 36,       color: '#72ff70' },
          ].map((s) => (
            <div key={s.label} className="glass-card rounded-lg p-3 text-center">
              <p className="font-mono text-[9px] tracking-widest uppercase text-[#849495] mb-1">{s.label}</p>
              <p className="font-mono text-[22px] font-bold" style={{ color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Cases List Sidebar */}
        <div className="w-80 shrink-0 border-r overflow-y-auto p-4 space-y-2"
          style={{ borderColor: 'rgba(59,73,75,0.2)', background: 'rgba(9,14,24,0.5)' }}>
          <div className="flex items-center justify-between mb-2">
            <p className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#849495]">Recent Incidents</p>
            <div className="flex gap-1">
              {['All', 'Active', 'Resolved'].map((f) => (
                <button key={f} className="font-mono text-[9px] px-2 py-0.5 rounded transition-colors"
                  style={{ background: f === 'All' ? 'rgba(0,240,255,0.15)' : 'transparent',
                           color: f === 'All' ? '#00f0ff' : '#849495',
                           border: f === 'All' ? '1px solid rgba(0,240,255,0.3)' : '1px solid transparent' }}>
                  {f}
                </button>
              ))}
            </div>
          </div>

          {DEMO_CASES.map((c) => (
            <div key={c.id}
              onClick={() => setAuthenticated(true)}
              className="p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors"
              style={{ background: 'rgba(27,32,42,0.5)', border: '1px solid rgba(59,73,75,0.3)' }}>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                <span className="font-mono text-[10px] text-[#849495]">{c.id}</span>
                <span className="ml-auto font-mono text-[9px] px-1.5 py-0.5 rounded"
                  style={{ background: 'rgba(59,73,75,0.4)', color: '#b9cacb' }}>
                  {c.tag}
                </span>
              </div>
              <p className="font-mono text-[11px] text-[#dee2f1] leading-snug mb-1">{c.title}</p>
              <p className="font-mono text-[10px]" style={{ color: c.color }}>{c.status}</p>
            </div>
          ))}
        </div>

        {/* IRIS iframe */}
        <div className="flex-1 relative overflow-hidden">
          {!authenticated ? (
            <div className="absolute inset-0 flex items-center justify-center"
              style={{ background: 'rgba(14,19,29,0.85)', backdropFilter: 'blur(6px)' }}>
              <div className="w-full max-w-md mx-6 rounded-2xl overflow-hidden"
                style={{ background: '#1b202a', border: '1px solid rgba(59,73,75,0.4)', boxShadow: '0 24px 64px rgba(0,0,0,0.7)' }}>
                <div className="p-8">
                  <div className="flex justify-center mb-5">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                      style={{ background: 'rgba(255,180,171,0.1)', border: '1px solid rgba(255,180,171,0.2)' }}>
                      <svg className="w-7 h-7 text-[#ffb4ab]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                          d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                    </div>
                  </div>
                  <h2 className="text-center font-bold text-lg text-[#dee2f1] mb-1">IRIS Case Management</h2>
                  <p className="text-center font-mono text-[11px] text-[#849495] mb-5">
                    Authenticate to access case management
                  </p>
                  <form onSubmit={handleAuth} className="space-y-3">
                    <input type="text" placeholder="Operator ID" value={creds.id}
                      onChange={e => setCreds(p => ({ ...p, id: e.target.value }))}
                      className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.5)' }} />
                    <input type="password" placeholder="••••••••" value={creds.token}
                      onChange={e => setCreds(p => ({ ...p, token: e.target.value }))}
                      className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.5)' }} />
                    <button type="submit" disabled={authLoading || !creds.id || !creds.token}
                      className="w-full py-3 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase"
                      style={{ background: '#ffb4ab', color: '#690005' }}>
                      {authLoading ? 'AUTHORIZING...' : 'AUTHORIZE ACCESS'}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          ) : (
            <>
              {!iframeLoaded && (
                <div className="absolute inset-0 flex items-center justify-center z-10"
                  style={{ background: 'rgba(14,19,29,0.9)' }}>
                  <svg className="w-8 h-8 text-[#ffb4ab] animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                </div>
              )}
              <iframe src={IRIS_URL} title="IRIS Case Management"
                onLoad={() => setIframeLoaded(true)}
                className="w-full h-full border-none"
                sandbox="allow-same-origin allow-scripts allow-forms allow-popups" />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
