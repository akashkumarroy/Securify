'use client';

import { useState, useEffect } from 'react';

interface ThreatActor {
  id: string;
  name: string;
  description?: string;
  threat_actor_types?: string[];
  sophistication?: string;
  first_seen?: string;
  last_seen?: string;
}

export default function ThreatIntelPage() {
  const [authenticated, setAuthenticated] = useState(false);
  const [secureId, setSecureId] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [actors, setActors] = useState<ThreatActor[]>([]);
  const [feedLoading, setFeedLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'wazuh' | 'opencti' | 'shuffle'>('opencti');
  const [iframeLoaded, setIframeLoaded] = useState(false);

  const OPENCTI_URL = process.env.NEXT_PUBLIC_OPENCTI_URL ?? '/proxy/opencti';

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!secureId.trim() || !accessToken.trim()) return;
    setAuthLoading(true);
    setAuthError('');

    // Validate against portal credentials via /api/auth/me
    // For module-level auth, we accept any non-empty credentials
    // and verify the session is still valid
    try {
      const res = await fetch('/api/auth/me');
      if (!res.ok) {
        setAuthError('Session expired. Please login again.');
        return;
      }
      // Simulate module auth — in prod integrate with SSO
      await new Promise((r) => setTimeout(r, 800));
      setAuthenticated(true);
      loadFeed();
    } catch {
      setAuthError('Authentication failed. Try again.');
    } finally {
      setAuthLoading(false);
    }
  };

  const loadFeed = async () => {
    setFeedLoading(true);
    try {
      const res = await fetch('/api/threat-intel/feed?type=actors');
      if (res.ok) {
        const data = await res.json();
        setActors(data.actors ?? []);
      }
    } finally {
      setFeedLoading(false);
    }
  };

  const SEVERITY_TAGS: Record<string, string> = {
    'threat-actor': '#ffb4ab',
    'intrusion-set': '#ffd770',
    'campaign': '#d1bcff',
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-6 pt-5 pb-4 shrink-0 border-b" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
        <div className="flex items-center justify-between">
          <h1 className="font-bold text-xl text-[#dee2f1] tracking-tight">Threat Intelligence</h1>
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] px-2 py-1 rounded"
              style={{ background: 'rgba(0,240,255,0.08)', border: '1px solid rgba(0,240,255,0.2)', color: '#00f0ff' }}>
              OpenCTI Platform
            </span>
          </div>
        </div>

        {/* Tab Bar */}
        <div className="flex items-center gap-1 mt-4 border-b" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
          {[
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'wazuh',    label: 'Wazuh (SIEM)' },
            { id: 'opencti',  label: 'OpenCTI (Intel)', icon: true },
            { id: 'shuffle',  label: 'Shuffle (SOAR)' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className="flex items-center gap-1.5 px-4 py-2 font-mono text-[12px] transition-colors border-b-2 -mb-px"
              style={{
                borderColor: activeTab === tab.id ? '#00f0ff' : 'transparent',
                color: activeTab === tab.id ? '#dee2f1' : '#849495',
              }}
            >
              {tab.icon && (
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945" />
                </svg>
              )}
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 relative overflow-hidden">
        {/* Module Auth Overlay */}
        {!authenticated && (
          <div className="absolute inset-0 z-20 flex items-center justify-center"
            style={{ background: 'rgba(14,19,29,0.7)', backdropFilter: 'blur(8px)' }}>
            {/* Blurred background preview */}
            <div className="absolute inset-0 opacity-20">
              <div className="h-full w-full bg-grid-pattern" />
            </div>

            {/* Auth Modal */}
            <div className="relative w-full max-w-md mx-6 rounded-2xl overflow-hidden"
              style={{ background: '#1b202a', border: '1px solid rgba(59,73,75,0.4)', boxShadow: '0 24px 64px rgba(0,0,0,0.7)' }}>
              <div className="p-8">
                {/* Lock icon */}
                <div className="flex justify-center mb-6">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
                    style={{ background: 'rgba(59,73,75,0.4)' }}>
                    <svg className="w-8 h-8 text-[#b9cacb]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                </div>

                <h2 className="text-center font-bold text-lg text-[#dee2f1] mb-2">Module Authentication</h2>
                <p className="text-center font-mono text-[12px] text-[#849495] mb-6">
                  OpenCTI requires secondary credential validation<br />for Level 4 Intel access.
                </p>

                {authError && (
                  <div className="mb-4 p-3 rounded-lg font-mono text-[11px] text-[#ffb4ab]"
                    style={{ background: 'rgba(147,0,10,0.2)', border: '1px solid rgba(255,180,171,0.3)' }}>
                    {authError}
                  </div>
                )}

                <form onSubmit={handleAuth} className="space-y-4">
                  <div>
                    <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#b9cacb] mb-1.5 block">
                      Secure ID
                    </label>
                    <input
                      type="text"
                      value={secureId}
                      onChange={(e) => setSecureId(e.target.value)}
                      placeholder="OPERATOR_ID"
                      className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.5)' }}
                      onFocus={(e) => e.currentTarget.style.borderColor = 'rgba(0,240,255,0.5)'}
                      onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(59,73,75,0.5)'}
                    />
                  </div>
                  <div>
                    <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#b9cacb] mb-1.5 block">
                      Access Token (HOTP)
                    </label>
                    <input
                      type="password"
                      value={accessToken}
                      onChange={(e) => setAccessToken(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.5)' }}
                      onFocus={(e) => e.currentTarget.style.borderColor = 'rgba(0,240,255,0.5)'}
                      onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(59,73,75,0.5)'}
                    />
                  </div>
                  <button type="submit" disabled={authLoading || !secureId || !accessToken}
                    className="w-full py-3 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase transition-all disabled:opacity-50"
                    style={{ background: '#00f0ff', color: '#003a3e' }}>
                    {authLoading ? 'AUTHORIZING...' : 'AUTHORIZE ACCESS'}
                  </button>
                </form>

                <p className="text-center font-mono text-[10px] text-[#849495] mt-4">
                  TIMESTAMP: {new Date().toISOString().split('.')[0]}Z
                </p>
              </div>
            </div>
          </div>
        )}

        {/* OpenCTI iframe + Sidebar Feed */}
        <div className="h-full flex gap-0">
          {/* Main iframe */}
          <div className="flex-1 relative">
            {authenticated && !iframeLoaded && (
              <div className="absolute inset-0 flex items-center justify-center z-10"
                style={{ background: 'rgba(14,19,29,0.9)' }}>
                <svg className="w-8 h-8 text-[#00f0ff] animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
              </div>
            )}
            <iframe
              src={authenticated ? OPENCTI_URL : 'about:blank'}
              title="OpenCTI Threat Intelligence"
              onLoad={() => setIframeLoaded(true)}
              className="w-full h-full border-none"
            />
          </div>

          {/* Threat Actor Feed Sidebar */}
          {authenticated && (
            <div className="w-72 shrink-0 border-l overflow-y-auto"
              style={{ borderColor: 'rgba(59,73,75,0.2)', background: 'rgba(9,14,24,0.6)' }}>
              <div className="p-4 border-b" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
                <p className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#b9cacb]">
                  Threat Actor Feed
                </p>
                <p className="font-mono text-[10px] text-[#849495] mt-0.5">Live intelligence</p>
              </div>

              <div className="p-3 space-y-2">
                {feedLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="skeleton h-20 rounded-lg" />
                  ))
                ) : actors.length === 0 ? (
                  /* Fallback demo data */
                  [
                    { name: 'Lazarus Group (APT38)', type: 'threat-actor', severity: 'CRITICAL',
                      desc: 'Targeting SWIFT payment gateways in SE Asia.', time: '12m ago' },
                    { name: 'FIN7 / Carbanak', type: 'intrusion-set', severity: 'HIGH',
                      desc: 'New POS malware variant identified in financial environments.', time: '2h ago' },
                    { name: 'LockBit 3.0', type: 'campaign', severity: 'HIGH',
                      desc: 'Active exploitation of CVE-2023-4966 against regional banking hubs.', time: '5h ago' },
                  ].map((a, i) => (
                    <div key={i} className="p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors"
                      style={{ background: 'rgba(27,32,42,0.5)', border: '1px solid rgba(59,73,75,0.3)' }}>
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="badge-critical font-mono text-[9px] px-1.5 py-0.5 rounded"
                          style={{ color: a.severity === 'CRITICAL' ? '#ffb4ab' : '#ffd770',
                                   background: a.severity === 'CRITICAL' ? 'rgba(147,0,10,0.3)' : 'rgba(150,80,0,0.3)',
                                   border: `1px solid ${a.severity === 'CRITICAL' ? 'rgba(255,180,171,0.3)' : 'rgba(255,215,100,0.3)'}` }}>
                          {a.severity}
                        </span>
                        <span className="font-mono text-[10px] text-[#849495] ml-auto">{a.time}</span>
                      </div>
                      <p className="font-mono text-[11px] font-bold text-[#dee2f1] mb-1">{a.name}</p>
                      <p className="font-mono text-[10px] text-[#849495] leading-relaxed">{a.desc}</p>
                    </div>
                  ))
                ) : actors.slice(0, 10).map((a) => (
                  <div key={a.id} className="p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors"
                    style={{ background: 'rgba(27,32,42,0.5)', border: '1px solid rgba(59,73,75,0.3)' }}>
                    <p className="font-mono text-[11px] font-bold text-[#dee2f1] mb-1">{a.name}</p>
                    {a.description && (
                      <p className="font-mono text-[10px] text-[#849495] leading-relaxed line-clamp-2">{a.description}</p>
                    )}
                    <div className="flex gap-1.5 mt-1.5">
                      {(a.threat_actor_types ?? ['threat-actor']).slice(0, 2).map((t) => (
                        <span key={t} className="font-mono text-[9px] px-1.5 py-0.5 rounded"
                          style={{ background: 'rgba(112,0,255,0.2)', color: '#d1bcff', border: '1px solid rgba(209,188,255,0.2)' }}>
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}

                <button onClick={loadFeed}
                  className="w-full py-2 rounded-lg font-mono text-[10px] font-bold tracking-widest uppercase text-[#849495] hover:text-[#dee2f1] transition-colors mt-2"
                  style={{ border: '1px solid rgba(59,73,75,0.3)' }}>
                  View Full Intel Report
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
