'use client';

import { useState, useEffect } from 'react';

interface SoarStats {
  total_workflows: number;
  active_workflows: number;
  success: number;
  failed: number;
  pending: number;
  health_pct: number;
}

export default function SOARPage() {
  const [stats, setStats] = useState<SoarStats | null>(null);
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [creds, setCreds] = useState({ id: '', token: '' });
  const [authLoading, setAuthLoading] = useState(false);

  const SHUFFLE_URL = process.env.NEXT_PUBLIC_SHUFFLE_URL ?? 'https://shuffler.io';

  useEffect(() => {
    fetch('/api/soar/stats').then(r => r.json()).then(setStats).catch(() => {});
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    await new Promise(r => setTimeout(r, 600));
    setAuthenticated(true);
    setAuthLoading(false);
  };

  const PLAYBOOKS = [
    { name: 'Ransomware Response', status: 'running', executions: 12, last: '2m ago', color: '#ffb4ab' },
    { name: 'Brute Force Containment', status: 'success', executions: 48, last: '15m ago', color: '#72ff70' },
    { name: 'IOC Enrichment Pipeline', status: 'success', executions: 234, last: '1h ago', color: '#72ff70' },
    { name: 'Endpoint Isolation', status: 'success', executions: 7, last: '3h ago', color: '#72ff70' },
    { name: 'Threat Hunt Trigger', status: 'failed', executions: 3, last: '6h ago', color: '#ffd770' },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-6 pt-5 pb-4 shrink-0 border-b" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="font-bold text-xl text-[#dee2f1] tracking-tight">SOAR Automation</h1>
            <p className="font-mono text-[11px] text-[#849495] mt-0.5">Security Orchestration & Automated Response</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase transition-all"
            style={{ background: '#00f0ff', color: '#003a3e' }}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            Run Playbook
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-5 gap-3">
          {[
            { label: 'Total Workflows', value: stats?.total_workflows ?? 42, color: '#dee2f1' },
            { label: 'Active Now',      value: stats?.active_workflows ?? 8,  color: '#00f0ff' },
            { label: 'Successful',      value: stats?.success ?? 42,          color: '#72ff70' },
            { label: 'Failed',          value: stats?.failed ?? 3,            color: '#ffb4ab' },
            { label: 'Pending',         value: stats?.pending ?? 12,          color: '#ffd770' },
          ].map((s) => (
            <div key={s.label} className="glass-card rounded-lg p-3 text-center">
              <p className="font-mono text-[9px] tracking-widest uppercase text-[#849495] mb-1">{s.label}</p>
              <p className="font-mono text-[20px] font-bold" style={{ color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Playbook Sidebar */}
        <div className="w-72 shrink-0 border-r overflow-y-auto p-4 space-y-3"
          style={{ borderColor: 'rgba(59,73,75,0.2)', background: 'rgba(9,14,24,0.5)' }}>
          <p className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#849495]">
            Active Playbooks
          </p>
          {PLAYBOOKS.map((p, i) => (
            <div key={i} className="p-3 rounded-lg cursor-pointer hover:bg-white/5 transition-colors"
              style={{ background: 'rgba(27,32,42,0.5)', border: '1px solid rgba(59,73,75,0.3)' }}>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: p.color }} />
                <p className="font-mono text-[12px] font-bold text-[#dee2f1] flex-1 truncate">{p.name}</p>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-[10px] text-[#849495]">{p.executions} runs</span>
                <span className="font-mono text-[10px] text-[#849495]">{p.last}</span>
              </div>
            </div>
          ))}

          {/* Health indicator */}
          <div className="mt-4 p-3 rounded-lg" style={{ background: 'rgba(0,240,255,0.05)', border: '1px solid rgba(0,240,255,0.1)' }}>
            <p className="font-mono text-[10px] text-[#849495] mb-2">SOAR EFFICIENCY</p>
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 40 40">
                  <circle cx="20" cy="20" r="16" fill="none" stroke="rgba(59,73,75,0.3)" strokeWidth="4" />
                  <circle cx="20" cy="20" r="16" fill="none" stroke="#7000ff" strokeWidth="4"
                    strokeDasharray={`${2 * Math.PI * 16 * (stats?.health_pct ?? 94) / 100} ${2 * Math.PI * 16}`}
                    strokeLinecap="round" />
                </svg>
                <span className="absolute inset-0 flex items-center justify-center font-mono text-[9px] font-bold text-white">
                  {stats?.health_pct ?? 94}%
                </span>
              </div>
              <div>
                <p className="font-mono text-[12px] font-bold text-[#dee2f1]">Health Nominal</p>
                <p className="font-mono text-[10px] text-[#849495]">{stats?.active_workflows ?? 42} Active Playbooks</p>
              </div>
            </div>
          </div>
        </div>

        {/* Shuffle iframe or auth */}
        <div className="flex-1 relative overflow-hidden">
          {!authenticated ? (
            <div className="absolute inset-0 flex items-center justify-center"
              style={{ background: 'rgba(14,19,29,0.85)', backdropFilter: 'blur(6px)' }}>
              <div className="w-full max-w-md mx-6 rounded-2xl overflow-hidden"
                style={{ background: '#1b202a', border: '1px solid rgba(59,73,75,0.4)', boxShadow: '0 24px 64px rgba(0,0,0,0.7)' }}>
                <div className="p-8">
                  <div className="flex justify-center mb-5">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
                      style={{ background: 'rgba(112,0,255,0.15)', border: '1px solid rgba(112,0,255,0.3)' }}>
                      <svg className="w-7 h-7 text-[#d1bcff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                  </div>
                  <h2 className="text-center font-bold text-lg text-[#dee2f1] mb-1">Shuffle SOAR Access</h2>
                  <p className="text-center font-mono text-[11px] text-[#849495] mb-5">
                    Enter your Shuffle credentials to continue
                  </p>
                  <form onSubmit={handleAuth} className="space-y-3">
                    <input type="text" placeholder="Operator ID" value={creds.id}
                      onChange={e => setCreds(p => ({ ...p, id: e.target.value }))}
                      className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.5)' }} />
                    <input type="password" placeholder="••••••••" value={creds.token}
                      onChange={e => setCreds(p => ({ ...p, token: e.target.value }))}
                      className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.5)' }} />
                    <button type="submit" disabled={authLoading || !creds.id || !creds.token}
                      className="w-full py-3 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase"
                      style={{ background: '#7000ff', color: '#e9ddff' }}>
                      {authLoading ? 'AUTHORIZING...' : 'AUTHORIZE ACCESS'}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          ) : (
            <>
              {!iframeLoaded && (
                <div className="absolute inset-0 flex items-center justify-center z-10"
                  style={{ background: 'rgba(14,19,29,0.9)' }}>
                  <svg className="w-8 h-8 text-[#7000ff] animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                </div>
              )}
              <iframe src={SHUFFLE_URL} title="Shuffle SOAR"
                onLoad={() => setIframeLoaded(true)}
                className="w-full h-full border-none" />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
