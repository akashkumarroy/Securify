import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
import TopBar from '@/components/layout/TopBar';
import Sidebar from '@/components/layout/Sidebar';
import FooterBar from '@/components/layout/FooterBar';

async function getCurrentUser() {
  const cookieStore = cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const payload = verifyToken(token);
  if (!payload) return null;

  const user = await queryOne(
    `SELECT u.id, u.username, u.email, u.full_name, u.role,
            u.tenant_id, u.last_login,
            t.name AS tenant_name, t.uid AS tenant_uid,
            t.wazuh_group, t.status AS tenant_status, t.threat_score
     FROM users u
     LEFT JOIN tenants t ON t.id = u.tenant_id
     WHERE u.id = $1 AND u.is_active = true`,
    [payload.sub],
  );
  return user;
}

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect('/');

  return (
    <div className="portal-layout">
      <TopBar user={user as Record<string,unknown>} className="portal-topbar" />
      <Sidebar user={user as Record<string,unknown>} className="portal-sidebar" />
      <main className="portal-main bg-background">
        {children}
      </main>
      <FooterBar className="portal-footer" />
    </div>
  );
}
