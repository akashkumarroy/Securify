'use client';

import { useState } from 'react';

export default function SettingsPage() {
  const [saved, setSaved] = useState(false);
  const [section, setSection] = useState<'general' | 'integrations' | 'security'>('general');

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="p-6 min-h-full">
      <div className="mb-6">
        <h1 className="font-bold text-2xl text-[#dee2f1] tracking-tight">Portal Settings</h1>
        <p className="font-mono text-[11px] text-[#849495] mt-0.5">Configure Prime SOC portal integrations and preferences</p>
      </div>

      <div className="flex gap-6">
        {/* Sidebar tabs */}
        <div className="w-48 shrink-0 space-y-1">
          {[
            { id: 'general',      label: 'General' },
            { id: 'integrations', label: 'Integrations' },
            { id: 'security',     label: 'Security' },
          ].map((t) => (
            <button key={t.id} onClick={() => setSection(t.id as typeof section)}
              className="w-full text-left px-3 py-2 rounded-lg font-mono text-[12px] transition-colors"
              style={{
                background: section === t.id ? 'rgba(0,240,255,0.1)' : 'transparent',
                color: section === t.id ? '#00f0ff' : '#849495',
                borderLeft: section === t.id ? '2px solid #00f0ff' : '2px solid transparent',
              }}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 max-w-2xl space-y-4">
          {section === 'general' && (
            <>
              <div className="glass-card rounded-xl p-5 space-y-4">
                <h3 className="font-mono text-[12px] font-bold tracking-widest uppercase text-[#b9cacb]">Portal Identity</h3>
                {[
                  { label: 'Portal Name', defaultValue: 'Prime SOC' },
                  { label: 'Organization', defaultValue: 'Vanguard Ops' },
                ].map((f) => (
                  <div key={f.label}>
                    <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#849495] mb-1.5 block">{f.label}</label>
                    <input defaultValue={f.defaultValue}
                      className="w-full bg-black/30 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.4)' }} />
                  </div>
                ))}
              </div>
              <div className="glass-card rounded-xl p-5 space-y-4">
                <h3 className="font-mono text-[12px] font-bold tracking-widest uppercase text-[#b9cacb]">Session</h3>
                <div>
                  <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#849495] mb-1.5 block">
                    Session Timeout (hours)
                  </label>
                  <input type="number" defaultValue={8} min={1} max={24}
                    className="w-32 bg-black/30 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                    style={{ border: '1px solid rgba(59,73,75,0.4)' }} />
                </div>
              </div>
            </>
          )}

          {section === 'integrations' && (
            <div className="glass-card rounded-xl p-5 space-y-5">
              <h3 className="font-mono text-[12px] font-bold tracking-widest uppercase text-[#b9cacb]">Tool URLs</h3>
              <p className="font-mono text-[11px] text-[#849495]">
                Update these when your tools change IP/domain. Restart the portal after saving.
              </p>
              {[
                { label: 'Wazuh Dashboard URL', key: 'WAZUH_DASHBOARD_URL', placeholder: 'https://wazuh.yourdomain.com', color: '#00f0ff' },
                { label: 'OpenCTI URL',         key: 'OPENCTI_URL',         placeholder: 'http://10.0.7.93:8080',        color: '#d1bcff' },
                { label: 'Shuffle (SOAR) URL',  key: 'SHUFFLE_URL',         placeholder: 'https://shuffler.io',          color: '#7000ff' },
                { label: 'IRIS URL',            key: 'IRIS_URL',            placeholder: 'https://10.0.7.93:4433',       color: '#ffb4ab' },
                { label: 'MISP URL',            key: 'MISP_URL',            placeholder: 'https://10.0.7.93',            color: '#ffd770' },
              ].map((f) => (
                <div key={f.key}>
                  <label className="font-mono text-[10px] font-bold tracking-widest uppercase mb-1.5 flex items-center gap-2"
                    style={{ color: f.color }}>
                    <div className="w-2 h-2 rounded-full" style={{ background: f.color }} />
                    {f.label}
                  </label>
                  <input defaultValue={f.placeholder}
                    className="w-full bg-black/30 text-[#dee2f1] font-mono text-[12px] p-3 rounded-lg outline-none"
                    style={{ border: `1px solid ${f.color}30` }} />
                </div>
              ))}
              <div className="p-3 rounded-lg flex items-start gap-2"
                style={{ background: 'rgba(255,215,112,0.08)', border: '1px solid rgba(255,215,112,0.2)' }}>
                <svg className="w-4 h-4 text-[#ffd770] shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="font-mono text-[11px] text-[#ffd770]">
                  URL changes require updating your .env file and restarting Docker containers.
                  These fields are for reference only in this UI.
                </p>
              </div>
            </div>
          )}

          {section === 'security' && (
            <div className="glass-card rounded-xl p-5 space-y-5">
              <h3 className="font-mono text-[12px] font-bold tracking-widest uppercase text-[#b9cacb]">Security Settings</h3>
              {[
                { label: 'Enforce HTTPS', description: 'Redirect all HTTP to HTTPS', enabled: true },
                { label: 'Audit Logging', description: 'Log all user actions to database', enabled: true },
                { label: 'IP Rate Limiting', description: 'Limit login attempts per IP', enabled: true },
                { label: 'SSO Integration', description: 'SAML/OIDC single sign-on (future roadmap)', enabled: false },
              ].map((s) => (
                <div key={s.label} className="flex items-center justify-between py-2 border-b last:border-0"
                  style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
                  <div>
                    <p className="font-mono text-[13px] font-bold text-[#dee2f1]">{s.label}</p>
                    <p className="font-mono text-[11px] text-[#849495] mt-0.5">{s.description}</p>
                  </div>
                  <div className="relative w-10 h-5 rounded-full cursor-pointer transition-colors"
                    style={{ background: s.enabled ? '#00f0ff' : 'rgba(59,73,75,0.5)' }}>
                    <div className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all"
                      style={{ left: s.enabled ? '22px' : '2px' }} />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Save Button */}
          <button onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2.5 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase transition-all"
            style={{ background: saved ? '#72ff70' : '#00f0ff', color: '#003a3e' }}>
            {saved ? (
              <>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                SAVED
              </>
            ) : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
}
