'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  BarChart, Bar, AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid,
} from 'recharts';

// ── Types ─────────────────────────────────────────────────────
interface Alert {
  id: string;
  timestamp: string;
  severity: string;
  source: string;
  event_name: string;
  status: string;
  rule_level: number;
}

interface WazuhStats {
  agents: {
    total_agents: number;
    active_agents: number;
    disconnected_agents: number;
    endpoint_health_pct: number;
  } | null;
  critical_alerts: number;
}

interface SoarStats {
  total_workflows: number;
  active_workflows: number;
  success: number;
  failed: number;
  pending: number;
  health_pct: number;
}

// ── EPS Simulation ────────────────────────────────────────────
function generateEPS(count = 30) {
  const base = 14200;
  return Array.from({ length: count }, (_, i) => ({
    t: `${String(Math.floor(i / 2)).padStart(2, '0')}:${i % 2 === 0 ? '00' : '30'}`,
    v: Math.round(base + (Math.random() - 0.5) * 4000),
  }));
}

// ── MITRE grid ────────────────────────────────────────────────
const MITRE_CELLS = Array.from({ length: 30 }, (_, i) => {
  const id = `T${1000 + i}`;
  const r = Math.random();
  const severity = r > 0.85 ? 'critical' : r > 0.7 ? 'high' : r > 0.5 ? 'medium' : 'none';
  return { id, severity };
});

const MITRE_COLOR: Record<string, string> = {
  critical: 'rgba(147,0,10,0.7)',
  high:     'rgba(150,80,0,0.5)',
  medium:   'rgba(80,60,0,0.5)',
  none:     'rgba(48,53,64,0.6)',
};

// ── Severity Badge ────────────────────────────────────────────
function SeverityBadge({ sev }: { sev: string }) {
  const cls: Record<string, string> = {
    CRITICAL: 'badge-critical',
    HIGH:     'badge-high',
    MEDIUM:   'badge-medium',
    LOW:      'badge-low',
    INFO:     'badge-info',
  };
  return (
    <span className={`inline-block font-mono text-[10px] font-bold tracking-widest uppercase px-2 py-0.5 rounded ${cls[sev] ?? 'badge-info'}`}>
      {sev}
    </span>
  );
}

// ── Urgent Incident Toast ─────────────────────────────────────
function UrgentIncident({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed bottom-12 right-6 z-50 w-80 rounded-xl overflow-hidden shadow-2xl animate-slide-in-up"
      style={{ background: '#1b202a', border: '1px solid rgba(255,180,171,0.3)' }}>
      <div className="flex items-center gap-2 px-4 py-2.5"
        style={{ background: 'rgba(147,0,10,0.3)', borderBottom: '1px solid rgba(255,180,171,0.2)' }}>
        <span className="text-[#ffb4ab] text-[10px] font-mono font-bold tracking-widest uppercase flex items-center gap-1.5">
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2L1 21h22L12 2zm0 3.5L20.5 19H3.5L12 5.5zm-1 5v4h2v-4h-2zm0 6v2h2v-2h-2z" />
          </svg>
          URGENT INCIDENT
        </span>
        <button onClick={onClose} className="ml-auto text-[#849495] hover:text-white transition-colors">
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
      <div className="px-4 py-3">
        <p className="font-mono text-[12px] font-bold text-[#dee2f1] mb-1">
          Ransomware Lateral Movement Detected
        </p>
        <p className="font-mono text-[10px] text-[#849495] leading-relaxed">
          Host: FS-04-NYC &nbsp;|&nbsp; Path: /var/lib/backups &nbsp;|&nbsp; Entropy Anomaly &gt; 8.0
        </p>
        <div className="flex gap-2 mt-3">
          <button className="flex-1 py-1.5 rounded-lg font-mono text-[10px] font-bold tracking-widest uppercase transition-all"
            style={{ background: '#ffb4ab', color: '#690005' }}>
            Isolate Host
          </button>
          <button className="flex-1 py-1.5 rounded-lg font-mono text-[10px] font-bold tracking-widest uppercase transition-all text-[#dee2f1]"
            style={{ border: '1px solid rgba(59,73,75,0.4)' }}>
            View Detail
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Custom EPS Tooltip ────────────────────────────────────────
function EPSTooltip({ active, payload }: { active?: boolean; payload?: { value: number }[] }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-card px-3 py-2 rounded-lg">
      <p className="font-mono text-[11px] text-[#00f0ff]">{payload[0].value.toLocaleString()} eps</p>
    </div>
  );
}

// ── Main Dashboard ────────────────────────────────────────────
export default function DashboardPage() {
  const [epsData, setEpsData] = useState(() => generateEPS());
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [wazuhStats, setWazuhStats] = useState<WazuhStats | null>(null);
  const [soarStats, setSoarStats] = useState<SoarStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showUrgent, setShowUrgent] = useState(true);

  // Live EPS ticker
  useEffect(() => {
    const id = setInterval(() => {
      setEpsData((prev) => [
        ...prev.slice(1),
        { t: 'now', v: Math.round(14200 + (Math.random() - 0.5) * 4000) },
      ]);
    }, 3000);
    return () => clearInterval(id);
  }, []);

  const fetchData = useCallback(async () => {
    try {
      const [alertsRes, statsRes, soarRes] = await Promise.allSettled([
        fetch('/api/wazuh/alerts?limit=20'),
        fetch('/api/wazuh/stats'),
        fetch('/api/soar/stats'),
      ]);

      if (alertsRes.status === 'fulfilled' && alertsRes.value.ok) {
        const d = await alertsRes.value.json();
        setAlerts(d.alerts ?? []);
      }
      if (statsRes.status === 'fulfilled' && statsRes.value.ok) {
        const d = await statsRes.value.json();
        setWazuhStats(d);
      }
      if (soarRes.status === 'fulfilled' && soarRes.value.ok) {
        const d = await soarRes.value.json();
        setSoarStats(d);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Auto-refresh every 30s
  useEffect(() => {
    const id = setInterval(fetchData, 30_000);
    return () => clearInterval(id);
  }, [fetchData]);

  const currentEPS = epsData[epsData.length - 1]?.v ?? 14200;
  const totalAgents = wazuhStats?.agents?.total_agents ?? 0;
  const healthPct   = wazuhStats?.agents?.endpoint_health_pct ?? 0;
  const critAlerts  = wazuhStats?.critical_alerts ?? 0;
  const soarPct     = soarStats?.health_pct ?? 75;

  return (
    <div className="p-5 space-y-5 min-h-full">
      {/* ── Row 1: EPS + SOAR ─────────────────────────────── */}
      <div className="grid grid-cols-3 gap-5">
        {/* EPS Chart */}
        <div className="col-span-2 glass-card rounded-xl p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-[#849495]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              <span className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#b9cacb]">
                Events Per Second (EPS) Live
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#72ff70] status-dot-live" />
              <span className="font-mono text-[12px] font-bold text-[#dee2f1]">
                STABLE: {(currentEPS / 1000).toFixed(1)}k
              </span>
            </div>
          </div>
          <div className="h-36">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={epsData} barSize={6} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
                <CartesianGrid vertical={false} stroke="rgba(59,73,75,0.2)" />
                <XAxis dataKey="t" hide />
                <YAxis hide domain={['auto', 'auto']} />
                <Tooltip content={<EPSTooltip />} cursor={{ fill: 'rgba(0,240,255,0.05)' }} />
                <Bar dataKey="v" fill="rgba(0,240,255,0.5)" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* SOAR Playbook Status */}
        <div className="glass-card rounded-xl p-4 flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <svg className="w-4 h-4 text-[#849495]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#b9cacb]">
              SOAR Playbook Status
            </span>
          </div>

          {/* Donut chart — CSS-based */}
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="relative w-28 h-28 mb-4">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(59,73,75,0.3)" strokeWidth="12" />
                <circle cx="50" cy="50" r="40" fill="none" stroke="#00f0ff" strokeWidth="12"
                  strokeDasharray={`${2 * Math.PI * 40 * soarPct / 100} ${2 * Math.PI * 40}`}
                  strokeLinecap="round"
                  style={{ filter: 'drop-shadow(0 0 6px rgba(0,240,255,0.6))' }} />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-mono text-[22px] font-bold text-white">{soarPct}%</span>
                <span className="font-mono text-[9px] text-[#849495] uppercase tracking-widest">Active</span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 w-full text-center">
              {[
                { label: 'SUCCESS', val: soarStats?.success ?? 42, color: '#72ff70' },
                { label: 'FAILED',  val: soarStats?.failed  ?? 3,  color: '#ffb4ab' },
                { label: 'PENDING', val: soarStats?.pending  ?? 12, color: '#ffd770' },
              ].map((s) => (
                <div key={s.label}>
                  <p className="font-mono text-[11px] font-bold" style={{ color: s.color }}>{s.val}</p>
                  <p className="font-mono text-[9px] text-[#849495]">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── Row 2: MITRE Heatmap + Alert Feed ─────────────── */}
      <div className="grid grid-cols-5 gap-5">
        {/* MITRE ATT&CK */}
        <div className="col-span-2 glass-card rounded-xl p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-[#849495]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
                  d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 13a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-4a1 1 0 01-1-1v-6z" />
              </svg>
              <span className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#b9cacb]">
                MITRE ATT&amp;CK Heatmap
              </span>
            </div>
            <button className="text-[#849495] hover:text-[#00f0ff] transition-colors">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5" />
              </svg>
            </button>
          </div>
          <div className="grid grid-cols-5 gap-1">
            {MITRE_CELLS.map((cell) => (
              <div
                key={cell.id}
                title={cell.id}
                className="rounded p-1 cursor-pointer hover:opacity-80 transition-opacity"
                style={{ background: MITRE_COLOR[cell.severity], minHeight: 28 }}
              >
                <p className="font-mono text-[8px] text-white/60 leading-none">{cell.id}</p>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-3 mt-3">
            {Object.entries({ Critical: 'critical', High: 'high', Medium: 'medium', None: 'none' }).map(([label, sev]) => (
              <div key={label} className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-sm" style={{ background: MITRE_COLOR[sev] }} />
                <span className="font-mono text-[9px] text-[#849495]">{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Real-Time Alert Feed */}
        <div className="col-span-3 glass-card rounded-xl p-4 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-[#ffd770]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
                  d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
              </svg>
              <span className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#b9cacb]">
                Real-Time Alert Feed
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="badge-critical font-mono text-[10px] px-2 py-0.5 rounded">
                CRITICAL: {critAlerts}
              </span>
              <span className="badge-info font-mono text-[10px] px-2 py-0.5 rounded">
                INFO: {alerts.filter(a => a.severity === 'INFO').length}
              </span>
            </div>
          </div>

          <div className="overflow-auto flex-1">
            {loading ? (
              <div className="space-y-2 p-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="skeleton h-10 rounded-lg" />
                ))}
              </div>
            ) : alerts.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-32 text-[#849495]">
                <svg className="w-8 h-8 mb-2 opacity-40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="font-mono text-[11px]">No active alerts</p>
              </div>
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Time</th>
                    <th>Severity</th>
                    <th>Source</th>
                    <th>Event Name</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {alerts.slice(0, 10).map((a) => (
                    <tr key={a.id} className="cursor-pointer">
                      <td className="text-[#849495]">
                        {a.timestamp ? new Date(a.timestamp).toLocaleTimeString('en-GB', { hour12: false }) : '—'}
                      </td>
                      <td><SeverityBadge sev={a.severity} /></td>
                      <td className="text-[#b9cacb]">{a.source}</td>
                      <td className="text-[#dee2f1] max-w-[200px] truncate">{a.event_name}</td>
                      <td>
                        <span className="flex items-center gap-1.5 font-mono text-[11px] text-[#b9cacb]">
                          {a.status === 'Triaging' && <span className="w-1.5 h-1.5 rounded-full bg-[#ffb4ab] status-dot-live" />}
                          {a.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {/* ── Row 3: Stats Row ───────────────────────────────── */}
      <div className="grid grid-cols-4 gap-4">
        {[
          {
            label: 'Total Agents',
            value: totalAgents.toLocaleString(),
            sub: `${wazuhStats?.agents?.active_agents ?? 0} active`,
            color: '#00f0ff',
            icon: 'M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2',
          },
          {
            label: 'Critical Alerts',
            value: critAlerts.toString(),
            sub: 'Level 12+ severity',
            color: '#ffb4ab',
            icon: 'M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z',
          },
          {
            label: 'Endpoint Health',
            value: `${healthPct}%`,
            sub: 'Healthy endpoints',
            color: '#72ff70',
            icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
          },
          {
            label: 'Events Scanned',
            value: `${(currentEPS / 1000).toFixed(1)}k/s`,
            sub: 'Events per second',
            color: '#d1bcff',
            icon: 'M13 10V3L4 14h7v7l9-11h-7z',
          },
        ].map((stat) => (
          <div key={stat.label} className="glass-card rounded-xl p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: `${stat.color}15` }}>
              <svg className="w-5 h-5" style={{ color: stat.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d={stat.icon} />
              </svg>
            </div>
            <div>
              <p className="font-mono text-[11px] text-[#849495] uppercase tracking-wider">{stat.label}</p>
              <p className="font-mono text-[20px] font-bold" style={{ color: stat.color }}>{stat.value}</p>
              <p className="font-mono text-[10px] text-[#849495]">{stat.sub}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Row 4: Global Attack Map placeholder ──────────── */}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="p-3 border-b" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
          <p className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#b9cacb]">
            Global Attack Vector Map
          </p>
          <p className="font-mono text-[10px] text-[#849495] mt-0.5">
            Active Sessions: 4,912 &nbsp;|&nbsp; Detected Threats: {critAlerts + 12}
          </p>
        </div>
        <div className="h-40 flex items-center justify-center relative overflow-hidden"
          style={{ background: 'rgba(0,0,0,0.3)' }}>
          {/* Animated map dots */}
          <div className="absolute inset-0 bg-grid-pattern opacity-30" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-full h-full overflow-hidden opacity-40"
              style={{ backgroundImage: 'radial-gradient(ellipse at 30% 50%, rgba(0,240,255,0.08) 0%, transparent 60%), radial-gradient(ellipse at 70% 40%, rgba(112,0,255,0.08) 0%, transparent 60%)' }}>
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i}
                  className="absolute w-1.5 h-1.5 rounded-full"
                  style={{
                    left: `${15 + (i * 7) % 70}%`,
                    top: `${20 + (i * 13) % 60}%`,
                    background: i % 3 === 0 ? '#ffb4ab' : i % 3 === 1 ? '#00f0ff' : '#72ff70',
                    boxShadow: `0 0 6px ${i % 3 === 0 ? '#ffb4ab' : i % 3 === 1 ? '#00f0ff' : '#72ff70'}`,
                    animation: `status-blink ${1.5 + (i * 0.3)}s ease-in-out infinite`,
                    animationDelay: `${i * 0.2}s`,
                  }}
                />
              ))}
            </div>
          </div>
          <p className="relative font-mono text-[11px] text-[#849495]">
            Threat map visualization — Real-time telemetry active
          </p>
        </div>
      </div>

      {/* Urgent Incident Toast */}
      {showUrgent && <UrgentIncident onClose={() => setShowUrgent(false)} />}
    </div>
  );
}
