'use client';

import { useState, useEffect } from 'react';

interface Agent {
  id: string;
  name: string;
  ip?: string;
  status: string;
  os?: { name: string; version: string; platform: string };
  group?: string[];
  version?: string;
  lastKeepAlive?: string;
  dateAdd?: string;
}

const STATUS_STYLE: Record<string, { color: string; bg: string; border: string }> = {
  active:           { color: '#72ff70', bg: 'rgba(0,80,0,0.3)',   border: 'rgba(114,255,112,0.3)' },
  disconnected:     { color: '#ffb4ab', bg: 'rgba(147,0,10,0.2)', border: 'rgba(255,180,171,0.2)' },
  never_connected:  { color: '#849495', bg: 'rgba(40,50,60,0.3)', border: 'rgba(132,148,149,0.2)' },
  pending:          { color: '#ffd770', bg: 'rgba(100,70,0,0.2)', border: 'rgba(255,215,112,0.2)' },
};

export default function AssetsPage() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [total, setTotal] = useState(0);

  useEffect(() => {
    fetch('/api/wazuh/agents')
      .then(r => r.json())
      .then(d => {
        setAgents(d.agents ?? []);
        setTotal(d.total ?? 0);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const filtered = agents.filter(a => {
    const matchesText = !filter ||
      a.name.toLowerCase().includes(filter.toLowerCase()) ||
      (a.ip ?? '').includes(filter) ||
      a.id.includes(filter);
    const matchesStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchesText && matchesStatus;
  });

  const counts = {
    active:       agents.filter(a => a.status === 'active').length,
    disconnected: agents.filter(a => a.status === 'disconnected').length,
    pending:      agents.filter(a => a.status === 'pending').length,
  };

  const healthPct = total > 0 ? Math.round((counts.active / total) * 100) : 0;

  return (
    <div className="p-6 min-h-full space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-2xl text-[#dee2f1] tracking-tight">Assets & Endpoints</h1>
          <p className="font-mono text-[11px] text-[#849495] mt-0.5">
            {total.toLocaleString()} managed endpoints via Wazuh
          </p>
        </div>
        <button onClick={() => { setLoading(true); fetch('/api/wazuh/agents').then(r=>r.json()).then(d=>{setAgents(d.agents??[]);setTotal(d.total??0)}).finally(()=>setLoading(false)); }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg font-mono text-[11px] transition-colors"
          style={{ border: '1px solid rgba(59,73,75,0.4)', color: '#b9cacb' }}>
          <svg className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Refresh
        </button>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Total Agents',    value: total,              color: '#dee2f1', status: 'all' },
          { label: 'Active',          value: counts.active,      color: '#72ff70', status: 'active' },
          { label: 'Disconnected',    value: counts.disconnected, color: '#ffb4ab', status: 'disconnected' },
          { label: 'Endpoint Health', value: `${healthPct}%`,   color: '#00f0ff', status: 'all' },
        ].map((s) => (
          <button key={s.label}
            onClick={() => setStatusFilter(s.status)}
            className="glass-card-hover rounded-xl p-4 text-left transition-all"
            style={statusFilter === s.status && s.status !== 'all'
              ? { borderColor: s.color, boxShadow: `0 0 12px ${s.color}30` } : {}}>
            <p className="font-mono text-[10px] tracking-widest uppercase text-[#849495] mb-1">{s.label}</p>
            <p className="font-mono text-[22px] font-bold" style={{ color: s.color }}>
              {typeof s.value === 'number' ? s.value.toLocaleString() : s.value}
            </p>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#849495]"
            fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input value={filter} onChange={e => setFilter(e.target.value)}
            placeholder="Search by name, IP, ID..."
            className="w-full pl-8 pr-3 py-1.5 bg-black/30 font-mono text-[12px] text-[#dee2f1] rounded-lg outline-none"
            style={{ border: '1px solid rgba(59,73,75,0.4)' }} />
        </div>
        <div className="flex gap-1">
          {['all', 'active', 'disconnected', 'pending'].map((s) => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className="font-mono text-[10px] px-3 py-1.5 rounded-lg capitalize transition-colors"
              style={{
                background: statusFilter === s ? 'rgba(0,240,255,0.12)' : 'transparent',
                border: `1px solid ${statusFilter === s ? 'rgba(0,240,255,0.3)' : 'rgba(59,73,75,0.3)'}`,
                color: statusFilter === s ? '#00f0ff' : '#849495',
              }}>
              {s}
            </button>
          ))}
        </div>
        <span className="font-mono text-[11px] text-[#849495] ml-auto">
          {filtered.length} of {agents.length} shown
        </span>
      </div>

      {/* Agent Table */}
      <div className="glass-card rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 flex flex-col items-center gap-3">
            <svg className="w-8 h-8 text-[#00f0ff] animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
            <p className="font-mono text-[12px] text-[#849495]">Fetching agents from Wazuh…</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center">
            <p className="font-mono text-[12px] text-[#849495]">No agents match your filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Agent ID</th>
                  <th>Name</th>
                  <th>IP Address</th>
                  <th>OS</th>
                  <th>Group</th>
                  <th>Version</th>
                  <th>Last Keepalive</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 100).map((agent) => {
                  const st = STATUS_STYLE[agent.status] ?? STATUS_STYLE.pending;
                  return (
                    <tr key={agent.id}>
                      <td className="font-mono text-[11px] text-[#849495]">{agent.id}</td>
                      <td className="font-mono text-[12px] font-bold text-[#dee2f1]">{agent.name}</td>
                      <td className="font-mono text-[11px] text-[#b9cacb]">{agent.ip ?? '—'}</td>
                      <td className="font-mono text-[11px] text-[#b9cacb]">
                        {agent.os ? `${agent.os.name} ${agent.os.version}` : '—'}
                      </td>
                      <td className="font-mono text-[11px] text-[#849495]">
                        {agent.group?.join(', ') ?? '—'}
                      </td>
                      <td className="font-mono text-[11px] text-[#849495]">{agent.version ?? '—'}</td>
                      <td className="font-mono text-[11px] text-[#849495]">
                        {agent.lastKeepAlive
                          ? new Date(agent.lastKeepAlive).toLocaleString()
                          : '—'}
                      </td>
                      <td>
                        <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded capitalize"
                          style={{ background: st.bg, color: st.color, border: `1px solid ${st.border}` }}>
                          {agent.status.replace('_', ' ')}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length > 100 && (
              <div className="p-3 text-center border-t" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
                <p className="font-mono text-[11px] text-[#849495]">
                  Showing 100 of {filtered.length} agents. Use filters to narrow results.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
