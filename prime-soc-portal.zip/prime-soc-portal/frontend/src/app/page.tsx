'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [time, setTime] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Live UTC clock
  useEffect(() => {
    const tick = () => setTime(new Date().toISOString().split('T')[1].split('.')[0]);
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  // Particle/grid mouse-tracking effect on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let mouse = { x: -9999, y: -9999 };

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', (e) => { mouse.x = e.clientX; mouse.y = e.clientY; });

    const particles: { x: number; y: number; vx: number; vy: number; life: number }[] = [];

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Mouse glow
      const grad = ctx.createRadialGradient(mouse.x, mouse.y, 0, mouse.x, mouse.y, 200);
      grad.addColorStop(0, 'rgba(0,240,255,0.04)');
      grad.addColorStop(1, 'transparent');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Random particles near mouse
      if (Math.random() < 0.3) {
        particles.push({
          x: mouse.x + (Math.random() - 0.5) * 100,
          y: mouse.y + (Math.random() - 0.5) * 100,
          vx: (Math.random() - 0.5) * 0.5,
          vy: -Math.random() * 0.5,
          life: 1,
        });
      }

      particles.forEach((p, i) => {
        p.x += p.vx; p.y += p.vy; p.life -= 0.015;
        if (p.life <= 0) { particles.splice(i, 1); return; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0,240,255,${p.life * 0.4})`;
        ctx.fill();
      });

      animId = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) return;
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim().toLowerCase(), password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? 'Authentication failed');
        return;
      }

      const redirect = searchParams.get('redirect') ?? '/dashboard';
      router.push(redirect);
      router.refresh();
    } catch {
      setError('Network error — please retry');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col items-center justify-center p-6">
      {/* Grid Background */}
      <div className="fixed inset-0 bg-grid-pattern z-0 pointer-events-none" />
      <div className="fixed inset-0 z-0 pointer-events-none"
        style={{ background: 'radial-gradient(circle at center, transparent 0%, #0e131d 80%)' }} />

      {/* Mouse-reactive canvas */}
      <canvas ref={canvasRef} className="fixed inset-0 z-0 pointer-events-none" />

      {/* Ambient glows */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full pointer-events-none z-0"
        style={{ background: 'rgba(0,240,255,0.04)', filter: 'blur(120px)' }} />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full pointer-events-none z-0"
        style={{ background: 'rgba(112,0,255,0.04)', filter: 'blur(120px)' }} />

      {/* Login Container */}
      <main className="relative z-10 w-full max-w-[440px] flex flex-col items-center">
        {/* Branding */}
        <div className="mb-10 text-center space-y-2">
          <h1 className="text-2xl font-bold tracking-tight text-[#00f0ff] flex items-center justify-center gap-2"
            style={{ textShadow: '0 0 20px rgba(0,240,255,0.4)' }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" className="shrink-0">
              <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"
                fill="rgba(0,240,255,0.15)" stroke="#00f0ff" strokeWidth="1.5" />
              <path d="M9 12l2 2 4-4" stroke="#00f0ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            PRIME SOC
          </h1>
          <p className="font-mono text-[11px] text-[#849495] uppercase tracking-[0.3em]">
            Advanced Cyber Defense Terminal
          </p>
        </div>

        {/* Glass Card */}
        <div className="glass-card w-full p-8 rounded-xl relative overflow-hidden">
          {/* Scanning bar */}
          <div className="scanning-bar absolute left-0 right-0" />

          <header className="mb-8">
            <div className="flex justify-between items-end mb-2">
              <span className="font-mono text-[11px] font-bold tracking-[0.12em] uppercase text-[#dbfcff]">
                Authentication Required
              </span>
              <span className="font-mono text-[10px] text-[#849495]">v1.0.0-SECURE</span>
            </div>
            <div className="h-px w-full" style={{ background: 'linear-gradient(to right, rgba(0,240,255,0.3), transparent)' }} />
          </header>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Error Banner */}
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg border"
                style={{ background: 'rgba(147,0,10,0.2)', borderColor: 'rgba(255,180,171,0.3)' }}>
                <svg className="w-4 h-4 text-[#ffb4ab] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.834-1.964-.834-2.732 0L3.07 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
                <span className="font-mono text-[11px] text-[#ffb4ab]">{error}</span>
              </div>
            )}

            {/* Username */}
            <div className="space-y-2">
              <label className="font-mono text-[11px] font-bold tracking-[0.1em] uppercase text-[#b9cacb] flex items-center gap-2">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                Username
              </label>
              <div className="relative group">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter operator ID"
                  autoComplete="username"
                  required
                  className="w-full bg-black/30 text-[#dee2f1] font-mono text-sm p-3 px-4 rounded-lg outline-none transition-all placeholder:text-[#3b494b]"
                  style={{ border: '1px solid rgba(59,73,75,0.4)' }}
                  onFocus={(e) => e.currentTarget.style.borderColor = 'rgba(0,240,255,0.5)'}
                  onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(59,73,75,0.4)'}
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <label className="font-mono text-[11px] font-bold tracking-[0.1em] uppercase text-[#b9cacb] flex items-center gap-2">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
                Access Key
              </label>
              <div className="relative group">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  autoComplete="current-password"
                  required
                  className="w-full bg-black/30 text-[#dee2f1] font-mono text-sm p-3 px-4 rounded-lg outline-none transition-all placeholder:text-[#3b494b]"
                  style={{ border: '1px solid rgba(59,73,75,0.4)' }}
                  onFocus={(e) => e.currentTarget.style.borderColor = 'rgba(0,240,255,0.5)'}
                  onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(59,73,75,0.4)'}
                />
              </div>
            </div>

            {/* MFA status indicator */}
            <div className="flex items-center gap-3 p-3 rounded-lg"
              style={{ background: 'rgba(23,28,38,0.5)', border: '1px solid rgba(59,73,75,0.2)' }}>
              <div className="w-2 h-2 rounded-full bg-[#72ff70] status-dot-live"
                style={{ boxShadow: '0 0 8px rgba(114,255,112,0.6)' }} />
              <span className="font-mono text-[11px] text-[#b9cacb]">Secure Link Active</span>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading || !username || !password}
              className="w-full font-mono text-[11px] font-bold tracking-[0.12em] uppercase py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{
                background: loading ? 'rgba(0,240,255,0.6)' : '#00f0ff',
                color: '#00363a',
              }}
            >
              {loading ? (
                <>
                  <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  AUTHENTICATING...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z" />
                  </svg>
                  SECURE LOGIN
                </>
              )}
            </button>
          </form>

          <footer className="mt-6 flex justify-between items-center">
            <button className="font-mono text-[10px] text-[#849495] hover:text-[#00f0ff] transition-colors">
              Forgot Credentials?
            </button>
            <div className="flex gap-1.5">
              {[0, 1, 2].map((i) => (
                <div key={i} className="w-1 h-1 rounded-full" style={{ background: 'rgba(0,240,255,0.25)' }} />
              ))}
            </div>
          </footer>
        </div>

        {/* Security Warning */}
        <div className="mt-10 text-center max-w-[320px] opacity-60">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-3 rounded-full"
            style={{ border: '1px solid rgba(255,180,171,0.3)', background: 'rgba(255,180,171,0.05)' }}>
            <svg className="w-3 h-3 text-[#ffb4ab]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
            </svg>
            <span className="font-mono text-[10px] text-[#ffb4ab]">Restricted System</span>
          </div>
          <p className="font-mono text-[11px] text-[#b9cacb] leading-relaxed">
            Unauthorized access is prohibited. All activities are monitored and logged.
            By logging in, you agree to Level 4 security protocols.
          </p>
        </div>
      </main>

      {/* Footer Status Bar */}
      <footer className="fixed bottom-0 w-full h-8 flex justify-between items-center px-6 z-50"
        style={{ background: 'rgba(9,14,24,0.7)', backdropFilter: 'blur(8px)', borderTop: '1px solid rgba(59,73,75,0.15)' }}>
        <div className="flex items-center gap-4">
          <span className="font-mono text-[10px] text-[#72ff70] flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#72ff70] status-dot-live" />
            SYSTEM HEALTH: NOMINAL
          </span>
          <span className="w-px h-3" style={{ background: 'rgba(59,73,75,0.4)' }} />
          <span className="font-mono text-[10px] text-[#b9cacb]">ENCRYPTED LINK: STABLE</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-mono text-[10px] text-[#849495]">LATENCY: 14ms</span>
          <span className="font-mono text-[10px] text-[#849495]">UTC: {time}</span>
        </div>
      </footer>
    </div>
  );
}
