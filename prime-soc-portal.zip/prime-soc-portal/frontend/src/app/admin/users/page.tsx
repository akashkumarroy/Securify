'use client';

import { useState, useEffect } from 'react';

interface User {
  id: string; username: string; email: string; full_name: string;
  role: string; tenant_id: string | null; tenant_name?: string;
  is_active: boolean; last_login: string; created_at: string;
}

interface Tenant { id: string; name: string; uid: string; }

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ username: '', password: '', full_name: '', email: '', role: 'client', tenant_id: '' });
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const fetchAll = async () => {
    try {
      const [usersRes, tenantsRes] = await Promise.all([
        fetch('/api/users'),
        fetch('/api/tenants'),
      ]);
      if (usersRes.ok)    setUsers((await usersRes.json()).users ?? []);
      if (tenantsRes.ok)  setTenants((await tenantsRes.json()).tenants ?? []);
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true); setError(''); setSuccess('');
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? 'Failed to create user'); return; }
      setSuccess(`User "${form.username}" created successfully.`);
      setForm({ username: '', password: '', full_name: '', email: '', role: 'client', tenant_id: '' });
      setShowCreate(false);
      fetchAll();
    } finally { setCreating(false); }
  };

  const handleToggle = async (userId: string, isActive: boolean) => {
    await fetch(`/api/users/${userId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_active: !isActive }),
    });
    fetchAll();
  };

  return (
    <div className="p-6 min-h-full">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-bold text-2xl text-[#dee2f1] tracking-tight">User Management</h1>
          <p className="font-mono text-[11px] text-[#849495] mt-0.5">{users.length} portal users registered</p>
        </div>
        <button onClick={() => { setShowCreate(true); setError(''); setSuccess(''); }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase"
          style={{ background: '#00f0ff', color: '#003a3e' }}>
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Add User
        </button>
      </div>

      {success && (
        <div className="mb-4 p-3 rounded-lg font-mono text-[12px]"
          style={{ background: 'rgba(0,80,0,0.3)', border: '1px solid rgba(114,255,112,0.3)', color: '#72ff70' }}>
          {success}
        </div>
      )}

      <div className="glass-card rounded-xl overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th>User</th><th>Role</th><th>Tenant</th>
              <th>Last Login</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="text-center py-8 text-[#849495] font-mono text-[12px]">Loading users…</td></tr>
            ) : users.map((u) => (
              <tr key={u.id}>
                <td>
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center font-mono text-[10px] font-bold text-[#003a3e]"
                      style={{ background: u.role === 'admin' ? '#00f0ff' : '#d1bcff' }}>
                      {(u.full_name || u.username).slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-mono text-[12px] font-bold text-[#dee2f1]">{u.full_name || u.username}</p>
                      <p className="font-mono text-[10px] text-[#849495]">@{u.username}</p>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="font-mono text-[10px] px-2 py-0.5 rounded font-bold uppercase"
                    style={u.role === 'admin'
                      ? { background: 'rgba(0,240,255,0.15)', color: '#00f0ff', border: '1px solid rgba(0,240,255,0.3)' }
                      : { background: 'rgba(209,188,255,0.1)', color: '#d1bcff', border: '1px solid rgba(209,188,255,0.2)' }}>
                    {u.role}
                  </span>
                </td>
                <td className="font-mono text-[12px] text-[#b9cacb]">{u.tenant_name ?? '—'}</td>
                <td className="font-mono text-[11px] text-[#849495]">
                  {u.last_login ? new Date(u.last_login).toLocaleString() : 'Never'}
                </td>
                <td>
                  <span className={`font-mono text-[10px] px-2 py-0.5 rounded ${u.is_active ? 'badge-nominal' : 'badge-info'}`}>
                    {u.is_active ? 'Active' : 'Disabled'}
                  </span>
                </td>
                <td>
                  <button onClick={() => handleToggle(u.id, u.is_active)}
                    className="font-mono text-[10px] px-2 py-0.5 rounded transition-colors text-[#849495] hover:text-[#dee2f1]"
                    style={{ border: '1px solid rgba(59,73,75,0.4)' }}>
                    {u.is_active ? 'Disable' : 'Enable'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Create User Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}>
          <div className="w-full max-w-lg mx-6 rounded-2xl overflow-hidden"
            style={{ background: '#1b202a', border: '1px solid rgba(59,73,75,0.4)', boxShadow: '0 24px 64px rgba(0,0,0,0.8)' }}>
            <div className="flex items-center justify-between p-5 border-b" style={{ borderColor: 'rgba(59,73,75,0.3)' }}>
              <h3 className="font-bold text-[15px] text-[#dee2f1]">Create New User</h3>
              <button onClick={() => setShowCreate(false)} className="text-[#849495] hover:text-white">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <form onSubmit={handleCreate} className="p-5 space-y-4">
              {error && (
                <div className="p-3 rounded-lg font-mono text-[11px]"
                  style={{ background: 'rgba(147,0,10,0.2)', border: '1px solid rgba(255,180,171,0.3)', color: '#ffb4ab' }}>
                  {error}
                </div>
              )}
              {[
                { label: 'Username *',  key: 'username',  type: 'text',     placeholder: 'operator_id' },
                { label: 'Full Name',   key: 'full_name', type: 'text',     placeholder: 'John Doe' },
                { label: 'Email',       key: 'email',     type: 'email',    placeholder: 'ops@company.com' },
                { label: 'Password *',  key: 'password',  type: 'password', placeholder: '••••••••' },
              ].map((f) => (
                <div key={f.key}>
                  <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#b9cacb] mb-1.5 block">{f.label}</label>
                  <input type={f.type} placeholder={f.placeholder} required={f.label.includes('*')}
                    value={(form as Record<string,string>)[f.key]}
                    onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                    className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                    style={{ border: '1px solid rgba(59,73,75,0.5)' }} />
                </div>
              ))}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#b9cacb] mb-1.5 block">Role *</label>
                  <select value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))}
                    className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                    style={{ border: '1px solid rgba(59,73,75,0.5)' }}>
                    <option value="client">Client</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                {form.role === 'client' && (
                  <div>
                    <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#b9cacb] mb-1.5 block">Tenant</label>
                    <select value={form.tenant_id} onChange={e => setForm(p => ({ ...p, tenant_id: e.target.value }))}
                      className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                      style={{ border: '1px solid rgba(59,73,75,0.5)' }}>
                      <option value="">Select tenant…</option>
                      {tenants.map(t => <option key={t.id} value={t.id}>{t.name} ({t.uid})</option>)}
                    </select>
                  </div>
                )}
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowCreate(false)}
                  className="flex-1 py-2.5 rounded-lg font-mono text-[11px] font-bold uppercase text-[#dee2f1]"
                  style={{ border: '1px solid rgba(59,73,75,0.4)' }}>Cancel</button>
                <button type="submit" disabled={creating}
                  className="flex-1 py-2.5 rounded-lg font-mono text-[11px] font-bold uppercase"
                  style={{ background: '#00f0ff', color: '#003a3e' }}>
                  {creating ? 'Creating...' : 'Create User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
