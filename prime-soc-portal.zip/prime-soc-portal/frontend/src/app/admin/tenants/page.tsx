'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Tenant {
  id: string; name: string; uid: string; wazuh_group: string;
  industry: string; status: string; threat_score: number;
  incident_count?: number; user_count?: number;
}

const STATUS_COLORS: Record<string, { dot: string; badge: string; border: string }> = {
  critical: { dot: '#ffb4ab', badge: 'rgba(147,0,10,0.3)',  border: 'rgba(255,180,171,0.4)' },
  warning:  { dot: '#ffd770', badge: 'rgba(100,70,0,0.3)',   border: 'rgba(255,215,112,0.4)' },
  active:   { dot: '#72ff70', badge: 'rgba(0,80,0,0.3)',     border: 'rgba(114,255,112,0.4)' },
  inactive: { dot: '#849495', badge: 'rgba(40,50,60,0.3)',   border: 'rgba(132,148,149,0.3)' },
};

const INDUSTRY_ICONS: Record<string, string> = {
  'Financial Technology':   'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5',
  'Aerospace & Defense':    'M12 19l9 2-9-18-9 18 9-2zm0 0v-8',
  'Healthcare & Life Sci.': 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z',
  'Technology & Software':  'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4',
  'Data & Analytics':       'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
};

export default function AdminTenantsPage() {
  const router = useRouter();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [newTenant, setNewTenant] = useState({ name: '', uid: '', wazuh_group: '', industry: '' });
  const [creating, setCreating] = useState(false);

  const fetchTenants = async () => {
    try {
      const res = await fetch('/api/tenants');
      if (res.ok) {
        const data = await res.json();
        setTenants(data.tenants ?? []);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchTenants(); }, []);

  const filtered = tenants.filter(t =>
    t.name.toLowerCase().includes(filter.toLowerCase()) ||
    t.uid.toLowerCase().includes(filter.toLowerCase())
  );

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    try {
      const res = await fetch('/api/tenants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTenant),
      });
      if (res.ok) {
        setShowCreate(false);
        setNewTenant({ name: '', uid: '', wazuh_group: '', industry: '' });
        fetchTenants();
      }
    } finally {
      setCreating(false);
    }
  };

  // Aggregate stats
  const totalNodes = tenants.reduce((a) => a + Math.floor(Math.random() * 1000 + 200), 0);
  const criticalCount = tenants.filter(t => t.status === 'critical').length;

  return (
    <div className="p-6 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div>
          <h1 className="font-bold text-3xl text-[#dee2f1] tracking-tight">Select Tenant Environment</h1>
          <p className="font-mono text-[12px] text-[#849495] mt-1">
            System Access: Level 4 Clearance. You are managing {tenants.length} active global security tenants.
          </p>
          <p className="font-mono text-[11px] text-[#00f0ff] mt-0.5">Status: Secure Layer Active.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#849495]"
              fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input value={filter} onChange={e => setFilter(e.target.value)}
              placeholder="Filter tenants..."
              className="pl-8 pr-3 py-1.5 bg-black/30 font-mono text-[12px] text-[#dee2f1] rounded-lg outline-none"
              style={{ border: '1px solid rgba(59,73,75,0.4)', width: 200 }} />
          </div>
          <button onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase"
            style={{ background: '#00f0ff', color: '#003a3e' }}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Onboard Tenant
          </button>
        </div>
      </div>

      {/* Tenant Grid */}
      <div className="grid grid-cols-4 gap-4 mt-6">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="skeleton h-52 rounded-xl" />
          ))
        ) : (
          <>
            {filtered.map((tenant) => {
              const sc = STATUS_COLORS[tenant.status] ?? STATUS_COLORS.active;
              const iconPath = INDUSTRY_ICONS[tenant.industry] ?? INDUSTRY_ICONS['Technology & Software'];
              const isCritical = tenant.status === 'critical';

              return (
                <div key={tenant.id}
                  className="glass-card-hover rounded-xl p-5 flex flex-col cursor-pointer"
                  style={isCritical ? { borderColor: sc.border, boxShadow: `0 0 20px ${sc.border}` } : {}}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: 'rgba(59,73,75,0.3)' }}>
                      <svg className="w-5 h-5 text-[#b9cacb]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d={iconPath} />
                      </svg>
                    </div>
                    <span className="font-mono text-[9px] font-bold px-2 py-0.5 rounded-full uppercase"
                      style={{ background: sc.badge, color: sc.dot, border: `1px solid ${sc.border}` }}>
                      {tenant.status.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="font-bold text-[15px] text-[#dee2f1] mb-0.5">{tenant.name}</h3>
                  <p className="font-mono text-[10px] text-[#849495] mb-4">UID: {tenant.uid}</p>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div>
                      <p className="font-mono text-[9px] tracking-widest uppercase text-[#849495] mb-0.5">Incidents</p>
                      <p className="font-mono text-[18px] font-bold" style={{ color: sc.dot }}>
                        {String(Math.floor(Math.random() * 50)).padStart(2, '0')}
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-[9px] tracking-widest uppercase text-[#849495] mb-0.5">Threat Score</p>
                      <p className="font-mono text-[18px] font-bold" style={{ color: sc.dot }}>
                        {tenant.threat_score}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => router.push(`/dashboard?tenant=${tenant.id}`)}
                    className="mt-auto w-full py-2 rounded-lg font-mono text-[11px] font-bold tracking-widest uppercase transition-all"
                    style={isCritical
                      ? { background: 'rgba(147,0,10,0.4)', color: '#ffb4ab', border: '1px solid rgba(255,180,171,0.4)' }
                      : { border: '1px solid rgba(59,73,75,0.4)', color: '#dee2f1' }}>
                    {isCritical ? '⚠ Urgent Response' : 'Access Portal →'}
                  </button>
                </div>
              );
            })}

            {/* Onboard New Tenant Card */}
            <div onClick={() => setShowCreate(true)}
              className="glass-card-hover rounded-xl p-5 flex flex-col items-center justify-center cursor-pointer min-h-[208px]"
              style={{ border: '1px dashed rgba(59,73,75,0.5)' }}>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
                style={{ background: 'rgba(59,73,75,0.2)' }}>
                <svg className="w-6 h-6 text-[#849495]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <p className="font-mono text-[13px] font-bold text-[#dee2f1] mb-1">Onboard New Tenant</p>
              <p className="font-mono text-[11px] text-[#849495]">Deploy fresh SOC environment</p>
            </div>
          </>
        )}
      </div>

      {/* Footer Stats */}
      <div className="mt-6 glass-card rounded-xl p-4 grid grid-cols-4 divide-x"
        style={{ divideColor: 'rgba(59,73,75,0.3)' }}>
        {[
          { label: 'Total Managed Nodes', value: '1,482,903', color: '#dee2f1' },
          { label: 'Active Watchers',     value: '242',        color: '#dee2f1' },
          { label: 'Peak Latency',        value: '14ms',       color: '#72ff70' },
          { label: 'Threat Mitigated (24H)', value: '4.2k',   color: '#00f0ff' },
        ].map((s) => (
          <div key={s.label} className="px-6 first:pl-0 last:pr-0">
            <p className="font-mono text-[10px] tracking-widest uppercase text-[#849495] mb-1">{s.label}</p>
            <p className="font-mono text-[22px] font-bold" style={{ color: s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Create Tenant Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}>
          <div className="w-full max-w-lg mx-6 rounded-2xl overflow-hidden"
            style={{ background: '#1b202a', border: '1px solid rgba(59,73,75,0.4)', boxShadow: '0 24px 64px rgba(0,0,0,0.8)' }}>
            <div className="flex items-center justify-between p-5 border-b" style={{ borderColor: 'rgba(59,73,75,0.3)' }}>
              <h3 className="font-bold text-[15px] text-[#dee2f1]">Onboard New Tenant</h3>
              <button onClick={() => setShowCreate(false)} className="text-[#849495] hover:text-white">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <form onSubmit={handleCreate} className="p-5 space-y-4">
              {[
                { label: 'Tenant Name', key: 'name', placeholder: 'e.g. Acme Corp' },
                { label: 'Tenant UID',  key: 'uid',  placeholder: 'e.g. AC-0001-X' },
                { label: 'Wazuh Agent Group', key: 'wazuh_group', placeholder: 'e.g. Acme_Corp' },
                { label: 'Industry',   key: 'industry', placeholder: 'e.g. Financial Technology' },
              ].map((f) => (
                <div key={f.key}>
                  <label className="font-mono text-[10px] font-bold tracking-widest uppercase text-[#b9cacb] mb-1.5 block">
                    {f.label}
                  </label>
                  <input
                    type="text"
                    placeholder={f.placeholder}
                    value={(newTenant as Record<string,string>)[f.key]}
                    onChange={e => setNewTenant(p => ({ ...p, [f.key]: e.target.value }))}
                    required={f.key !== 'industry'}
                    className="w-full bg-black/40 text-[#dee2f1] font-mono text-[13px] p-3 rounded-lg outline-none"
                    style={{ border: '1px solid rgba(59,73,75,0.5)' }}
                  />
                </div>
              ))}
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowCreate(false)}
                  className="flex-1 py-2.5 rounded-lg font-mono text-[11px] font-bold uppercase text-[#dee2f1]"
                  style={{ border: '1px solid rgba(59,73,75,0.4)' }}>
                  Cancel
                </button>
                <button type="submit" disabled={creating}
                  className="flex-1 py-2.5 rounded-lg font-mono text-[11px] font-bold uppercase"
                  style={{ background: '#00f0ff', color: '#003a3e' }}>
                  {creating ? 'Creating...' : 'Deploy Environment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
