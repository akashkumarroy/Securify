import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
import TopBar from '@/components/layout/TopBar';
import Sidebar from '@/components/layout/Sidebar';
import FooterBar from '@/components/layout/FooterBar';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const cookieStore = cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) redirect('/');

  const payload = verifyToken(token);
  if (!payload || payload.role !== 'admin') redirect('/dashboard');

  const user = await queryOne(
    `SELECT u.id, u.username, u.email, u.full_name, u.role, u.tenant_id
     FROM users u
     WHERE u.id = $1 AND u.is_active = true`,
    [payload.sub],
  );
  if (!user) redirect('/');

  return (
    <div className="portal-layout">
      <TopBar user={user as Record<string, unknown>} className="portal-topbar" />
      <Sidebar user={user as Record<string, unknown>} className="portal-sidebar" />
      <main className="portal-main bg-background">
        {children}
      </main>
      <FooterBar className="portal-footer" />
    </div>
  );
}
