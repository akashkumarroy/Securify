import { NextRequest, NextResponse } from 'next/server';
import { COOKIE_NAME } from '@/lib/auth';
import { query } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;

  if (token) {
    const payload = verifyToken(token);
    if (payload?.jti) {
      // Invalidate session from DB
      await query(`DELETE FROM sessions WHERE token_jti = $1`, [payload.jti]).catch(() => {});
      // Audit log
      await query(
        `INSERT INTO audit_logs (user_id, username, action, resource)
         VALUES ($1, $2, 'LOGOUT', 'auth')`,
        [payload.sub, payload.username],
      ).catch(() => {});
    }
  }

  const response = NextResponse.json({ success: true });
  response.cookies.delete(COOKIE_NAME);
  return response;
}
