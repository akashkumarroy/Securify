import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { queryOne, query } from '@/lib/db';
import { signToken, COOKIE_NAME, COOKIE_OPTIONS } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface DbUser {
  id: string;
  username: string;
  password_hash: string;
  email: string;
  full_name: string;
  role: 'admin' | 'client';
  tenant_id: string | null;
  wazuh_group: string | null;
  is_active: boolean;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body as { username: string; password: string };

    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username and password are required' },
        { status: 400 },
      );
    }

    // Fetch user with tenant info
    const user = await queryOne<DbUser>(
      `SELECT u.id, u.username, u.password_hash, u.email, u.full_name,
              u.role, u.tenant_id, u.is_active,
              t.wazuh_group
       FROM users u
       LEFT JOIN tenants t ON t.id = u.tenant_id
       WHERE u.username = $1`,
      [username.trim().toLowerCase()],
    );

    if (!user) {
      // Timing-safe: still compute hash to prevent user enumeration
      await bcrypt.compare(password, '$2b$12$invalidhashfortimingnormalization');
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    if (!user.is_active) {
      return NextResponse.json({ error: 'Account is disabled' }, { status: 403 });
    }

    const passwordMatch = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatch) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    // Issue JWT
    const jti = uuidv4();
    const token = signToken({
      sub:          user.id,
      username:     user.username,
      role:         user.role,
      tenant_id:    user.tenant_id ?? undefined,
      wazuh_group:  user.wazuh_group ?? undefined,
    });

    // Store session for audit
    const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000);
    const ip = request.headers.get('x-forwarded-for') ?? request.headers.get('x-real-ip') ?? '';
    const ua = request.headers.get('user-agent') ?? '';

    await query(
      `INSERT INTO sessions (user_id, token_jti, ip_address, user_agent, expires_at)
       VALUES ($1, $2, $3, $4, $5)`,
      [user.id, jti, ip, ua, expiresAt],
    );

    // Update last_login
    await query(`UPDATE users SET last_login = NOW() WHERE id = $1`, [user.id]);

    // Audit log
    await query(
      `INSERT INTO audit_logs (user_id, username, action, resource, ip_address)
       VALUES ($1, $2, 'LOGIN', 'auth', $3)`,
      [user.id, user.username, ip],
    );

    // Build response
    const responseData = {
      user: {
        id:        user.id,
        username:  user.username,
        email:     user.email,
        full_name: user.full_name,
        role:      user.role,
        tenant_id: user.tenant_id,
      },
    };

    const response = NextResponse.json(responseData, { status: 200 });

    // Set httpOnly session cookie
    response.cookies.set(COOKIE_NAME, token, COOKIE_OPTIONS);

    return response;
  } catch (err) {
    console.error('[LOGIN]', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
