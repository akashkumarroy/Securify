import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getThreatActors, getIndicators, getReports } from '@/lib/opencti';

function getPayload(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// GET /api/threat-intel/feed
export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type') ?? 'actors';

  try {
    if (type === 'actors') {
      const actors = await getThreatActors(10);
      return NextResponse.json({ actors });
    }
    if (type === 'indicators') {
      const indicators = await getIndicators(20);
      return NextResponse.json({ indicators });
    }
    if (type === 'reports') {
      const reports = await getReports(10);
      return NextResponse.json({ reports });
    }
    return NextResponse.json({ error: 'Invalid type' }, { status: 400 });
  } catch (err) {
    console.error('[THREAT INTEL]', err);
    return NextResponse.json({ error: 'Failed to fetch threat intel' }, { status: 502 });
  }
}
