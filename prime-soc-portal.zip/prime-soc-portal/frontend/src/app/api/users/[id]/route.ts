import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { query, queryOne } from '@/lib/db';

function getPayload(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// PATCH /api/users/[id]
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const payload = getPayload(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const userId = params.id;
  const body = await request.json();
  const { is_active, full_name, email, role, tenant_id, password } = body;

  // Build update query dynamically
  const updates: string[] = [];
  const values: unknown[] = [];
  let idx = 1;

  if (typeof is_active === 'boolean') { updates.push(`is_active = $${idx++}`); values.push(is_active); }
  if (full_name !== undefined) { updates.push(`full_name = $${idx++}`); values.push(full_name); }
  if (email !== undefined) { updates.push(`email = $${idx++}`); values.push(email); }
  if (role !== undefined && ['admin', 'client'].includes(role)) {
    updates.push(`role = $${idx++}`); values.push(role);
  }
  if (tenant_id !== undefined) { updates.push(`tenant_id = $${idx++}`); values.push(tenant_id || null); }
  if (password) {
    const hash = await bcrypt.hash(password, 12);
    updates.push(`password_hash = $${idx++}`); values.push(hash);
  }

  if (updates.length === 0) {
    return NextResponse.json({ error: 'Nothing to update' }, { status: 400 });
  }

  values.push(userId);
  const [user] = await query(
    `UPDATE users SET ${updates.join(', ')} WHERE id = $${idx}
     RETURNING id, username, email, full_name, role, tenant_id, is_active`,
    values,
  );

  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  return NextResponse.json({ user });
}

// DELETE /api/users/[id]
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } },
) {
  const payload = getPayload(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  // Prevent self-deletion
  if (params.id === payload.sub) {
    return NextResponse.json({ error: 'Cannot delete your own account' }, { status: 400 });
  }

  await query(`DELETE FROM users WHERE id = $1`, [params.id]);
  return NextResponse.json({ success: true });
}
