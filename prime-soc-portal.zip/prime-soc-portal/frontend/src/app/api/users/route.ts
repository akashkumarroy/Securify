import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { query, queryOne } from '@/lib/db';

function getPayload(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// GET /api/users
export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const users = await query(
    `SELECT u.id, u.username, u.email, u.full_name, u.role,
            u.tenant_id, u.is_active, u.last_login, u.created_at,
            t.name AS tenant_name, t.uid AS tenant_uid
     FROM users u
     LEFT JOIN tenants t ON t.id = u.tenant_id
     ORDER BY u.created_at DESC`,
  );

  return NextResponse.json({ users });
}

// POST /api/users — create new user (admin only)
export async function POST(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const body = await request.json();
  const { username, password, full_name, email, role, tenant_id } = body;

  if (!username || !password) {
    return NextResponse.json({ error: 'Username and password are required' }, { status: 400 });
  }

  if (!['admin', 'client'].includes(role ?? 'client')) {
    return NextResponse.json({ error: 'Invalid role' }, { status: 400 });
  }

  // Validate tenant exists if provided
  if (tenant_id) {
    const tenant = await queryOne(`SELECT id FROM tenants WHERE id = $1`, [tenant_id]);
    if (!tenant) return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  try {
    const [user] = await query(
      `INSERT INTO users (username, password_hash, email, full_name, role, tenant_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, username, email, full_name, role, tenant_id, is_active, created_at`,
      [
        username.trim().toLowerCase(),
        passwordHash,
        email?.trim() || null,
        full_name?.trim() || null,
        role ?? 'client',
        tenant_id || null,
      ],
    );

    // Audit log
    await query(
      `INSERT INTO audit_logs (user_id, username, action, resource, details)
       VALUES ($1, $2, 'CREATE_USER', 'users', $3)`,
      [payload.sub, payload.username, JSON.stringify({ created_username: username })],
    );

    return NextResponse.json({ user }, { status: 201 });
  } catch (err: unknown) {
    const e = err as { code?: string };
    if (e.code === '23505') {
      return NextResponse.json({ error: 'Username already exists' }, { status: 409 });
    }
    throw err;
  }
}
