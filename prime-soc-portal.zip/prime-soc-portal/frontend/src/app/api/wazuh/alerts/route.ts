import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
import { getAlerts } from '@/lib/wazuh';

function getPayload(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// GET /api/wazuh/alerts?limit=50
export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const limit = Math.min(parseInt(searchParams.get('limit') ?? '50'), 200);

  try {
    let wazuhGroup: string | undefined;
    if (payload.role !== 'admin') {
      if (payload.wazuh_group) {
        wazuhGroup = payload.wazuh_group;
      } else if (payload.tenant_id) {
        const tenant = await queryOne<{ wazuh_group: string }>(
          `SELECT wazuh_group FROM tenants WHERE id = $1`,
          [payload.tenant_id],
        );
        wazuhGroup = tenant?.wazuh_group;
      }
    }

    const alertsData = await getAlerts(wazuhGroup, limit);
    const alerts = (alertsData.affected_items as Array<Record<string, unknown>>).map((a) => {
      const rule = (a.rule as Record<string, unknown>) ?? {};
      const agent = (a.agent as Record<string, unknown>) ?? {};
      const level = (rule.level as number) ?? 0;

      let severity: string;
      if (level >= 13) severity = 'CRITICAL';
      else if (level >= 10) severity = 'HIGH';
      else if (level >= 7) severity = 'MEDIUM';
      else if (level >= 4) severity = 'LOW';
      else severity = 'INFO';

      return {
        id:         a.id ?? a._id ?? Math.random().toString(36).slice(2),
        timestamp:  a.timestamp,
        severity,
        source:     agent.name ?? 'unknown',
        event_name: rule.description ?? 'Unknown event',
        status:     level >= 13 ? 'Triaging' : level >= 10 ? 'Pending' : 'Closed',
        rule_level: level,
        agent_id:   agent.id,
        agent_ip:   agent.ip,
      };
    });

    return NextResponse.json({
      alerts,
      total: alertsData.total_affected_items,
    });
  } catch (err) {
    console.error('[WAZUH ALERTS]', err);
    return NextResponse.json({ error: 'Failed to fetch alerts' }, { status: 502 });
  }
}
