import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
import { getAgents } from '@/lib/wazuh';

function getPayload(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    let wazuhGroup: string | undefined;
    if (payload.role !== 'admin') {
      if (payload.wazuh_group) {
        wazuhGroup = payload.wazuh_group;
      } else if (payload.tenant_id) {
        const tenant = await queryOne<{ wazuh_group: string }>(
          `SELECT wazuh_group FROM tenants WHERE id = $1`,
          [payload.tenant_id],
        );
        wazuhGroup = tenant?.wazuh_group;
      }
    }

    const data = await getAgents(wazuhGroup);
    return NextResponse.json({
      agents: data.affected_items,
      total:  data.total_affected_items,
    });
  } catch (err) {
    console.error('[WAZUH AGENTS]', err);
    return NextResponse.json({ error: 'Failed to fetch agents' }, { status: 502 });
  }
}
