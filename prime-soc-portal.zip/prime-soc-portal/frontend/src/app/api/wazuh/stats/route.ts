import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { queryOne } from '@/lib/db';
import { getDashboardStats, getAlerts, getSecurityEvents } from '@/lib/wazuh';

function getPayload(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

async function getWazuhGroup(payload: ReturnType<typeof getPayload>) {
  if (!payload) return undefined;
  if (payload.role === 'admin') return undefined; // admin sees all
  if (payload.wazuh_group) return payload.wazuh_group;

  // Fallback: load from DB
  if (payload.tenant_id) {
    const tenant = await queryOne<{ wazuh_group: string }>(
      `SELECT wazuh_group FROM tenants WHERE id = $1`,
      [payload.tenant_id],
    );
    return tenant?.wazuh_group;
  }
  return undefined;
}

// GET /api/wazuh/stats
export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const wazuhGroup = await getWazuhGroup(payload);
    const stats = await getDashboardStats(wazuhGroup);
    return NextResponse.json(stats);
  } catch (err) {
    console.error('[WAZUH STATS]', err);
    return NextResponse.json({ error: 'Failed to fetch Wazuh stats' }, { status: 502 });
  }
}
