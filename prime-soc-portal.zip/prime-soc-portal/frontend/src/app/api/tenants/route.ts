import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { query, queryOne } from '@/lib/db';
import bcrypt from 'bcryptjs';

function getPayload(request: NextRequest) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// GET /api/tenants — list all (admin) or own tenant (client)
export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  if (payload.role === 'admin') {
    const tenants = await query(
      `SELECT t.*,
              COUNT(DISTINCT u.id) AS user_count
       FROM tenants t
       LEFT JOIN users u ON u.tenant_id = t.id
       GROUP BY t.id
       ORDER BY t.name ASC`,
    );
    return NextResponse.json({ tenants });
  } else {
    // Client: only their own tenant
    if (!payload.tenant_id) {
      return NextResponse.json({ tenants: [] });
    }
    const tenant = await queryOne(
      `SELECT t.*,
              COUNT(DISTINCT u.id) AS user_count
       FROM tenants t
       LEFT JOIN users u ON u.tenant_id = t.id
       WHERE t.id = $1
       GROUP BY t.id`,
      [payload.tenant_id],
    );
    return NextResponse.json({ tenants: tenant ? [tenant] : [] });
  }
}

// POST /api/tenants — create new tenant (admin only)
export async function POST(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload || payload.role !== 'admin') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const body = await request.json();
  const { name, uid, wazuh_group, industry, status } = body;

  if (!name || !uid || !wazuh_group) {
    return NextResponse.json({ error: 'name, uid, and wazuh_group are required' }, { status: 400 });
  }

  try {
    const [tenant] = await query(
      `INSERT INTO tenants (name, uid, wazuh_group, industry, status)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [name, uid, wazuh_group, industry ?? null, status ?? 'active'],
    );
    return NextResponse.json({ tenant }, { status: 201 });
  } catch (err: unknown) {
    const e = err as { code?: string };
    if (e.code === '23505') {
      return NextResponse.json({ error: 'Tenant UID already exists' }, { status: 409 });
    }
    throw err;
  }
}
