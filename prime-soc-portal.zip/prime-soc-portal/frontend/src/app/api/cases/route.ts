import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getCases, getCaseStats } from '@/lib/iris';

function getPayload(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// GET /api/cases — list cases with stats
export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const statsOnly = searchParams.get('stats') === 'true';

  try {
    if (statsOnly) {
      const stats = await getCaseStats();
      return NextResponse.json(stats);
    }
    const cases = await getCases();
    return NextResponse.json({ cases });
  } catch (err) {
    console.error('[IRIS CASES]', err);
    return NextResponse.json({ error: 'Failed to fetch cases' }, { status: 502 });
  }
}
