import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, COOKIE_NAME } from '@/lib/auth';
import { getSOARStats, getWorkflows } from '@/lib/shuffle';

function getPayload(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// GET /api/soar/stats
export async function GET(request: NextRequest) {
  const payload = getPayload(request);
  if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const stats = await getSOARStats();
    return NextResponse.json(stats);
  } catch (err) {
    console.error('[SOAR STATS]', err);
    return NextResponse.json({ error: 'Failed to fetch SOAR stats' }, { status: 502 });
  }
}
