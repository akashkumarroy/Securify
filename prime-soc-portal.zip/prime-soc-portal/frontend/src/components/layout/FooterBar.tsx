'use client';

import { useEffect, useState } from 'react';

export default function FooterBar({ className = '' }: { className?: string }) {
  const [time, setTime] = useState('');
  const [latency, setLatency] = useState(14);

  useEffect(() => {
    const tick = () => {
      setTime(new Date().toISOString().split('T')[1].split('.')[0]);
      setLatency(Math.floor(12 + Math.random() * 8));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <footer
      className={`${className} flex justify-between items-center px-6 z-50`}
      style={{
        background: 'rgba(9,14,24,0.85)',
        backdropFilter: 'blur(8px)',
        borderTop: '1px solid rgba(59,73,75,0.15)',
      }}
    >
      <div className="flex items-center gap-5">
        <span className="font-mono text-[10px] text-[#72ff70] flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#72ff70] status-dot-live" />
          SYSTEM HEALTH: NOMINAL
        </span>
        <span className="w-px h-3" style={{ background: 'rgba(59,73,75,0.5)' }} />
        <span className="font-mono text-[10px] text-[#b9cacb]">ENCRYPTED LINK: STABLE</span>
      </div>
      <div className="flex items-center gap-5">
        <a href="#" className="font-mono text-[10px] text-[#849495] hover:text-[#dee2f1] transition-colors">
          Status Page
        </a>
        <a href="#" className="font-mono text-[10px] text-[#849495] hover:text-[#dee2f1] transition-colors">
          Support
        </a>
        <a href="#" className="font-mono text-[10px] text-[#849495] hover:text-[#dee2f1] transition-colors">
          Documentation
        </a>
        <span className="w-px h-3" style={{ background: 'rgba(59,73,75,0.5)' }} />
        <span className="font-mono text-[10px] text-[#849495]">LATENCY: {latency}ms</span>
        <span className="font-mono text-[10px] text-[#849495]">UTC: {time}</span>
      </div>
    </footer>
  );
}
