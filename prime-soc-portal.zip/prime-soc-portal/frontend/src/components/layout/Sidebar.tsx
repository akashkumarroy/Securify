'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';

interface SidebarProps {
  user: Record<string, unknown>;
  className?: string;
}

const NAV_ITEMS = [
  {
    label: 'Dashboard',
    href: '/dashboard',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M4 5a1 1 0 011-1h4a1 1 0 011 1v5a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v2a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zM14 13a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-4a1 1 0 01-1-1v-6z" />
      </svg>
    ),
  },
  {
    label: 'SIEM',
    href: '/siem',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
      </svg>
    ),
  },
  {
    label: 'SOAR',
    href: '/soar',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
  },
  {
    label: 'Threat Intel',
    href: '/threat-intel',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    label: 'Cases',
    href: '/cases',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
      </svg>
    ),
  },
  {
    label: 'Reports',
    href: '/reports',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    ),
  },
  {
    label: 'Assets',
    href: '/assets',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
      </svg>
    ),
  },
  {
    label: 'Settings',
    href: '/settings',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
];

const ADMIN_ITEMS = [
  {
    label: 'Tenants',
    href: '/admin/tenants',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
      </svg>
    ),
  },
  {
    label: 'Users',
    href: '/admin/users',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8}
          d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
      </svg>
    ),
  },
];

export default function Sidebar({ user, className = '' }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const role = user.role as string;
  const fullName = (user.full_name as string) || (user.username as string);
  const tenantName = user.tenant_name as string | undefined;
  const tenantStatus = user.tenant_status as string | undefined;

  const statusColor =
    tenantStatus === 'critical' ? '#ffb4ab' :
    tenantStatus === 'warning'  ? '#ffd770' : '#72ff70';

  return (
    <aside
      className={`${className} flex flex-col`}
      style={{
        background: 'rgba(9,14,24,0.8)',
        borderRight: '1px solid rgba(59,73,75,0.2)',
        backdropFilter: 'blur(12px)',
      }}
    >
      {/* User Profile Area */}
      <div className="p-4 border-b" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
        <div className="flex items-center gap-3">
          <div className="relative shrink-0">
            <div className="w-9 h-9 rounded-full flex items-center justify-center font-mono text-xs font-bold text-[#00363a]"
              style={{ background: '#00f0ff' }}>
              {fullName?.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2) || 'U'}
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#090e18]"
              style={{ background: statusColor }} />
          </div>
          <div className="min-w-0">
            <p className="font-mono text-[12px] font-bold text-[#dee2f1] truncate">{fullName}</p>
            <p className="font-mono text-[10px] truncate" style={{ color: statusColor }}>
              {role === 'admin' ? 'Level 4 Clearance' : tenantName ?? 'Client Portal'}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2 overflow-y-auto">
        <div className="space-y-0.5">
          {NAV_ITEMS.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + '/');
            return (
              <button
                key={item.href}
                onClick={() => router.push(item.href)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 text-left group"
                style={{
                  background: active ? 'rgba(112,0,255,0.2)' : 'transparent',
                  borderLeft: active ? '2px solid #7000ff' : '2px solid transparent',
                  color: active ? '#dee2f1' : '#849495',
                }}
              >
                <span className={`shrink-0 transition-colors ${active ? 'text-[#d1bcff]' : 'text-[#849495] group-hover:text-[#b9cacb]'}`}>
                  {item.icon}
                </span>
                <span className={`font-mono text-[13px] transition-colors ${active ? 'font-semibold text-[#dee2f1]' : 'group-hover:text-[#dee2f1]'}`}>
                  {item.label}
                </span>
                {item.label === 'Cases' && (
                  <span className="ml-auto font-mono text-[9px] font-bold px-1.5 py-0.5 rounded"
                    style={{ background: 'rgba(255,180,171,0.15)', color: '#ffb4ab' }}>
                    3
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Admin Section */}
        {role === 'admin' && (
          <div className="mt-4">
            <p className="font-mono text-[10px] font-bold tracking-[0.15em] uppercase text-[#3b494b] px-3 mb-2">
              Admin
            </p>
            <div className="space-y-0.5">
              {ADMIN_ITEMS.map((item) => {
                const active = pathname === item.href || pathname.startsWith(item.href + '/');
                return (
                  <button
                    key={item.href}
                    onClick={() => router.push(item.href)}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 text-left group"
                    style={{
                      background: active ? 'rgba(0,240,255,0.1)' : 'transparent',
                      borderLeft: active ? '2px solid #00f0ff' : '2px solid transparent',
                      color: active ? '#dee2f1' : '#849495',
                    }}
                  >
                    <span className={`shrink-0 ${active ? 'text-[#00f0ff]' : 'text-[#849495] group-hover:text-[#b9cacb]'}`}>
                      {item.icon}
                    </span>
                    <span className={`font-mono text-[13px] ${active ? 'font-semibold text-[#dee2f1]' : 'group-hover:text-[#dee2f1]'}`}>
                      {item.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </nav>

      {/* Bottom Status */}
      <div className="p-3 border-t" style={{ borderColor: 'rgba(59,73,75,0.2)' }}>
        <div className="flex items-center gap-2 px-1">
          <div className="w-1.5 h-1.5 rounded-full bg-[#72ff70] status-dot-live" />
          <span className="font-mono text-[10px] text-[#849495]">SOC ACTIVE</span>
        </div>
      </div>
    </aside>
  );
}
