'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface TopBarProps {
  user: Record<string, unknown>;
  className?: string;
}

export default function TopBar({ user, className = '' }: TopBarProps) {
  const router = useRouter();
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchVal, setSearchVal] = useState('');
  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setProfileOpen(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  };

  const role = user.role as string;
  const fullName = (user.full_name as string) || (user.username as string);
  const tenantName = user.tenant_name as string | undefined;
  const initials = fullName?.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2) || 'U';

  return (
    <header
      className={`${className} flex items-center justify-between px-4 z-50`}
      style={{
        background: 'rgba(9,14,24,0.95)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(59,73,75,0.25)',
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 min-w-[200px]">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="shrink-0">
          <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"
            fill="rgba(0,240,255,0.12)" stroke="#00f0ff" strokeWidth="1.5" />
          <path d="M9 12l2 2 4-4" stroke="#00f0ff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="font-bold text-[15px] tracking-tight text-white">Prime SOC</span>
      </div>

      {/* Search */}
      <div className="flex-1 max-w-[380px] mx-4">
        <div className="relative">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#849495]"
            fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            value={searchVal}
            onChange={(e) => setSearchVal(e.target.value)}
            placeholder="Search telemetry..."
            className="w-full pl-8 pr-4 py-1.5 bg-black/30 font-mono text-[13px] text-[#dee2f1] rounded-lg outline-none placeholder:text-[#849495] transition-all"
            style={{ border: '1px solid rgba(59,73,75,0.3)' }}
            onFocus={(e) => e.currentTarget.style.borderColor = 'rgba(0,240,255,0.4)'}
            onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(59,73,75,0.3)'}
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        {/* Create Case */}
        <button
          onClick={() => router.push('/cases')}
          className="font-mono text-[10px] font-bold tracking-[0.1em] uppercase px-3 py-1.5 rounded-lg transition-all"
          style={{ border: '1px solid #00f0ff', color: '#00f0ff', background: 'rgba(0,240,255,0.08)' }}
        >
          Create Case
        </button>

        {/* Run Playbook */}
        <button
          onClick={() => router.push('/soar')}
          className="font-mono text-[10px] font-bold tracking-[0.1em] uppercase px-3 py-1.5 rounded-lg transition-all text-white"
          style={{ border: '1px solid rgba(255,255,255,0.2)', background: 'rgba(255,255,255,0.05)' }}
        >
          Run Playbook
        </button>

        {/* Notifications */}
        <div ref={notifRef} className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="relative w-8 h-8 flex items-center justify-center rounded-lg transition-colors hover:bg-white/5"
          >
            <svg className="w-4 h-4 text-[#b9cacb]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-[#ffb4ab]"
              style={{ boxShadow: '0 0 4px rgba(255,180,171,0.8)' }} />
          </button>

          {notifOpen && (
            <div className="absolute right-0 top-10 w-72 rounded-xl z-50 overflow-hidden"
              style={{ background: '#1b202a', border: '1px solid rgba(59,73,75,0.4)', boxShadow: '0 16px 48px rgba(0,0,0,0.6)' }}>
              <div className="p-3 border-b border-[#3b494b]/30 flex justify-between items-center">
                <span className="font-mono text-[11px] font-bold tracking-widest uppercase text-[#dee2f1]">Notifications</span>
                <span className="font-mono text-[10px] text-[#849495]">3 unread</span>
              </div>
              <div className="p-2 max-h-72 overflow-y-auto">
                {[
                  { sev: 'critical', title: 'Ransomware Lateral Movement Detected', time: 'Just now' },
                  { sev: 'high', title: 'Brute Force Attack on VPN-GW-EAST', time: '2m ago' },
                  { sev: 'medium', title: 'Unusual Data Egress: AWS-PROD-01', time: '14m ago' },
                ].map((n, i) => (
                  <div key={i} className="p-2.5 rounded-lg hover:bg-white/5 cursor-pointer flex gap-3 items-start">
                    <div className={`w-2 h-2 rounded-full mt-1 shrink-0 ${n.sev === 'critical' ? 'bg-[#ffb4ab]' : n.sev === 'high' ? 'bg-[#ffb870]' : 'bg-[#ffd770]'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="font-mono text-[11px] text-[#dee2f1] leading-snug">{n.title}</p>
                      <p className="font-mono text-[10px] text-[#849495] mt-0.5">{n.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Apps grid */}
        <button className="w-8 h-8 flex items-center justify-center rounded-lg transition-colors hover:bg-white/5">
          <svg className="w-4 h-4 text-[#b9cacb]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
              d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
          </svg>
        </button>

        {/* User Profile */}
        <div ref={profileRef} className="relative">
          <button onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-white/5 transition-colors">
            <div className="w-7 h-7 rounded-full flex items-center justify-center font-mono text-[11px] font-bold text-[#00363a]"
              style={{ background: '#00f0ff' }}>
              {initials}
            </div>
            <svg className="w-3 h-3 text-[#849495]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>

          {profileOpen && (
            <div className="absolute right-0 top-10 w-56 rounded-xl z-50 overflow-hidden"
              style={{ background: '#1b202a', border: '1px solid rgba(59,73,75,0.4)', boxShadow: '0 16px 48px rgba(0,0,0,0.6)' }}>
              <div className="p-3 border-b border-[#3b494b]/30">
                <p className="font-mono text-[12px] font-bold text-[#dee2f1]">{fullName}</p>
                <p className="font-mono text-[10px] text-[#849495] mt-0.5">
                  {role === 'admin' ? 'SUPER ADMIN' : `CLIENT — ${tenantName ?? 'No Tenant'}`}
                </p>
              </div>
              <div className="p-1.5">
                {[
                  { label: 'Profile Settings', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' },
                ].map((item) => (
                  <button key={item.label}
                    className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors text-left">
                    <svg className="w-3.5 h-3.5 text-[#849495]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
                    </svg>
                    <span className="font-mono text-[12px] text-[#dee2f1]">{item.label}</span>
                  </button>
                ))}
                <div className="my-1 border-t border-[#3b494b]/30" />
                <button onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-red-500/10 transition-colors text-left">
                  <svg className="w-3.5 h-3.5 text-[#ffb4ab]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  <span className="font-mono text-[12px] text-[#ffb4ab]">Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
