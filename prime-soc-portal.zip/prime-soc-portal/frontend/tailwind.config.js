/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // ── Prime SOC Design System (from Stitch) ──────────────
        background:                '#0e131d',
        surface:                   '#0e131d',
        'surface-dim':             '#0e131d',
        'surface-bright':          '#343945',
        'surface-container-lowest':'#090e18',
        'surface-container-low':   '#171c26',
        'surface-container':       '#1b202a',
        'surface-container-high':  '#252a35',
        'surface-container-highest':'#303540',
        'surface-variant':         '#303540',

        // Primary (Neon Cyan)
        primary:                   '#dbfcff',
        'primary-fixed':           '#7df4ff',
        'primary-fixed-dim':       '#00dbe9',
        'primary-container':       '#00f0ff',
        'on-primary':              '#00363a',
        'on-primary-container':    '#006970',
        'on-primary-fixed':        '#002022',
        'on-primary-fixed-variant':'#004f54',
        'inverse-primary':         '#006970',

        // Secondary (Purple)
        secondary:                 '#d1bcff',
        'secondary-fixed':         '#e9ddff',
        'secondary-fixed-dim':     '#d1bcff',
        'secondary-container':     '#7000ff',
        'on-secondary':            '#3c0090',
        'on-secondary-container':  '#ddcdff',
        'on-secondary-fixed':      '#23005b',
        'on-secondary-fixed-variant':'#5700c9',

        // Tertiary (Green)
        tertiary:                  '#ddffd3',
        'tertiary-fixed':          '#72ff70',
        'tertiary-fixed-dim':      '#00e639',
        'tertiary-container':      '#00fb40',
        'on-tertiary':             '#003907',
        'on-tertiary-container':   '#006e16',
        'on-tertiary-fixed':       '#002203',
        'on-tertiary-fixed-variant':'#00530e',

        // Error
        error:                     '#ffb4ab',
        'error-container':         '#93000a',
        'on-error':                '#690005',
        'on-error-container':      '#ffdad6',

        // Neutral
        outline:                   '#849495',
        'outline-variant':         '#3b494b',
        'on-background':           '#dee2f1',
        'on-surface':              '#dee2f1',
        'on-surface-variant':      '#b9cacb',
        'inverse-surface':         '#dee2f1',
        'inverse-on-surface':      '#2c303b',
        'surface-tint':            '#00dbe9',

        // Semantic aliases (for easier usage)
        'neon-cyan':  '#00f0ff',
        'neon-purple':'#7000ff',
        'neon-green': '#72ff70',
        'neon-red':   '#ff4444',
      },
      fontFamily: {
        sans:  ['Inter', 'system-ui', 'sans-serif'],
        mono:  ['"JetBrains Mono"', 'Consolas', 'monospace'],
        display: ['Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display-lg': ['48px', { lineHeight: '1.1', letterSpacing: '-0.02em', fontWeight: '700' }],
        'headline-md': ['24px', { lineHeight: '1.2', letterSpacing: '-0.01em', fontWeight: '600' }],
        'data-mono': ['14px', { lineHeight: '1.4', fontWeight: '500' }],
        'label-caps': ['11px', { lineHeight: '1', letterSpacing: '0.1em', fontWeight: '700' }],
        'body-base': ['16px', { lineHeight: '1.6', fontWeight: '400' }],
      },
      borderRadius: {
        DEFAULT: '0.125rem',
        sm:      '0.125rem',
        md:      '0.25rem',
        lg:      '0.375rem',
        xl:      '0.5rem',
        '2xl':   '0.75rem',
        full:    '0.75rem',
      },
      animation: {
        'pulse-cyan':   'pulse-cyan 2s infinite',
        'scan':         'scan 4s linear infinite',
        'glow':         'glow 2s ease-in-out infinite alternate',
        'float':        'float 6s ease-in-out infinite',
        'slide-in-left':'slide-in-left 0.3s ease-out',
        'slide-in-up':  'slide-in-up 0.3s ease-out',
        'fade-in':      'fade-in 0.3s ease-out',
      },
      keyframes: {
        'pulse-cyan': {
          '0%':   { boxShadow: '0 0 0 0 rgba(0, 240, 255, 0.4)' },
          '70%':  { boxShadow: '0 0 0 15px rgba(0, 240, 255, 0)' },
          '100%': { boxShadow: '0 0 0 0 rgba(0, 240, 255, 0)' },
        },
        scan: {
          '0%':   { top: '0%', opacity: '0' },
          '5%':   { opacity: '1' },
          '95%':  { opacity: '1' },
          '100%': { top: '100%', opacity: '0' },
        },
        glow: {
          from: { textShadow: '0 0 10px rgba(0,240,255,0.3)' },
          to:   { textShadow: '0 0 20px rgba(0,240,255,0.7), 0 0 40px rgba(0,240,255,0.3)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%':      { transform: 'translateY(-8px)' },
        },
        'slide-in-left': {
          from: { opacity: '0', transform: 'translateX(-20px)' },
          to:   { opacity: '1', transform: 'translateX(0)' },
        },
        'slide-in-up': {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          from: { opacity: '0' },
          to:   { opacity: '1' },
        },
      },
      boxShadow: {
        'neon-cyan':   '0 0 15px rgba(0, 240, 255, 0.4)',
        'neon-purple': '0 0 15px rgba(112, 0, 255, 0.4)',
        'neon-green':  '0 0 15px rgba(114, 255, 112, 0.4)',
        'glass':       '0 0 40px rgba(0,0,0,0.5), inset 0 0 20px rgba(0,240,255,0.05)',
        'card':        '0 4px 24px rgba(0,0,0,0.4)',
      },
      backgroundImage: {
        'grid-cyan': `
          linear-gradient(to right, rgba(0,240,255,0.03) 1px, transparent 1px),
          linear-gradient(to bottom, rgba(0,240,255,0.03) 1px, transparent 1px)
        `,
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      },
      backgroundSize: {
        'grid': '40px 40px',
      },
    },
  },
  plugins: [],
};
